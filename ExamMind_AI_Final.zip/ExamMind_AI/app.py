import streamlit as st
import json
import os
import io
import pandas as pd
from typing import Dict, List, Any, Optional
from pathlib import Path

# Load .env file automatically if present (with fallback to _env)
ENV_PATH = Path(__file__).resolve().parent / ".env"
if not ENV_PATH.exists():
    ENV_PATH = Path(__file__).resolve().parent / "_env"

if ENV_PATH.exists():
    try:
        with open(ENV_PATH, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
    except OSError as e:
        print(f"Warning: Could not read environment file: {e}")

from curriculum.loader import curriculum_repo
from engine.validator import ExamPatternValidator
from engine.parser import DocumentParser
from engine.analyzer import MaterialAnalyzer
from engine.generator import ExamGenerator
from engine.grader import ExamGrader
from engine.pdf_export import generate_exam_pdf, format_paper_as_text
from engine.docx_export import generate_exam_docx
from database.db import save_paper, get_all_papers, get_paper_by_uid, delete_paper

UNIVERSITY_PRESETS = {
    "General HEC University Standard": "Department of Computer Science — Examination Paper",
    "Institute of Space Technology (IST) Islamabad": "Institute of Space Technology (IST) Islamabad — Department of Computer Science",
    "FAST-NUCES (High Coding & Tracing Rigor)": "FAST National University of Computer and Emerging Sciences — Department of Computer Science",
    "NUST - SEECS (Analytical & Scenario Modeling)": "National University of Sciences and Technology (NUST) — SEECS",
    "COMSATS University Islamabad": "COMSATS University Islamabad — Department of Computer Science",
    "PUCIT / Punjab University": "Punjab University College of Information Technology (PUCIT)",
    "UET Lahore / Taxila": "University of Engineering and Technology (UET) — Department of CS",
    "GIKI (Top Engineering Standard)": "Ghulam Ishaq Khan Institute of Engineering Sciences and Technology (GIKI)",
    "IBA Karachi / Karachi University": "Institute of Business Administration (IBA) Karachi — CS Department",
    "Air University Islamabad": "Air University Islamabad — Faculty of Computing & AI",
    "Bahria University": "Bahria University — Department of Computer Science"
}

# Streamlit Page Config
st.set_page_config(
    page_title="ExamMind AI — HEC Pakistan BSCS Exam Generator",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS styling (Self-contained, offline-friendly)
st.markdown("""
<style>
    .main-header {
        font-size: 2.2rem;
        font-weight: 800;
        color: #1E3A8A;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        font-size: 1.05rem;
        color: #4B5563;
        margin-bottom: 1.5rem;
    }
    .step-card {
        background-color: #F8FAFC;
        border-radius: 10px;
        padding: 1.2rem;
        border: 1px solid #E2E8F0;
        margin-bottom: 1.2rem;
    }
    .validation-success {
        background-color: #ECFDF5;
        border: 1px solid #10B981;
        border-radius: 8px;
        padding: 10px 14px;
        color: #065F46;
        font-weight: 600;
        margin-top: 10px;
    }
    .validation-error {
        background-color: #FEF2F2;
        border: 1px solid #EF4444;
        border-radius: 8px;
        padding: 10px 14px;
        color: #991B1B;
        font-weight: 600;
        margin-top: 10px;
    }
    .tag-badge {
        display: inline-block;
        background-color: #EFF6FF;
        color: #1E40AF;
        padding: 2px 8px;
        border-radius: 4px;
        font-size: 0.78rem;
        font-weight: 600;
        margin-right: 4px;
    }
    .blooms-badge {
        display: inline-block;
        background-color: #FDF2F8;
        color: #9D174D;
        padding: 2px 8px;
        border-radius: 4px;
        font-size: 0.78rem;
        font-weight: 600;
    }
</style>
""", unsafe_allow_html=True)


# Initialize Session State
if "generated_paper" not in st.session_state:
    st.session_state.generated_paper = None
if "current_paper_uid" not in st.session_state:
    st.session_state.current_paper_uid = None
if "parsed_materials_cache" not in st.session_state:
    st.session_state.parsed_materials_cache = {}

# ---------------------------------------------------------
# SIDEBAR: Engine & API Keys & History
# ---------------------------------------------------------
with st.sidebar:
    st.markdown("### ⚙️ **AI Engine & API Configuration**")
    
    llm_provider = st.selectbox(
        "Select Generation Engine:",
        ["Google Gemini Free Tier", "Offline Synthesizer (Instant / No Key)", "Groq Inference"],
        index=0
    )

    env_gemini_key = os.environ.get("GEMINI_API_KEY", "")
    env_groq_key = os.environ.get("GROQ_API_KEY", "")

    api_key = ""
    if "Gemini" in llm_provider:
        api_key = st.text_input(
            "Gemini API Key:",
            value=env_gemini_key,
            type="password",
            help="Your API key from Google AI Studio (https://aistudio.google.com/app/apikey). Automatically loaded from .env if present."
        )
        if api_key:
            os.environ["GEMINI_API_KEY"] = api_key
            st.caption("✅ Gemini Key Configured")
        else:
            st.warning("⚠️ No Gemini key provided. System will fall back to Offline Synthesizer.")
    elif "Groq" in llm_provider:
        api_key = st.text_input(
            "Groq API Key:",
            value=env_groq_key,
            type="password",
            help="Your API key from Groq Cloud Console."
        )
        if api_key:
            os.environ["GROQ_API_KEY"] = api_key

    st.markdown("---")
    st.markdown("### 🗃️ **Saved Exam Papers**")
    saved_papers = get_all_papers()
    if saved_papers:
        for p in saved_papers[:6]:
            col_l, col_d = st.columns([4, 1])
            with col_l:
                if st.button(f"📄 {p['subject_title']} ({p['exam_type']})", key=f"hist_{p['paper_uid']}", use_container_width=True):
                    paper_obj = get_paper_by_uid(p["paper_uid"])
                    if paper_obj:
                        st.session_state.generated_paper = paper_obj["paper_content"]
                        st.session_state.current_paper_uid = p["paper_uid"]
                        st.rerun()
            with col_d:
                if st.button("✕", key=f"del_{p['paper_uid']}", help="Delete"):
                    delete_paper(p["paper_uid"])
                    st.rerun()
    else:
        st.caption("No previously generated papers found.")


# ---------------------------------------------------------
# MAIN INTERFACE: 5-Step Configurator
# ---------------------------------------------------------
st.markdown('<div class="main-header">🎓 ExamMind AI</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-header">Autonomous Practice Exam Paper Generator & Assessment Suite for BS Computer Science (HEC Pakistan Curriculum 2025/2026)</div>', unsafe_allow_html=True)

col_input, col_output = st.columns([5, 6], gap="medium")

with col_input:
    # ------------------ STEP 1: SUBJECT SELECTION ------------------
    st.markdown("### **Step 1 — Subject & University Profile**")
    subjects = curriculum_repo.get_subjects_list()
    subject_titles = [f"{s['title']} ({s['code']})" for s in subjects]
    
    selected_subject_str = st.selectbox("Select BS Computer Science Subject:", subject_titles, index=0)
    selected_slug = next(s['slug'] for s in subjects if f"{s['title']} ({s['code']})" == selected_subject_str)
    subject_info = curriculum_repo.get_subject_by_slug(selected_slug)

    u_col1, u_col2 = st.columns(2)
    with u_col1:
        uni_profile = st.selectbox("Target University Standard:", list(UNIVERSITY_PRESETS.keys()), index=0)
        university_header = UNIVERSITY_PRESETS[uni_profile]
    with u_col2:
        rigor_level = st.selectbox("Rigor / Difficulty Level:", ["Standard HEC", "Foundational", "High Rigor (FAST-Style)"], index=0)

    # CLO inspection expander
    if subject_info:
        with st.expander("🔍 View Official HEC CLOs & Mapped PLOs for this Course"):
            st.markdown(f"**Course Description:** {subject_info.get('description', '')}")
            st.markdown(f"**Category:** `{subject_info.get('category')}` | **Credits:** `{subject_info.get('credit_hours')}` | **Semester:** `{subject_info.get('semester_suggested', 'Core')}`")
            st.markdown("#### Official Course Learning Outcomes (CLOs):")
            for clo in subject_info.get("clos", []):
                plos_str = ", ".join(clo.get("mapped_plos", []))
                st.markdown(f"- **[{clo['id']}]** {clo['text']}  \n  *Bloom's Level:* `{clo['blooms_level']}` | *Mapped PLOs:* `{plos_str}`")
            st.markdown("#### Prescribed Common Topics:")
            st.write(", ".join(subject_info.get("common_topics", [])))

    # ------------------ STEP 2: EXAM SCOPE & MATERIAL UPLOAD ------------------
    st.markdown("### **Step 2 — Exam Scope & Course Materials**")
    exam_type = st.radio("Select Examination Scope:", ["Midterm", "Final"], horizontal=True)

    with st.expander("📁 Attach Course Documents & Past Assessments (Optional but Recommended)", expanded=False):
        st.caption("Upload lecture slides, past quizzes, assignments, or midterm papers (.pdf, .pptx, .docx, .txt, .png, .jpg). Multimodal Vision extracts questions from diagrams and photos.")
        up_slides = st.file_uploader("Upload Lecture Slides & Notes:", type=["pdf", "pptx", "docx", "txt", "png", "jpg", "jpeg"], accept_multiple_files=True, key="up_slides")
        up_quizzes = st.file_uploader("Upload Past Quizzes & Assessments:", type=["pdf", "docx", "txt", "png", "jpg", "jpeg"], accept_multiple_files=True, key="up_quizzes")
        up_assign = st.file_uploader("Upload Assignments / Homework Sets:", type=["pdf", "docx", "txt", "png", "jpg", "jpeg"], accept_multiple_files=True, key="up_assign")
        up_past = st.file_uploader("Upload Past Exam Papers (Midterm / Final):", type=["pdf", "docx", "txt", "png", "jpg", "jpeg"], accept_multiple_files=True, key="up_past")

    uploaded_files_map = {
        "slides": up_slides or [],
        "quizzes": up_quizzes or [],
        "assignments": up_assign or [],
        "past_papers": up_past or []
    }
    total_uploaded = sum(len(f) for f in uploaded_files_map.values())

    # ------------------ STEP 3: PAPER PATTERN SPECIFICATION ------------------
    st.markdown("### **Step 3 — Paper Pattern & Marks Allocation**")
    
    total_marks = st.number_input("Total Exam Marks:", min_value=10, max_value=200, value=50, step=5)
    
    p_col1, p_col2 = st.columns(2)
    with p_col1:
        mcq_count = st.number_input("Number of MCQs:", min_value=0, max_value=50, value=10, step=1)
        short_count = st.number_input("Number of Short Questions:", min_value=0, max_value=20, value=4, step=1)
        long_count = st.number_input("Number of Long Questions:", min_value=0, max_value=10, value=2, step=1)
        tf_count = st.number_input("Number of True/False (if any):", min_value=0, max_value=30, value=0, step=1)
    
    with p_col2:
        mcq_marks = st.number_input("Marks per MCQ:", min_value=0.5, max_value=5.0, value=1.0, step=0.5)
        short_marks = st.number_input("Marks per Short Question:", min_value=1.0, max_value=20.0, value=5.0, step=1.0)
        long_marks = st.number_input("Marks per Long Question:", min_value=2.0, max_value=50.0, value=10.0, step=1.0)
        tf_marks = st.number_input("Marks per True/False:", min_value=0.5, max_value=5.0, value=1.0, step=0.5)

    # Validate pattern equation
    is_valid, calc_total, val_msg = ExamPatternValidator.validate_marks(
        total_marks=float(total_marks),
        mcq_count=int(mcq_count),
        mcq_marks_each=float(mcq_marks),
        short_count=int(short_count),
        short_marks_each=float(short_marks),
        long_count=int(long_count),
        long_marks_each=float(long_marks),
        tf_count=int(tf_count),
        tf_marks_each=float(tf_marks)
    )

    if is_valid:
        st.markdown(f'<div class="validation-success">✅ {val_msg}</div>', unsafe_allow_html=True)
    else:
        st.markdown(f'<div class="validation-error">⚠️ {val_msg}</div>', unsafe_allow_html=True)

    # ------------------ STEP 4: VERBAL INSTRUCTIONS ------------------
    st.markdown("### **Step 4 — Professor's Verbal Hints & Constraints**")
    verbal_instructions = st.text_area(
        f"Enter teacher's verbal topics or excluded chapters for {subject_info.get('title') if subject_info else 'Course'}:",
        placeholder="e.g., 'Focus strictly on A* Search, Minimax with Alpha-Beta Pruning, and Neural Networks. No numericals from Chapter 4.'",
        height=85
    )

    # ------------------ STEP 5: GENERATE BUTTON ------------------
    st.markdown("### **Step 5 — Generate Practice Paper**")
    
    generate_disabled = not is_valid
    if st.button("🚀 Generate AI Practice Exam Paper", type="primary", use_container_width=True, disabled=generate_disabled):
        with st.status("🧠 Synthesizing Practice Paper...", expanded=True) as status:
            st.write("📖 Reading and parsing uploaded course documents...")
            parsed_materials = {}
            total_chars = 0
            failed_files = []
            
            for cat, files in uploaded_files_map.items():
                parsed_materials[cat] = []
                for f in files:
                    try:
                        doc = DocumentParser.parse_uploaded_file(f)
                        parsed_materials[cat].append(doc)
                        total_chars += doc.get("char_count", 0)
                    except Exception as parse_err:
                        failed_files.append((getattr(f, "name", "file"), str(parse_err)))

            st.session_state.parsed_materials_cache = parsed_materials

            if failed_files:
                st.warning(f"⚠️ {len(failed_files)} file(s) failed parsing: " + ", ".join([f"{fn} ({err})" for fn, err in failed_files]))

            st.write("📊 Analyzing topic weightages and document context...")
            material_analysis = MaterialAnalyzer.extract_topic_weightages(parsed_materials, subject_info)
            past_docs = parsed_materials.get("past_papers", []) + parsed_materials.get("midterms", [])
            quiz_docs = parsed_materials.get("quizzes", [])
            style_analysis = MaterialAnalyzer.analyze_past_paper_patterns(past_docs, quiz_docs)
            document_context = DocumentParser.build_prompt_material_context(parsed_materials)

            st.write("🎯 Synthesizing university-standard questions aligned with HEC CLOs...")
            pattern_dict = {
                "total_marks": int(total_marks),
                "mcq_count": int(mcq_count),
                "mcq_marks_each": float(mcq_marks),
                "short_count": int(short_count),
                "short_marks_each": float(short_marks),
                "long_count": int(long_count),
                "long_marks_each": float(long_marks),
                "tf_count": int(tf_count),
                "tf_marks_each": float(tf_marks)
            }

            provider_key = "gemini" if "Gemini" in llm_provider else ("groq" if "Groq" in llm_provider else "offline")
            generator = ExamGenerator(
                gemini_api_key=api_key if provider_key == "gemini" else None,
                groq_api_key=api_key if provider_key == "groq" else None
            )

            try:
                paper_result = generator.generate_exam_paper(
                    subject_slug=selected_slug,
                    exam_type=exam_type,
                    pattern=pattern_dict,
                    verbal_instructions=verbal_instructions,
                    uploaded_summary=f"Processed {total_uploaded} files ({total_chars} characters)",
                    material_analysis=material_analysis,
                    style_analysis=style_analysis,
                    document_context=document_context,
                    rigor_level=rigor_level,
                    university_header=university_header,
                    llm_provider=provider_key
                )

                # Persist to database
                paper_uid = save_paper(
                    subject_slug=selected_slug,
                    subject_title=subject_info.get("title", selected_slug),
                    exam_type=exam_type,
                    total_marks=pattern_dict["total_marks"],
                    pattern=pattern_dict,
                    verbal_instructions=verbal_instructions,
                    uploaded_files_summary=f"{total_uploaded} files parsed ({total_chars} chars)",
                    paper_content=paper_result,
                    solution_content=paper_result.get("marking_scheme_and_solutions", {}),
                    analysis_summary=paper_result.get("pattern_analysis_summary", "")
                )

                st.session_state.generated_paper = paper_result
                st.session_state.current_paper_uid = paper_uid
                status.update(label="✅ Exam Paper Generated Successfully!", state="complete", expanded=False)
                st.rerun()

            except Exception as e:
                status.update(label=f"❌ Error during generation: {e}", state="error")
                st.error(f"Generation Failed: {e}")


# ---------------------------------------------------------
# RIGHT COLUMN: RESULTS SUITE & MULTI-FORMAT EXPORT
# ---------------------------------------------------------
with col_output:
    if not st.session_state.generated_paper:
        st.info("👈 Configure your exam parameters on the left and click **Generate AI Practice Exam Paper** to preview the full examination paper, model solutions, and CLO matrix.")
    else:
        paper = st.session_state.generated_paper
        meta = paper.get("metadata", {})

        # Top Action Ribbon
        st.markdown(f"### 📋 **{meta.get('subject')} — {meta.get('exam_type')} Examination**")
        
        col_exp1, col_exp2, col_exp3 = st.columns([1, 1, 1])
        with col_exp1:
            pdf_bytes = generate_exam_pdf(paper, include_solutions=True)
            st.download_button(
                label="📥 Download PDF",
                data=pdf_bytes,
                file_name=f"{meta.get('subject', 'Exam')}_{meta.get('exam_type', 'Terminal')}_Paper.pdf".replace(" ", "_"),
                mime="application/pdf",
                use_container_width=True
            )
        with col_exp2:
            docx_bytes = generate_exam_docx(paper, include_solutions=True)
            st.download_button(
                label="📄 Download Word (.docx)",
                data=docx_bytes,
                file_name=f"{meta.get('subject', 'Exam')}_{meta.get('exam_type', 'Terminal')}_Paper.docx".replace(" ", "_"),
                mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                use_container_width=True
            )
        with col_exp3:
            plain_txt = format_paper_as_text(paper, include_solutions=True)
            st.download_button(
                label="📝 Download Text (.txt)",
                data=plain_txt,
                file_name=f"{meta.get('subject', 'Exam')}_Paper.txt".replace(" ", "_"),
                mime="text/plain",
                use_container_width=True
            )

        # Tabbed Viewer
        tab_paper, tab_sol, tab_matrix, tab_pattern = st.tabs([
            "📄 Practice Exam Paper",
            "🔑 Model Solutions & Rubrics",
            "🎯 CLO-PLO Attainment Matrix",
            "📊 Style & Pattern Analytics"
        ])

        with tab_paper:
            st.markdown(f"""
            <div style="text-align: center; border-bottom: 2px solid #1E3A8A; padding-bottom: 8px; margin-bottom: 12px;">
                <h3 style="margin: 0; color: #1E3A8A;">{meta.get('university_header', 'DEPARTMENT OF COMPUTER SCIENCE')}</h3>
                <h4 style="margin: 4px 0; color: #374151;">{meta.get('subject')} ({meta.get('course_code')}) — {meta.get('exam_type')} Examination</h4>
                <p style="margin: 0; font-size: 0.9rem; color: #6B7280;"><b>Time Allowed:</b> {meta.get('time_allowed', '2.5 Hours')} &nbsp;|&nbsp; <b>Total Marks:</b> {meta.get('total_marks', 50)} Marks</p>
            </div>
            """, unsafe_allow_html=True)
            
            st.markdown(f"**General Instructions:** {' | '.join(meta.get('instructions', []))}")
            st.markdown("---")

            # Section A: MCQs
            mcqs = paper.get("section_a_mcqs", [])
            if mcqs:
                st.markdown(f"#### **SECTION A: Multiple Choice Questions [{sum(q.get('marks', 1) for q in mcqs):g} Marks]**")
                for q in mcqs:
                    st.markdown(f"**Q{q.get('q_number')}.** {q.get('question')} &nbsp;&nbsp; <span class='tag-badge'>{q.get('clo')}</span> <span class='blooms-badge'>{q.get('blooms')}</span> *[{q.get('marks')} Mark]*", unsafe_allow_html=True)
                    opts = q.get("options", [])
                    c1, c2 = st.columns(2)
                    for idx, opt in enumerate(opts):
                        if idx % 2 == 0:
                            c1.markdown(f"&nbsp;&nbsp;&nbsp;&nbsp;{opt}")
                        else:
                            c2.markdown(f"&nbsp;&nbsp;&nbsp;&nbsp;{opt}")
                    st.write("")

            # Section A (Part 2): True / False
            tf_list = paper.get("section_a_tf", [])
            if tf_list:
                st.markdown(f"#### **SECTION A (Part II): True / False Questions [{sum(q.get('marks', 1) for q in tf_list):g} Marks]**")
                for q in tf_list:
                    st.markdown(f"**{q.get('q_number')}.** [ &nbsp; ] {q.get('statement')} &nbsp;&nbsp; <span class='tag-badge'>{q.get('clo')}</span> *[{q.get('marks')} Mark]*", unsafe_allow_html=True)
                st.write("")

            # Section B: Short Questions
            short_qs = paper.get("section_b_short", [])
            if short_qs:
                st.markdown(f"#### **SECTION B: Short Answer & Analytical Questions [{sum(q.get('marks', 5) for q in short_qs):g} Marks]**")
                for q in short_qs:
                    plo_tags = " ".join([f"<span class='tag-badge'>{p}</span>" for p in q.get("mapped_plos", [])])
                    st.markdown(f"""
                    <div class="step-card">
                        <b>Q{q.get('q_number')}.</b> {q.get('question')}<br/>
                        <b>Marks:</b> [{q.get('marks')} Marks] &nbsp;|&nbsp;
                        <span class='tag-badge'>{q.get('clo')}</span> <span class='blooms-badge'>{q.get('blooms')}</span> {plo_tags}
                    </div>
                    """, unsafe_allow_html=True)

            # Section C: Long Questions
            long_qs = paper.get("section_c_long", [])
            if long_qs:
                st.markdown(f"#### **SECTION C: Long / Comprehensive / Design Questions [{sum(q.get('marks', 10) for q in long_qs):g} Marks]**")
                for q in long_qs:
                    plo_tags = " ".join([f"<span class='tag-badge'>{p}</span>" for p in q.get("mapped_plos", [])])
                    st.markdown(f"""
                    <div class="step-card" style="border-left: 4px solid #1E3A8A;">
                        <b>Q{q.get('q_number')}.</b> {q.get('question').replace(chr(10), '<br/>')}<br/><br/>
                        <b>Allocation:</b> [{q.get('marks')} Marks] &nbsp;|&nbsp;
                        <span class='tag-badge'>{q.get('clo')}</span> <span class='blooms-badge'>{q.get('blooms')}</span> {plo_tags}
                    </div>
                    """, unsafe_allow_html=True)

        with tab_sol:
            st.markdown("### 🔑 Official Model Solutions & Step-by-Step Marking Rubric")
            sol = paper.get("marking_scheme_and_solutions", {})
            
            if sol.get("mcq_solutions"):
                st.markdown("#### 1. MCQ Answer Key & Technical Explanations")
                for s in sol["mcq_solutions"]:
                    st.markdown(f"- **Q{s.get('q_number')}:** Option **[{s.get('correct_option')}]** — {s.get('explanation')}")
                st.write("")

            if sol.get("tf_solutions"):
                st.markdown("#### 2. True / False Answer Key")
                for s in sol["tf_solutions"]:
                    st.markdown(f"- **{s.get('q_number')}:** [{s.get('correct_value')}] — {s.get('explanation')}")
                st.write("")

            if sol.get("short_solutions"):
                st.markdown("#### 3. Section B Model Solutions & Marking Rubrics")
                for s in sol["short_solutions"]:
                    with st.expander(f"Q{s.get('q_number')} Model Answer & Rubric", expanded=True):
                        st.markdown(f"**Model Answer:**\n{s.get('model_answer')}")
                        st.info(f"**Marking Rubric:** {s.get('rubric')}")

            if sol.get("long_solutions"):
                st.markdown("#### 4. Section C Comprehensive Solutions & Rubrics")
                for s in sol["long_solutions"]:
                    with st.expander(f"Q{s.get('q_number')} Comprehensive Solution & Rubric", expanded=True):
                        st.markdown(f"**Comprehensive Solution:**\n{s.get('model_answer')}")
                        st.success(f"**Step-wise Rubric Breakdown:** {s.get('rubric')}")

        with tab_matrix:
            st.markdown("### 🎯 CLO / PLO Attainment & Bloom's Taxonomy Matrix")
            
            audit = ExamPatternValidator.validate_clo_alignment(paper, subject_info)
            if audit.get("all_verified"):
                st.success(f"✅ Verified: All {audit.get('total_questions_audited')} questions strictly match official HEC curriculum CLOs.")
            else:
                st.warning("⚠️ Some questions have custom or non-standard CLO mappings.")

            matrix_rows = []
            for item in audit.get("verification_results", []):
                matrix_rows.append({
                    "Section": item["section"],
                    "Question #": f"Q{item['q_number']}",
                    "Marks": item["marks"],
                    "Target CLO": item["clo"],
                    "Bloom's Taxonomy": item["blooms"],
                    "Mapped PLOs": ", ".join(item["mapped_plos"])
                })

            df_matrix = pd.DataFrame(matrix_rows)
            st.dataframe(df_matrix, use_container_width=True, hide_index=True)

        with tab_pattern:
            st.markdown("### 📊 Professor Assessment Style & Pattern Analysis")
            summary_text = paper.get("pattern_analysis_summary", "Standard HEC Academic format.")
            st.success(f"**Pattern Insight:** {summary_text}")
            
            st.markdown("#### Calibration Standards:")
            st.markdown("""
            - **Curriculum Guardrail:** Bounded within prescribed BSCS learning outcomes.
            - **Cognitive Balance:** Spans Bloom's levels (Understand, Apply, Analyze, Design).
            - **Synthesized Novelty:** Novel scenarios synthesized without copying verbatim past paper prompts.
            - **Point Balancing:** Question point distribution equals target exam marks.
            """)
