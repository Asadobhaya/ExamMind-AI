import os
import sys
from pathlib import Path
from PIL import Image, ImageDraw

ROOT_DIR = Path(__file__).resolve().parent
ASSETS_DIR = ROOT_DIR / "assets"
ASSETS_DIR.mkdir(exist_ok=True)
ICON_PATH = ASSETS_DIR / "app_icon.ico"


def create_app_icon():
    """Generates a modern, high-res graduation cap / exam app icon."""
    size = (256, 256)
    img = Image.new("RGBA", size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Draw rounded dark blue gradient-like background
    draw.rounded_rectangle([(16, 16), (240, 240)], radius=48, fill=(15, 23, 42, 255), outline=(59, 130, 246, 255), width=6)

    # Draw Graduation Cap / Exam Icon in vibrant blue & emerald
    # Cap Diamond
    cap_points = [(128, 64), (208, 104), (128, 144), (48, 104)]
    draw.polygon(cap_points, fill=(37, 99, 235, 255), outline=(96, 165, 250, 255))

    # Cap Skullcap / Lower Arc
    draw.polygon([(80, 120), (176, 120), (176, 148), (128, 172), (80, 148)], fill=(30, 64, 175, 255), outline=(96, 165, 250, 255))

    # Tassel
    draw.line([(208, 104), (218, 140), (218, 170)], fill=(245, 158, 11, 255), width=5)
    draw.ellipse([(212, 165), (224, 177)], fill=(245, 158, 11, 255))

    # Star / AI Sparkle Badge in bottom-left
    draw.polygon([(60, 180), (66, 160), (86, 154), (66, 148), (60, 128), (54, 148), (34, 154), (54, 160)], fill=(16, 185, 129, 255))

    # Save multi-size .ico
    img.save(ICON_PATH, format="ICO", sizes=[(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (16, 16)])
    print(f"Icon generated at: {ICON_PATH}")
    return ICON_PATH


def create_windows_desktop_shortcut():
    """Creates a native Windows Desktop shortcut (.lnk) linking to pythonw.exe."""
    icon_path = create_app_icon()
    desktop = Path(os.path.expanduser("~")) / "Desktop"
    shortcut_path = desktop / "ExamMind AI.lnk"

    pythonw_exe = Path(sys.executable).parent / "pythonw.exe"
    if not pythonw_exe.exists():
        pythonw_exe = Path(sys.executable)

    main_script = ROOT_DIR / "main.py"
    work_dir = str(ROOT_DIR)

    # PowerShell command to create Windows shortcut
    ps_command = f"""
    $WshShell = New-Object -ComObject WScript.Shell
    $Shortcut = $WshShell.CreateShortcut('{str(shortcut_path)}')
    $Shortcut.TargetPath = '{str(pythonw_exe)}'
    $Shortcut.Arguments = '"{str(main_script)}"'
    $Shortcut.WorkingDirectory = '{work_dir}'
    $Shortcut.IconLocation = '{str(icon_path)}, 0'
    $Shortcut.Description = 'ExamMind AI — Autonomous HEC Pakistan BSCS Practice Paper Generator'
    $Shortcut.Save()
    """

    import subprocess
    result = subprocess.run(["powershell", "-NoProfile", "-Command", ps_command], capture_output=True, text=True)
    if result.returncode == 0:
        print(f"Successfully created Windows Desktop shortcut: {shortcut_path}")
    else:
        print(f"PowerShell error creating shortcut: {result.stderr}")


if __name__ == "__main__":
    create_windows_desktop_shortcut()
