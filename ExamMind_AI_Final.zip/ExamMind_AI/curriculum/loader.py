import json
import os
from typing import Dict, List, Optional, Any
from pathlib import Path

CURRICULUM_DIR = Path(__file__).resolve().parent
SUBJECTS_DIR = CURRICULUM_DIR / "subjects"
PLOS_FILE = CURRICULUM_DIR / "plos.json"


class CurriculumRepository:
    def __init__(self):
        self._plos_cache: Optional[Dict[str, Any]] = None
        self._subjects_cache: Dict[str, Dict[str, Any]] = {}
        self._load_all()

    def _load_all(self):
        # Load PLOs
        if PLOS_FILE.exists():
            with open(PLOS_FILE, "r", encoding="utf-8") as f:
                self._plos_cache = json.load(f)
        else:
            self._plos_cache = {"plos": []}

        # Load Subjects
        if SUBJECTS_DIR.exists():
            for filepath in SUBJECTS_DIR.glob("*.json"):
                try:
                    with open(filepath, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        key = filepath.stem
                        self._subjects_cache[key] = data
                except Exception as e:
                    print(f"Error loading {filepath}: {e}")

    def get_plos(self) -> List[Dict[str, Any]]:
        return self._plos_cache.get("plos", []) if self._plos_cache else []

    def get_plo_map(self) -> Dict[str, Dict[str, Any]]:
        return {p["id"]: p for p in self.get_plos()}

    def get_subjects_list(self) -> List[Dict[str, Any]]:
        """Returns sorted list of subjects with slug, title, and code."""
        items = []
        for slug, data in self._subjects_cache.items():
            items.append({
                "slug": slug,
                "title": data.get("title", slug),
                "code": data.get("code", ""),
                "category": data.get("category", "Major"),
                "credit_hours": data.get("credit_hours", "3+0"),
                "clo_count": len(data.get("clos", []))
            })
        return sorted(items, key=lambda x: (0 if "Compulsory" in x["category"] else 1, x["title"]))

    def get_subject_by_slug(self, slug: str) -> Optional[Dict[str, Any]]:
        return self._subjects_cache.get(slug)

    def get_subject_by_title(self, title: str) -> Optional[Dict[str, Any]]:
        for slug, data in self._subjects_cache.items():
            if data.get("title", "").strip().lower() == title.strip().lower():
                return data
        return None

    def validate_clo(self, subject_slug: str, clo_id: str) -> bool:
        subj = self.get_subject_by_slug(subject_slug)
        if not subj:
            return False
        return any(clo.get("id") == clo_id for clo in subj.get("clos", []))


# Global singleton instance
curriculum_repo = CurriculumRepository()
