import sqlite3
import json
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any

DB_PATH = Path(__file__).resolve().parent / "exammind.db"


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS papers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            paper_uid TEXT UNIQUE NOT NULL,
            subject_slug TEXT NOT NULL,
            subject_title TEXT NOT NULL,
            exam_type TEXT NOT NULL,
            total_marks INTEGER NOT NULL,
            pattern_json TEXT NOT NULL,
            verbal_instructions TEXT,
            uploaded_files_summary TEXT,
            paper_content TEXT NOT NULL,
            solution_content TEXT NOT NULL,
            analysis_summary TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()


def save_paper(
    subject_slug: str,
    subject_title: str,
    exam_type: str,
    total_marks: int,
    pattern: Dict[str, Any],
    verbal_instructions: str,
    uploaded_files_summary: str,
    paper_content: Dict[str, Any],
    solution_content: Dict[str, Any],
    analysis_summary: str
) -> str:
    init_db()
    conn = get_connection()
    cursor = conn.cursor()
    paper_uid = str(uuid.uuid4())
    
    cursor.execute("""
        INSERT INTO papers (
            paper_uid, subject_slug, subject_title, exam_type, total_marks,
            pattern_json, verbal_instructions, uploaded_files_summary,
            paper_content, solution_content, analysis_summary, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        paper_uid,
        subject_slug,
        subject_title,
        exam_type,
        total_marks,
        json.dumps(pattern),
        verbal_instructions,
        uploaded_files_summary,
        json.dumps(paper_content),
        json.dumps(solution_content),
        analysis_summary,
        datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ))
    
    conn.commit()
    conn.close()
    return paper_uid


def get_all_papers() -> List[Dict[str, Any]]:
    init_db()
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, paper_uid, subject_slug, subject_title, exam_type, total_marks, created_at FROM papers ORDER BY id DESC")
    rows = cursor.fetchall()
    results = [dict(row) for row in rows]
    conn.close()
    return results


def get_paper_by_uid(paper_uid: str) -> Optional[Dict[str, Any]]:
    init_db()
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM papers WHERE paper_uid = ?", (paper_uid,))
    row = cursor.fetchone()
    conn.close()
    if not row:
        return None
    d = dict(row)
    d["pattern_json"] = json.loads(d["pattern_json"])
    d["paper_content"] = json.loads(d["paper_content"])
    d["solution_content"] = json.loads(d["solution_content"])
    return d


def delete_paper(paper_uid: str) -> bool:
    init_db()
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM papers WHERE paper_uid = ?", (paper_uid,))
    changes = conn.total_changes
    conn.commit()
    conn.close()
    return changes > 0


# Ensure database is initialized on import
init_db()
