import os
import sys
import json
import time
import tkinter as tk
from tkinter import filedialog, messagebox
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path

import customtkinter as ctk

# Robust .env loading with fallback to _env
ENV_FILE = Path(__file__).resolve().parent / ".env"
if not ENV_FILE.exists():
    ENV_FILE = Path(__file__).resolve().parent / "_env"

def load_environment_file():
    if ENV_FILE.exists():
        try:
            with open(ENV_FILE, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        k, v = line.split("=", 1)
                        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
        except (OSError, IOError) as e:
            print(f"Warning: Could not read environment file {ENV_FILE}: {e}")

load_environment_file()

from curriculum.loader import curriculum_repo
from engine.validator import ExamPatternValidator
from engine.parser import DocumentParser
from engine.analyzer import MaterialAnalyzer
from engine.generator import ExamGenerator
from engine.grader import ExamGrader
from engine.pdf_export import generate_exam_pdf, format_paper_as_text
from engine.docx_export import generate_exam_docx
from database.db import save_paper, get_all_papers, get_paper_by_uid, delete_paper

THEME = {
    "bg_dark": "#0B0F19",
    "card_dark": "#111827",
    "card_border": "#1F2937",
    "accent_blue": "#3B82F6",
    "accent_blue_hover": "#2563EB",
    "accent_emerald": "#10B981",
    "accent_purple": "#8B5CF6",
    "text_primary": "#F9FAFB",
    "text_secondary": "#9CA3AF",
    "text_muted": "#6B7280",
    "danger": "#EF4444",
    "warning": "#F59E0B",
    "success_bg": "#064E3B",
    "success_text": "#6EE7B7",
    "error_bg": "#7F1D1D",
    "error_text": "#FCA5A5"
}

UNIVERSITY_PRESETS = {
    "General HEC University Standard": "Department of Computer Science — Examination Paper",
    "Institute of Space Technology (IST) Islamabad": "Institute of Space Technology (IST) Islamabad — Department of Computer Science",
    "FAST-NUCES (High Coding & Tracing Rigor)": "FAST National University of Computer and Emerging Sciences — Department of Computer Science",
    "NUST - SEECS (Analytical & Scenario Modeling)": "National University of Sciences and Technology (NUST) — SEECS",
    "COMSATS University Islamabad": "COMSATS University Islamabad — Department of Computer Science",
    "PUCIT / Punjab University": "Punjab University College of Information Technology (PUCIT)",
    "UET Lahore / Taxila": "University of Engineering and Technology (UET) — Department of CS",
    "GIKI (Top Engineering Standard)": "Ghulam Ishaq Khan Institute of Engineering Sciences and Technology (GIKI)",
    "IBA Karachi / Karachi University": "Institute of Business Administration (IBA) Karachi — CS Department",
    "Air University Islamabad": "Air University Islamabad — Faculty of Computing & AI",
    "Bahria University": "Bahria University — Department of Computer Science"
}

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")


class ModernExamMindApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        # Window Configuration
        self.title("ExamMind AI — Autonomous HEC Pakistan BSCS Practice Paper & Grading Suite")
        self.geometry("1420x920")
        self.minsize(1150, 780)
        self.configure(fg_color=THEME["bg_dark"])

        # Window Icon
        icon_path = Path(__file__).resolve().parent / "assets" / "app_icon.ico"
        if icon_path.exists():
            try:
                self.iconbitmap(str(icon_path))
            except Exception:
                pass

        # State Management
        self.selected_files = {
            "slides": [],
            "quizzes": [],
            "assignments": [],
            "past_papers": []
        }
        self.extracted_materials_cache = {}
        self.current_paper_data: Optional[Dict[str, Any]] = None
        self.current_paper_uid: Optional[str] = None
        self.is_generating = False
        self.is_grading = False

        # Mock Exam Timer State (Tkinter after loop)
        self.mock_inputs = {}
        self.mock_timer_seconds = 0
        self.mock_timer_running = False
        self._timer_job = None

        # Load Subjects & PLOs
        self.subjects = curriculum_repo.get_subjects_list()
        self.subject_map = {f"{s['title']} ({s['code']})": s['slug'] for s in self.subjects}

        # Clean Exit Protocol
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        # Build Interactive Dashboard Layout
        self._build_dashboard()

    def _on_close(self):
        if self._timer_job:
            self.after_cancel(self._timer_job)
        self.destroy()
        sys.exit(0)

    def _build_dashboard(self):
        self.grid_columnconfigure(0, weight=4, minsize=440)
        self.grid_columnconfigure(1, weight=6, minsize=680)
        self.grid_rowconfigure(0, weight=1)

        # =========================================================================
        # LEFT PANE: Smart Parameter Studio & File Manager
        # =========================================================================
        left_container = ctk.CTkFrame(self, fg_color=THEME["card_dark"], corner_radius=14, border_width=1, border_color=THEME["card_border"])
        left_container.grid(row=0, column=0, padx=(14, 7), pady=14, sticky="nsew")
        left_container.grid_rowconfigure(1, weight=1)
        left_container.grid_columnconfigure(0, weight=1)

        # 1. Top Brand Header & API Settings Bar
        header_bar = ctk.CTkFrame(left_container, fg_color="transparent")
        header_bar.grid(row=0, column=0, padx=16, pady=(14, 6), sticky="ew")

        brand_badge = ctk.CTkLabel(
            header_bar,
            text="🎓 ExamMind AI",
            font=ctk.CTkFont(size=20, weight="bold"),
            text_color="#60A5FA"
        )
        brand_badge.pack(side="left")

        btn_settings = ctk.CTkButton(
            header_bar,
            text="🔑 API Keys",
            width=80,
            height=26,
            font=ctk.CTkFont(size=11, weight="bold"),
            fg_color="#1E3A8A",
            hover_color="#2563EB",
            command=self._open_api_key_dialog
        )
        btn_settings.pack(side="right", padx=(4, 0))

        status_pill = ctk.CTkLabel(
            header_bar,
            text="● HEC 2025/2026",
            font=ctk.CTkFont(size=10, weight="bold"),
            fg_color="#1E293B",
            text_color="#93C5FD",
            corner_radius=10,
            padx=8,
            pady=2
        )
        status_pill.pack(side="right")

        # 2. Scrollable Configuration Form
        form_scroll = ctk.CTkScrollableFrame(left_container, fg_color="transparent")
        form_scroll.grid(row=1, column=0, padx=10, pady=(0, 10), sticky="nsew")

        # --- QUICK PRESETS BAR ---
        preset_frame = ctk.CTkFrame(form_scroll, fg_color="#1E293B", corner_radius=8)
        preset_frame.pack(fill="x", pady=(0, 8), padx=4)

        ctk.CTkLabel(preset_frame, text="⚡ Quick Exam Presets:", font=ctk.CTkFont(size=11, weight="bold"), text_color="#94A3B8").pack(anchor="w", padx=10, pady=(6, 2))
        
        p_btn_row = ctk.CTkFrame(preset_frame, fg_color="transparent")
        p_btn_row.pack(fill="x", padx=6, pady=(0, 6))
        p_btn_row.columnconfigure((0, 1, 2, 3), weight=1)

        ctk.CTkButton(p_btn_row, text="Mid 30M", height=24, font=ctk.CTkFont(size=10), fg_color="#334155", hover_color="#475569", command=lambda: self._apply_preset(30, 5, 1, 3, 5, 1, 10)).grid(row=0, column=0, padx=2, sticky="ew")
        ctk.CTkButton(p_btn_row, text="Mid 50M", height=24, font=ctk.CTkFont(size=10), fg_color="#334155", hover_color="#475569", command=lambda: self._apply_preset(50, 10, 1, 4, 5, 2, 10)).grid(row=0, column=1, padx=2, sticky="ew")
        ctk.CTkButton(p_btn_row, text="Final 80M", height=24, font=ctk.CTkFont(size=10), fg_color="#334155", hover_color="#475569", command=lambda: self._apply_preset(80, 20, 1, 6, 5, 3, 10)).grid(row=0, column=2, padx=2, sticky="ew")
        ctk.CTkButton(p_btn_row, text="Final 100M", height=24, font=ctk.CTkFont(size=10), fg_color="#334155", hover_color="#475569", command=lambda: self._apply_preset(100, 20, 1, 8, 5, 4, 10)).grid(row=0, column=3, padx=2, sticky="ew")

        # --- STEP 1: SUBJECT & UNIVERSITY PROFILE ---
        s1_card = self._create_section_card(form_scroll, "1. Course & University Target")
        
        self.subject_var = ctk.StringVar(value=list(self.subject_map.keys())[0])
        self.subject_combo = ctk.CTkComboBox(
            s1_card,
            values=list(self.subject_map.keys()),
            variable=self.subject_var,
            height=32,
            dropdown_font=ctk.CTkFont(size=11),
            command=self._on_subject_changed
        )
        self.subject_combo.pack(fill="x", padx=10, pady=(4, 4))

        ctk.CTkLabel(s1_card, text="Target University Profile & Rigor:", font=ctk.CTkFont(size=10, weight="bold"), text_color="#94A3B8").pack(anchor="w", padx=10, pady=(2, 0))
        self.uni_var = ctk.StringVar(value=list(UNIVERSITY_PRESETS.keys())[0])
        self.uni_combo = ctk.CTkComboBox(
            s1_card,
            values=list(UNIVERSITY_PRESETS.keys()),
            variable=self.uni_var,
            height=30,
            dropdown_font=ctk.CTkFont(size=10)
        )
        self.uni_combo.pack(fill="x", padx=10, pady=(2, 6))

        r_frame = ctk.CTkFrame(s1_card, fg_color="transparent")
        r_frame.pack(fill="x", padx=10, pady=(0, 6))
        ctk.CTkLabel(r_frame, text="Rigor Level:", font=ctk.CTkFont(size=10, weight="bold"), text_color="#94A3B8").pack(side="left")
        self.rigor_var = ctk.StringVar(value="Standard HEC")
        self.rigor_seg = ctk.CTkSegmentedButton(r_frame, values=["Foundational", "Standard HEC", "High Rigor (FAST-Style)"], variable=self.rigor_var, height=24)
        self.rigor_seg.pack(side="right")

        self.btn_inspect_clo = ctk.CTkButton(
            s1_card,
            text="🔍 Inspect Official HEC CLOs & Mapped PLOs",
            fg_color="#1E3A8A",
            hover_color="#2563EB",
            height=26,
            font=ctk.CTkFont(size=11, weight="bold"),
            command=self._show_clo_inspector
        )
        self.btn_inspect_clo.pack(fill="x", padx=10, pady=(0, 8))

        # --- STEP 2: EXAM SCOPE & FILE ATTACHMENTS ---
        s2_card = self._create_section_card(form_scroll, "2. Exam Scope & Material Ingestion")

        self.exam_type_var = ctk.StringVar(value="Midterm")
        self.type_seg = ctk.CTkSegmentedButton(
            s2_card,
            values=["Midterm", "Final"],
            variable=self.exam_type_var,
            height=28
        )
        self.type_seg.pack(fill="x", padx=10, pady=(4, 8))

        # Upload Grid
        f_grid = ctk.CTkFrame(s2_card, fg_color="transparent")
        f_grid.pack(fill="x", padx=10, pady=(0, 6))
        f_grid.columnconfigure((0, 1), weight=1)

        self.btn_slides = ctk.CTkButton(f_grid, text="📄 Slides/Notes (0)", height=30, fg_color="#1E293B", hover_color="#334155", command=lambda: self._select_files("slides"))
        self.btn_slides.grid(row=0, column=0, padx=(0, 3), pady=3, sticky="ew")

        self.btn_quizzes = ctk.CTkButton(f_grid, text="📝 Quizzes (0)", height=30, fg_color="#1E293B", hover_color="#334155", command=lambda: self._select_files("quizzes"))
        self.btn_quizzes.grid(row=0, column=1, padx=(3, 0), pady=3, sticky="ew")

        self.btn_assign = ctk.CTkButton(f_grid, text="📂 Assignments (0)", height=30, fg_color="#1E293B", hover_color="#334155", command=lambda: self._select_files("assignments"))
        self.btn_assign.grid(row=1, column=0, padx=(0, 3), pady=3, sticky="ew")

        self.btn_past = ctk.CTkButton(f_grid, text="📜 Past Papers (0)", height=30, fg_color="#1E293B", hover_color="#334155", command=lambda: self._select_files("past_papers"))
        self.btn_past.grid(row=1, column=1, padx=(3, 0), pady=3, sticky="ew")

        self.lbl_file_stats = ctk.CTkLabel(s2_card, text="💡 Upload slides/quizzes to inject custom topics directly into the exam.", font=ctk.CTkFont(size=10), text_color="#94A3B8")
        self.lbl_file_stats.pack(anchor="w", padx=10, pady=(0, 6))

        # --- STEP 3: PATTERN INPUT & LIVE VALIDATION GAUGE ---
        s3_card = self._create_section_card(form_scroll, "3. Paper Pattern & Marks Allocation")

        tot_row = ctk.CTkFrame(s3_card, fg_color="transparent")
        tot_row.pack(fill="x", padx=10, pady=(4, 6))
        ctk.CTkLabel(tot_row, text="Total Exam Marks:", font=ctk.CTkFont(weight="bold")).pack(side="left")
        self.ent_total = ctk.CTkEntry(tot_row, width=80, height=28, font=ctk.CTkFont(size=12, weight="bold"))
        self.ent_total.insert(0, "50")
        self.ent_total.pack(side="right")
        self.ent_total.bind("<KeyRelease>", lambda e: self._update_pattern_calc())

        # Pattern Grid
        p_table = ctk.CTkFrame(s3_card, fg_color="#1E293B", corner_radius=6)
        p_table.pack(fill="x", padx=10, pady=(0, 8))
        p_table.columnconfigure((0, 1, 2, 3), weight=1)

        ctk.CTkLabel(p_table, text="Section Type", font=ctk.CTkFont(size=10, weight="bold"), text_color="#94A3B8").grid(row=0, column=0, padx=6, pady=4, sticky="w")
        ctk.CTkLabel(p_table, text="Count", font=ctk.CTkFont(size=10, weight="bold"), text_color="#94A3B8").grid(row=0, column=1, padx=4, pady=4)
        ctk.CTkLabel(p_table, text="Marks/Q", font=ctk.CTkFont(size=10, weight="bold"), text_color="#94A3B8").grid(row=0, column=2, padx=4, pady=4)
        ctk.CTkLabel(p_table, text="Total", font=ctk.CTkFont(size=10, weight="bold"), text_color="#94A3B8").grid(row=0, column=3, padx=6, pady=4, sticky="e")

        # Row 1: MCQs
        ctk.CTkLabel(p_table, text="A: MCQs", font=ctk.CTkFont(size=11)).grid(row=1, column=0, padx=6, pady=3, sticky="w")
        self.ent_mcq_c = ctk.CTkEntry(p_table, width=45, height=24)
        self.ent_mcq_c.insert(0, "10")
        self.ent_mcq_c.grid(row=1, column=1, pady=3)
        self.ent_mcq_c.bind("<KeyRelease>", lambda e: self._update_pattern_calc())

        self.ent_mcq_m = ctk.CTkEntry(p_table, width=45, height=24)
        self.ent_mcq_m.insert(0, "1")
        self.ent_mcq_m.grid(row=1, column=2, pady=3)
        self.ent_mcq_m.bind("<KeyRelease>", lambda e: self._update_pattern_calc())

        self.lbl_mcq_val = ctk.CTkLabel(p_table, text="10 M", font=ctk.CTkFont(size=11, weight="bold"), text_color="#60A5FA")
        self.lbl_mcq_val.grid(row=1, column=3, padx=6, pady=3, sticky="e")

        # Row 2: Short Questions
        ctk.CTkLabel(p_table, text="B: Short Qs", font=ctk.CTkFont(size=11)).grid(row=2, column=0, padx=6, pady=3, sticky="w")
        self.ent_short_c = ctk.CTkEntry(p_table, width=45, height=24)
        self.ent_short_c.insert(0, "4")
        self.ent_short_c.grid(row=2, column=1, pady=3)
        self.ent_short_c.bind("<KeyRelease>", lambda e: self._update_pattern_calc())

        self.ent_short_m = ctk.CTkEntry(p_table, width=45, height=24)
        self.ent_short_m.insert(0, "5")
        self.ent_short_m.grid(row=2, column=2, pady=3)
        self.ent_short_m.bind("<KeyRelease>", lambda e: self._update_pattern_calc())

        self.lbl_short_val = ctk.CTkLabel(p_table, text="20 M", font=ctk.CTkFont(size=11, weight="bold"), text_color="#34D399")
        self.lbl_short_val.grid(row=2, column=3, padx=6, pady=3, sticky="e")

        # Row 3: Long Questions
        ctk.CTkLabel(p_table, text="C: Long Qs", font=ctk.CTkFont(size=11)).grid(row=3, column=0, padx=6, pady=3, sticky="w")
        self.ent_long_c = ctk.CTkEntry(p_table, width=45, height=24)
        self.ent_long_c.insert(0, "2")
        self.ent_long_c.grid(row=3, column=1, pady=3)
        self.ent_long_c.bind("<KeyRelease>", lambda e: self._update_pattern_calc())

        self.ent_long_m = ctk.CTkEntry(p_table, width=45, height=24)
        self.ent_long_m.insert(0, "10")
        self.ent_long_m.grid(row=3, column=2, pady=3)
        self.ent_long_m.bind("<KeyRelease>", lambda e: self._update_pattern_calc())

        self.lbl_long_val = ctk.CTkLabel(p_table, text="20 M", font=ctk.CTkFont(size=11, weight="bold"), text_color="#A78BFA")
        self.lbl_long_val.grid(row=3, column=3, padx=6, pady=3, sticky="e")

        # Row 4: True / False
        ctk.CTkLabel(p_table, text="T/F Qs", font=ctk.CTkFont(size=11)).grid(row=4, column=0, padx=6, pady=3, sticky="w")
        self.ent_tf_c = ctk.CTkEntry(p_table, width=45, height=24)
        self.ent_tf_c.insert(0, "0")
        self.ent_tf_c.grid(row=4, column=1, pady=3)
        self.ent_tf_c.bind("<KeyRelease>", lambda e: self._update_pattern_calc())

        self.ent_tf_m = ctk.CTkEntry(p_table, width=45, height=24)
        self.ent_tf_m.insert(0, "1")
        self.ent_tf_m.grid(row=4, column=2, pady=3)
        self.ent_tf_m.bind("<KeyRelease>", lambda e: self._update_pattern_calc())

        self.lbl_tf_val = ctk.CTkLabel(p_table, text="0 M", font=ctk.CTkFont(size=11, weight="bold"), text_color="#FBBF24")
        self.lbl_tf_val.grid(row=4, column=3, padx=6, pady=3, sticky="e")

        # Real-time Mathematical Validation Banner
        self.badge_valid = ctk.CTkLabel(
            s3_card,
            text="✅ Valid Marks Equation: 10 + 20 + 20 = 50 Marks",
            fg_color=THEME["success_bg"],
            text_color=THEME["success_text"],
            corner_radius=6,
            height=30,
            font=ctk.CTkFont(size=11, weight="bold")
        )
        self.badge_valid.pack(fill="x", padx=10, pady=(0, 8))

        # --- STEP 4: VERBAL INSTRUCTIONS & NUDGES ---
        s4_card = self._create_section_card(form_scroll, "4. Professor's Verbal Hints & Constraints")

        self.lbl_verbal_info = ctk.CTkLabel(s4_card, text="Enter teacher's verbal topics, excluded chapters, or hints:", font=ctk.CTkFont(size=10), text_color="#94A3B8")
        self.lbl_verbal_info.pack(anchor="w", padx=10, pady=(2, 2))

        self.txt_verbal_hints = ctk.CTkTextbox(s4_card, height=75, font=ctk.CTkFont(size=11), fg_color="#1E293B")
        self.txt_verbal_hints.pack(fill="x", padx=10, pady=(2, 6))

        chips_bar = ctk.CTkFrame(s4_card, fg_color="transparent")
        chips_bar.pack(fill="x", padx=10, pady=(0, 8))
        chips_bar.columnconfigure((0, 1, 2), weight=1)
        ctk.CTkButton(chips_bar, text="+ 'Include Code'", height=22, font=ctk.CTkFont(size=10), fg_color="#334155", command=lambda: self._append_verbal("Include code implementation.")).grid(row=0, column=0, padx=(0, 2), sticky="ew")
        ctk.CTkButton(chips_bar, text="+ 'No Numericals'", height=22, font=ctk.CTkFont(size=10), fg_color="#334155", command=lambda: self._append_verbal("No numerical questions.")).grid(row=0, column=1, padx=2, sticky="ew")
        ctk.CTkButton(chips_bar, text="Clear", height=22, font=ctk.CTkFont(size=10), fg_color="#7F1D1D", hover_color="#991B1B", command=lambda: self.txt_verbal_hints.delete("1.0", "end")).grid(row=0, column=2, padx=(2, 0), sticky="ew")

        # --- STEP 5: ENGINE SELECTION ---
        s5_card = self._create_section_card(form_scroll, "5. AI Generation Engine")
        
        self.provider_choice = ctk.StringVar(value="Google Gemini Free Tier")
        self.combo_engine = ctk.CTkComboBox(
            s5_card,
            values=["Google Gemini Free Tier", "Offline Synthesizer (Instant / No Key)", "Groq Inference"],
            variable=self.provider_choice,
            height=30
        )
        self.combo_engine.pack(fill="x", padx=10, pady=(4, 8))

        # Launch Action Button
        self.btn_execute = ctk.CTkButton(
            form_scroll,
            text="🚀 Generate AI Practice Exam Paper",
            height=46,
            font=ctk.CTkFont(size=14, weight="bold"),
            fg_color=THEME["accent_blue"],
            hover_color=THEME["accent_blue_hover"],
            corner_radius=10,
            command=self._launch_generation
        )
        self.btn_execute.pack(fill="x", pady=(10, 4), padx=4)

        self.gen_progress = ctk.CTkProgressBar(form_scroll, height=8, progress_color="#3B82F6")
        self.gen_progress.set(0.0)
        self.gen_progress.pack(fill="x", pady=(0, 4), padx=4)

        self.lbl_telemetry = ctk.CTkLabel(form_scroll, text="Ready to synthesize practice exam.", font=ctk.CTkFont(size=11), text_color="#9CA3AF")
        self.lbl_telemetry.pack(pady=(0, 10))

        # =========================================================================
        # RIGHT PANE: Interactive Results & Assessment Center
        # =========================================================================
        right_container = ctk.CTkFrame(self, fg_color=THEME["card_dark"], corner_radius=14, border_width=1, border_color=THEME["card_border"])
        right_container.grid(row=0, column=1, padx=(7, 14), pady=14, sticky="nsew")
        right_container.grid_rowconfigure(1, weight=1)
        right_container.grid_columnconfigure(0, weight=1)

        # 1. Action Ribbon Header
        action_ribbon = ctk.CTkFrame(right_container, fg_color="transparent")
        action_ribbon.grid(row=0, column=0, padx=16, pady=(12, 6), sticky="ew")

        self.lbl_doc_title = ctk.CTkLabel(
            action_ribbon,
            text="📋 Generated Practice Exam & Assessment Suite",
            font=ctk.CTkFont(size=15, weight="bold"),
            text_color="#F3F4F6"
        )
        self.lbl_doc_title.pack(side="left")

        # Multi-Format Export Action Buttons
        self.btn_docx = ctk.CTkButton(
            action_ribbon,
            text="📄 Word (.docx)",
            width=100,
            height=30,
            font=ctk.CTkFont(size=11, weight="bold"),
            fg_color="#2563EB",
            hover_color="#1D4ED8",
            command=self._export_docx_action
        )
        self.btn_docx.pack(side="right", padx=(4, 0))

        self.btn_pdf = ctk.CTkButton(
            action_ribbon,
            text="📥 PDF",
            width=80,
            height=30,
            font=ctk.CTkFont(size=11, weight="bold"),
            fg_color="#059669",
            hover_color="#047857",
            command=self._export_pdf_action
        )
        self.btn_pdf.pack(side="right", padx=(4, 0))

        self.btn_copy = ctk.CTkButton(
            action_ribbon,
            text="📋 Copy",
            width=70,
            height=30,
            font=ctk.CTkFont(size=11),
            fg_color="#334155",
            hover_color="#475569",
            command=self._copy_paper_action
        )
        self.btn_copy.pack(side="right", padx=(4, 0))

        # 2. Tabbed Viewer
        self.results_tabs = ctk.CTkTabview(right_container, fg_color="#0B0F19", segmented_button_selected_color="#2563EB")
        self.results_tabs.grid(row=1, column=0, padx=12, pady=(0, 12), sticky="nsew")

        self.tab_view_paper = self.results_tabs.add("📄 Practice Paper")
        self.tab_view_mock = self.results_tabs.add("✍️ Take Mock Exam")
        self.tab_view_grading = self.results_tabs.add("🎯 AI Grade Report")
        self.tab_view_solutions = self.results_tabs.add("🔑 Model Solutions")
        self.tab_view_matrix = self.results_tabs.add("🎯 CLO-PLO Matrix")
        self.tab_view_extracted = self.results_tabs.add("📖 Extracted Material")
        self.tab_view_pattern = self.results_tabs.add("📊 Style Analytics")
        self.tab_view_history = self.results_tabs.add("🗃️ Saved History")

        # Populate Tabs
        self._init_tab_paper()
        self._init_tab_mock()
        self._init_tab_grading()
        self._init_tab_solutions()
        self._init_tab_matrix()
        self._init_tab_extracted()
        self._init_tab_pattern()
        self._init_tab_history()

        # Initial validation trigger
        self._update_pattern_calc()

    def _create_section_card(self, parent, title: str) -> ctk.CTkFrame:
        card = ctk.CTkFrame(parent, fg_color="#1E293B", corner_radius=10, border_width=1, border_color="#334155")
        card.pack(fill="x", pady=5, padx=4)
        ctk.CTkLabel(card, text=title, font=ctk.CTkFont(size=12, weight="bold"), text_color="#93C5FD").pack(anchor="w", padx=10, pady=(6, 2))
        return card

    def _open_api_key_dialog(self):
        """Modal dialog for viewing, entering, and persisting Gemini/Groq API keys."""
        modal = ctk.CTkToplevel(self)
        modal.title("API Key & Engine Credentials")
        modal.geometry("540x360")
        modal.configure(fg_color=THEME["bg_dark"])
        modal.grab_set()

        card = ctk.CTkFrame(modal, fg_color=THEME["card_dark"], corner_radius=12, border_width=1, border_color="#334155")
        card.pack(fill="both", expand=True, padx=16, pady=16)

        ctk.CTkLabel(card, text="🔑 API Key Configuration", font=ctk.CTkFont(size=16, weight="bold"), text_color="#60A5FA").pack(anchor="w", padx=14, pady=(12, 4))
        ctk.CTkLabel(card, text="Keys are saved securely to your local .env file. (Never committed to git).", font=ctk.CTkFont(size=10), text_color="#94A3B8").pack(anchor="w", padx=14, pady=(0, 10))

        # Gemini Key Field
        ctk.CTkLabel(card, text="Google Gemini API Key:", font=ctk.CTkFont(size=11, weight="bold")).pack(anchor="w", padx=14, pady=(4, 2))
        ent_gemini = ctk.CTkEntry(card, show="•", height=32, font=ctk.CTkFont(size=11))
        ent_gemini.insert(0, os.environ.get("GEMINI_API_KEY", ""))
        ent_gemini.pack(fill="x", padx=14, pady=(0, 8))

        # Groq Key Field
        ctk.CTkLabel(card, text="Groq Cloud API Key (Optional):", font=ctk.CTkFont(size=11, weight="bold")).pack(anchor="w", padx=14, pady=(4, 2))
        ent_groq = ctk.CTkEntry(card, show="•", height=32, font=ctk.CTkFont(size=11))
        ent_groq.insert(0, os.environ.get("GROQ_API_KEY", ""))
        ent_groq.pack(fill="x", padx=14, pady=(0, 14))

        def save_keys():
            g_key = ent_gemini.get().strip()
            gr_key = ent_groq.get().strip()
            
            if g_key:
                os.environ["GEMINI_API_KEY"] = g_key
            if gr_key:
                os.environ["GROQ_API_KEY"] = gr_key

            # Write to .env
            env_target = Path(__file__).resolve().parent / ".env"
            try:
                with open(env_target, "w", encoding="utf-8") as ef:
                    ef.write(f"GEMINI_API_KEY={g_key}\n")
                    ef.write(f"GROQ_API_KEY={gr_key}\n")
                messagebox.showinfo("Saved", "API Keys saved to .env and activated for current session!")
                modal.destroy()
            except OSError as err:
                messagebox.showerror("Error Saving", f"Could not write to .env: {err}")

        btn_save = ctk.CTkButton(card, text="💾 Save & Activate Keys", height=36, font=ctk.CTkFont(weight="bold"), fg_color="#2563EB", hover_color="#1D4ED8", command=save_keys)
        btn_save.pack(fill="x", padx=14, pady=(6, 10))

    def _init_tab_paper(self):
        self.txt_display_paper = ctk.CTkTextbox(self.tab_view_paper, wrap="word", font=ctk.CTkFont(family="Consolas", size=11), fg_color="#0B0F19")
        self.txt_display_paper.pack(fill="both", expand=True, padx=4, pady=4)
        self.txt_display_paper.insert("1.0", "Welcome to ExamMind AI!\n\n1. Select your Course & Target University Profile.\n2. Configure your announced paper pattern & attach lecture slides/past papers.\n3. Click '🚀 Generate AI Practice Exam Paper'.\n\nYour university-level practice paper, answer keys, mock exam mode, and CLO alignments will appear here.")

    def _init_tab_mock(self):
        self.mock_scroll = ctk.CTkScrollableFrame(self.tab_view_mock, fg_color="transparent")
        self.mock_scroll.pack(fill="both", expand=True, padx=4, pady=4)
        
        # Timer and Submit Bar
        mock_bar = ctk.CTkFrame(self.mock_scroll, fg_color="#1E293B", corner_radius=8)
        mock_bar.pack(fill="x", pady=(0, 10), padx=2)

        self.lbl_mock_timer = ctk.CTkLabel(mock_bar, text="⏱️ Exam Timer: 00:00:00", font=ctk.CTkFont(size=13, weight="bold"), text_color="#60A5FA")
        self.lbl_mock_timer.pack(side="left", padx=12, pady=8)

        self.btn_timer_toggle = ctk.CTkButton(mock_bar, text="▶ Start Timer", width=95, height=28, fg_color="#334155", command=self._toggle_mock_timer)
        self.btn_timer_toggle.pack(side="left", padx=6, pady=8)

        self.btn_submit_mock = ctk.CTkButton(
            mock_bar,
            text="🤖 AI Grade My Exam",
            font=ctk.CTkFont(weight="bold"),
            fg_color="#059669",
            hover_color="#047857",
            height=30,
            command=self._grade_mock_exam
        )
        self.btn_submit_mock.pack(side="right", padx=12, pady=8)

        self.mock_questions_container = ctk.CTkFrame(self.mock_scroll, fg_color="transparent")
        self.mock_questions_container.pack(fill="both", expand=True)
        ctk.CTkLabel(self.mock_questions_container, text="Generate an exam paper first to take the interactive mock test!", text_color="#9CA3AF").pack(pady=40)

    def _init_tab_grading(self):
        self.grading_scroll = ctk.CTkScrollableFrame(self.tab_view_grading, fg_color="transparent")
        self.grading_scroll.pack(fill="both", expand=True, padx=4, pady=4)
        ctk.CTkLabel(self.grading_scroll, text="Submit your answers in '✍️ Take Mock Exam' to see your AI scorecard, rubric breakdown, and CLO attainment diagnosis.", text_color="#9CA3AF").pack(pady=40)

    def _init_tab_solutions(self):
        self.txt_display_sol = ctk.CTkTextbox(self.tab_view_solutions, wrap="word", font=ctk.CTkFont(family="Consolas", size=11), fg_color="#0B0F19")
        self.txt_display_sol.pack(fill="both", expand=True, padx=4, pady=4)
        self.txt_display_sol.insert("1.0", "Official model solutions and step-by-step marking rubrics will appear here once generated.")

    def _init_tab_matrix(self):
        self.txt_display_matrix = ctk.CTkTextbox(self.tab_view_matrix, wrap="none", font=ctk.CTkFont(family="Consolas", size=11), fg_color="#0B0F19")
        self.txt_display_matrix.pack(fill="both", expand=True, padx=4, pady=4)
        self.txt_display_matrix.insert("1.0", "CLO/PLO alignment matrix and Bloom's Taxonomy breakdown will appear here.")

    def _init_tab_extracted(self):
        self.txt_display_extracted = ctk.CTkTextbox(self.tab_view_extracted, wrap="word", font=ctk.CTkFont(family="Consolas", size=11), fg_color="#0B0F19")
        self.txt_display_extracted.pack(fill="both", expand=True, padx=4, pady=4)
        self.txt_display_extracted.insert("1.0", "Upload course slides, past quizzes, or assignments to inspect the raw extracted text and concepts here.")

    def _init_tab_pattern(self):
        self.txt_display_pat = ctk.CTkTextbox(self.tab_view_pattern, wrap="word", font=ctk.CTkFont(size=12), fg_color="#0B0F19")
        self.txt_display_pat.pack(fill="both", expand=True, padx=4, pady=4)
        self.txt_display_pat.insert("1.0", "Detailed report on professor testing tendencies, coding vs theory distribution, and topic weightages.")

    def _init_tab_history(self):
        self.history_scroll = ctk.CTkScrollableFrame(self.tab_view_history, fg_color="transparent")
        self.history_scroll.pack(fill="both", expand=True, padx=4, pady=4)
        self._refresh_history_cards()

    def _on_subject_changed(self, choice: str):
        sub_name = choice.split(" (")[0] if " (" in choice else choice
        self.lbl_verbal_info.configure(text=f"Enter hints & topics for {sub_name}:")

    def _apply_preset(self, total: int, mcq_c: int, mcq_m: float, short_c: int, short_m: float, long_c: int, long_m: float):
        self.ent_total.delete(0, "end")
        self.ent_total.insert(0, str(total))
        self.ent_mcq_c.delete(0, "end")
        self.ent_mcq_c.insert(0, str(mcq_c))
        self.ent_mcq_m.delete(0, "end")
        self.ent_mcq_m.insert(0, str(int(mcq_m) if mcq_m.is_integer() else mcq_m))
        self.ent_short_c.delete(0, "end")
        self.ent_short_c.insert(0, str(short_c))
        self.ent_short_m.delete(0, "end")
        self.ent_short_m.insert(0, str(int(short_m) if short_m.is_integer() else short_m))
        self.ent_long_c.delete(0, "end")
        self.ent_long_c.insert(0, str(long_c))
        self.ent_long_m.delete(0, "end")
        self.ent_long_m.insert(0, str(int(long_m) if long_m.is_integer() else long_m))
        self.ent_tf_c.delete(0, "end")
        self.ent_tf_c.insert(0, "0")
        self._update_pattern_calc()

    def _append_verbal(self, text: str):
        current = self.txt_verbal_hints.get("1.0", "end").strip()
        if current:
            self.txt_verbal_hints.delete("1.0", "end")
            self.txt_verbal_hints.insert("1.0", f"{current} {text}")
        else:
            self.txt_verbal_hints.insert("1.0", text)

    def _show_clo_inspector(self):
        slug = self.subject_map.get(self.subject_var.get())
        info = curriculum_repo.get_subject_by_slug(slug)
        if not info:
            return

        modal = ctk.CTkToplevel(self)
        modal.title(f"HEC Curriculum Inspector: {info.get('title')}")
        modal.geometry("740x560")
        modal.configure(fg_color=THEME["bg_dark"])
        modal.grab_set()

        scroll = ctk.CTkScrollableFrame(modal, fg_color=THEME["card_dark"])
        scroll.pack(fill="both", expand=True, padx=14, pady=14)

        ctk.CTkLabel(scroll, text=f"🏛️ {info.get('title')} ({info.get('code')})", font=ctk.CTkFont(size=17, weight="bold"), text_color="#60A5FA").pack(anchor="w", pady=(0, 2))
        ctk.CTkLabel(scroll, text=f"Category: {info.get('category')}  |  Credits: {info.get('credit_hours')}  |  Semester: {info.get('semester_suggested', 'Core')}", font=ctk.CTkFont(size=11), text_color="#9CA3AF").pack(anchor="w", pady=(0, 8))

        ctk.CTkLabel(scroll, text=info.get("description", ""), font=ctk.CTkFont(size=11), wraplength=660, justify="left").pack(anchor="w", pady=(0, 10))

        ctk.CTkLabel(scroll, text="Official Course Learning Outcomes (CLOs):", font=ctk.CTkFont(size=13, weight="bold"), text_color="#93C5FD").pack(anchor="w", pady=(4, 4))
        for clo in info.get("clos", []):
            card = ctk.CTkFrame(scroll, fg_color="#1E293B", corner_radius=6)
            card.pack(fill="x", pady=3, padx=2)
            ctk.CTkLabel(card, text=f"[{clo['id']}] {clo['text']}", font=ctk.CTkFont(size=11, weight="bold"), wraplength=640, justify="left").pack(anchor="w", padx=10, pady=(6, 2))
            ctk.CTkLabel(card, text=f"🎯 Cognitive Level: {clo['blooms_level']}   |   Mapped Seoul Accord: {', '.join(clo.get('mapped_plos', []))}", font=ctk.CTkFont(size=10), text_color="#34D399").pack(anchor="w", padx=10, pady=(0, 6))

        ctk.CTkLabel(scroll, text="Prescribed Syllabus Topics:", font=ctk.CTkFont(size=13, weight="bold"), text_color="#93C5FD").pack(anchor="w", pady=(10, 4))
        for t in info.get("common_topics", []):
            ctk.CTkLabel(scroll, text=f"  • {t}", font=ctk.CTkFont(size=11), anchor="w").pack(anchor="w", padx=4, pady=1)

    def _select_files(self, category: str):
        filetypes = [
            ("Supported Documents", "*.pdf;*.pptx;*.docx;*.txt;*.png;*.jpg;*.jpeg;*.webp"),
            ("PDF Files", "*.pdf"),
            ("PowerPoint", "*.pptx"),
            ("Word Docs", "*.docx"),
            ("Images/Scans", "*.png;*.jpg;*.jpeg;*.webp"),
            ("Text Files", "*.txt")
        ]
        chosen = filedialog.askopenfilenames(title=f"Attach {category.replace('_', ' ').title()}", filetypes=filetypes)
        if chosen:
            self.selected_files[category] = list(chosen)

        # Update Buttons
        self.btn_slides.configure(text=f"📄 Slides ({len(self.selected_files['slides'])})", fg_color="#2563EB" if self.selected_files['slides'] else "#1E293B")
        self.btn_quizzes.configure(text=f"📝 Quizzes ({len(self.selected_files['quizzes'])})", fg_color="#2563EB" if self.selected_files['quizzes'] else "#1E293B")
        self.btn_assign.configure(text=f"📂 Assignments ({len(self.selected_files['assignments'])})", fg_color="#2563EB" if self.selected_files['assignments'] else "#1E293B")
        self.btn_past.configure(text=f"📜 Past Papers ({len(self.selected_files['past_papers'])})", fg_color="#2563EB" if self.selected_files['past_papers'] else "#1E293B")

        total = sum(len(v) for v in self.selected_files.values())
        if total > 0:
            self.lbl_file_stats.configure(text=f"✅ Attached {total} documents for topic & style analysis.", text_color="#34D399")
        else:
            self.lbl_file_stats.configure(text="💡 Upload slides/quizzes to inject custom topics directly into the exam.", text_color="#94A3B8")

    def _update_pattern_calc(self):
        try:
            total_m = float(self.ent_total.get().strip() or "0")
            mcq_c = int(self.ent_mcq_c.get().strip() or "0")
            mcq_m = float(self.ent_mcq_m.get().strip() or "0")
            short_c = int(self.ent_short_c.get().strip() or "0")
            short_m = float(self.ent_short_m.get().strip() or "0")
            long_c = int(self.ent_long_c.get().strip() or "0")
            long_m = float(self.ent_long_m.get().strip() or "0")
            tf_c = int(self.ent_tf_c.get().strip() or "0")
            tf_m = float(self.ent_tf_m.get().strip() or "0")

            # Update Subtotals
            self.lbl_mcq_val.configure(text=f"{mcq_c * mcq_m:g} M")
            self.lbl_short_val.configure(text=f"{short_c * short_m:g} M")
            self.lbl_long_val.configure(text=f"{long_c * long_m:g} M")
            self.lbl_tf_val.configure(text=f"{tf_c * tf_m:g} M")

            is_valid, calc_tot, msg = ExamPatternValidator.validate_marks(
                total_marks=total_m,
                mcq_count=mcq_c,
                mcq_marks_each=mcq_m,
                short_count=short_c,
                short_marks_each=short_m,
                long_count=long_c,
                long_marks_each=long_m,
                tf_count=tf_c,
                tf_marks_each=tf_m
            )

            if is_valid:
                self.badge_valid.configure(
                    text=f"✅ Valid Marks Equation: {mcq_c*mcq_m:g} + {short_c*short_m:g} + {long_c*long_m:g} + {tf_c*tf_m:g} = {total_m:g} Marks",
                    fg_color=THEME["success_bg"],
                    text_color=THEME["success_text"]
                )
                self.btn_execute.configure(state="normal")
            else:
                self.badge_valid.configure(
                    text=f"⚠️ {msg}",
                    fg_color=THEME["error_bg"],
                    text_color=THEME["error_text"]
                )
                self.btn_execute.configure(state="disabled")
        except Exception:
            self.badge_valid.configure(text="⚠️ Enter valid numerical values.", fg_color=THEME["error_bg"], text_color=THEME["error_text"])
            self.btn_execute.configure(state="disabled")

    def _launch_generation(self):
        if self.is_generating:
            return

        self.is_generating = True
        self.btn_execute.configure(state="disabled", text="⏳ Synthesizing Practice Paper...")
        self.gen_progress.set(0.1)
        self.lbl_telemetry.configure(text="Step 1/4: Parsing uploaded course materials...")

        import threading
        thread = threading.Thread(target=self._generation_worker, daemon=True)
        thread.start()

    def _generation_worker(self):
        try:
            slug = self.subject_map.get(self.subject_var.get())
            subject_info = curriculum_repo.get_subject_by_slug(slug)
            exam_type = self.exam_type_var.get()
            verbal = self.txt_verbal_hints.get("1.0", "end").strip()
            uni_choice = self.uni_var.get()
            uni_header = UNIVERSITY_PRESETS.get(uni_choice, "Department of Computer Science — Examination Paper")
            rigor = self.rigor_var.get()

            total_m_val = float(self.ent_total.get().strip() or "50")
            pattern = {
                "total_marks": int(total_m_val) if total_m_val.is_integer() else total_m_val,
                "mcq_count": int(self.ent_mcq_c.get().strip() or "0"),
                "mcq_marks_each": float(self.ent_mcq_m.get().strip() or "0"),
                "short_count": int(self.ent_short_c.get().strip() or "0"),
                "short_marks_each": float(self.ent_short_m.get().strip() or "0"),
                "long_count": int(self.ent_long_c.get().strip() or "0"),
                "long_marks_each": float(self.ent_long_m.get().strip() or "0"),
                "tf_count": int(self.ent_tf_c.get().strip() or "0"),
                "tf_marks_each": float(self.ent_tf_m.get().strip() or "0")
            }

            parsed_materials = {}
            total_chars = 0
            failed_files = []
            
            for cat, paths in self.selected_files.items():
                parsed_materials[cat] = []
                for p in paths:
                    try:
                        with open(p, "rb") as f:
                            doc = DocumentParser.parse_uploaded_file(f)
                            doc["filename"] = Path(p).name
                            parsed_materials[cat].append(doc)
                            total_chars += doc.get("char_count", 0)
                    except Exception as e:
                        failed_files.append((Path(p).name, str(e)))

            self.extracted_materials_cache = parsed_materials

            parse_feedback = f"Parsed {sum(len(v) for v in parsed_materials.values())} files ({total_chars:,} chars)"
            if failed_files:
                parse_feedback += f" | ⚠️ {len(failed_files)} file errors"

            self.after(0, lambda: self.gen_progress.set(0.35))
            self.after(0, lambda: self.lbl_telemetry.configure(text=f"Step 2/4: {parse_feedback}..."))

            mat_analysis = MaterialAnalyzer.extract_topic_weightages(parsed_materials, subject_info)
            past_docs = parsed_materials.get("past_papers", []) + parsed_materials.get("midterms", [])
            quiz_docs = parsed_materials.get("quizzes", [])
            style_analysis = MaterialAnalyzer.analyze_past_paper_patterns(past_docs, quiz_docs)
            document_context = DocumentParser.build_prompt_material_context(parsed_materials)

            self.after(0, lambda: self.gen_progress.set(0.65))
            self.after(0, lambda: self.lbl_telemetry.configure(text="Step 3/4: Synthesizing questions with HEC CLOs & document context..."))

            choice = self.provider_choice.get()
            prov_key = "gemini" if "Gemini" in choice else ("groq" if "Groq" in choice else "offline")

            generator = ExamGenerator(
                gemini_api_key=os.environ.get("GEMINI_API_KEY"),
                groq_api_key=os.environ.get("GROQ_API_KEY")
            )
            
            paper_result = generator.generate_exam_paper(
                subject_slug=slug,
                exam_type=exam_type,
                pattern=pattern,
                verbal_instructions=verbal,
                uploaded_summary=parse_feedback,
                material_analysis=mat_analysis,
                style_analysis=style_analysis,
                document_context=document_context,
                rigor_level=rigor,
                university_header=uni_header,
                llm_provider=prov_key
            )

            # Persist in SQLite
            paper_uid = save_paper(
                subject_slug=slug,
                subject_title=subject_info.get("title", slug),
                exam_type=exam_type,
                total_marks=pattern["total_marks"],
                pattern=pattern,
                verbal_instructions=verbal,
                uploaded_files_summary=parse_feedback,
                paper_content=paper_result,
                solution_content=paper_result.get("marking_scheme_and_solutions", {}),
                analysis_summary=paper_result.get("pattern_analysis_summary", "")
            )

            self.current_paper_data = paper_result
            self.current_paper_uid = paper_uid

            self.after(0, lambda: self.gen_progress.set(1.0))
            self.after(0, lambda: self.lbl_telemetry.configure(text="✅ Exam Generation Complete! Saved to database."))
            self.after(0, lambda: self._display_results(paper_result, subject_info))
            self.after(0, lambda: self._build_mock_exam_ui(paper_result))
            self.after(0, lambda: self._display_extracted_material())
            self.after(0, lambda: self._refresh_history_cards())

        except Exception as e:
            self.after(0, lambda err=str(e): messagebox.showerror("Generation Error", f"Failed: {err}"))
            self.after(0, lambda: self.lbl_telemetry.configure(text="❌ Error occurred during generation."))
        finally:
            self.is_generating = False
            self.after(0, lambda: self.btn_execute.configure(state="normal", text="🚀 Generate AI Practice Exam Paper"))

    def _display_results(self, paper: Dict[str, Any], subject_info: Optional[Dict[str, Any]] = None):
        if not subject_info:
            slug = self.subject_map.get(self.subject_var.get())
            subject_info = curriculum_repo.get_subject_by_slug(slug)

        meta = paper.get("metadata", {})
        self.lbl_doc_title.configure(text=f"📋 {meta.get('subject')} ({meta.get('course_code')}) — {meta.get('exam_type')} Exam")

        # 1. Exam Paper Text Formatter
        lines_p = [
            f"=======================================================================================",
            f"                     {meta.get('university_header', 'DEPARTMENT OF COMPUTER SCIENCE')}",
            f"            {meta.get('subject')} ({meta.get('course_code')}) — {meta.get('exam_type')} Examination",
            f"=======================================================================================",
            f"Roll Number: ________________________   Time Allowed: {meta.get('time_allowed', '2.5 Hours')}   Total Marks: {meta.get('total_marks')} Marks",
            f"---------------------------------------------------------------------------------------",
            f"Instructions: " + " | ".join(meta.get("instructions", [])),
            f"---------------------------------------------------------------------------------------\n"
        ]

        mcqs = paper.get("section_a_mcqs", [])
        if mcqs:
            lines_p.append(f"--- SECTION A: MULTIPLE CHOICE QUESTIONS [Marks: {sum(q.get('marks', 1) for q in mcqs):g}] ---")
            for q in mcqs:
                lines_p.append(f"\nQ{q.get('q_number')}. {q.get('question')}  [{q.get('marks')} Mark] [{q.get('clo')} | {q.get('blooms')}]")
                for opt in q.get("options", []):
                    lines_p.append(f"     {opt}")

        tf_list = paper.get("section_a_tf", [])
        if tf_list:
            lines_p.append(f"\n\n--- SECTION A (PART II): TRUE / FALSE [Marks: {sum(q.get('marks', 1) for q in tf_list):g}] ---")
            for q in tf_list:
                lines_p.append(f"\n{q.get('q_number')}. [   ] {q.get('statement')}  [{q.get('marks')} Mark] [{q.get('clo')}]")

        short_qs = paper.get("section_b_short", [])
        if short_qs:
            lines_p.append(f"\n\n--- SECTION B: SHORT ANSWER & ANALYTICAL QUESTIONS [Marks: {sum(q.get('marks', 5) for q in short_qs):g}] ---")
            for q in short_qs:
                plos = f" | {', '.join(q.get('mapped_plos', []))}" if q.get('mapped_plos') else ""
                lines_p.append(f"\nQ{q.get('q_number')}. {q.get('question')}\n     [{q.get('marks')} Marks] [{q.get('clo')} | {q.get('blooms')}{plos}]")

        long_qs = paper.get("section_c_long", [])
        if long_qs:
            lines_p.append(f"\n\n--- SECTION C: LONG / COMPREHENSIVE / DESIGN QUESTIONS [Marks: {sum(q.get('marks', 10) for q in long_qs):g}] ---")
            for q in long_qs:
                plos = f" | {', '.join(q.get('mapped_plos', []))}" if q.get('mapped_plos') else ""
                lines_p.append(f"\nQ{q.get('q_number')}.\n{q.get('question')}\n     [{q.get('marks')} Marks] [{q.get('clo')} | {q.get('blooms')}{plos}]\n")

        self.txt_display_paper.delete("1.0", "end")
        self.txt_display_paper.insert("1.0", "\n".join(lines_p))

        # 2. Solutions Text Formatter
        lines_s = [
            f"=======================================================================================",
            f"                   OFFICIAL MODEL SOLUTIONS & STEP-BY-STEP MARKING RUBRIC",
            f"                                {meta.get('subject')}",
            f"=======================================================================================\n"
        ]
        sol = paper.get("marking_scheme_and_solutions", {})
        if sol.get("mcq_solutions"):
            lines_s.append("1. MCQ ANSWER KEY & EXPLANATIONS:\n")
            for s in sol["mcq_solutions"]:
                lines_s.append(f"  • Q{s.get('q_number')}: Option [{s.get('correct_option')}] — {s.get('explanation')}")
            lines_s.append("\n")

        if sol.get("tf_solutions"):
            lines_s.append("2. TRUE / FALSE ANSWER KEY:\n")
            for s in sol["tf_solutions"]:
                lines_s.append(f"  • Q{s.get('q_number')}: [{s.get('correct_value')}] — {s.get('explanation')}")
            lines_s.append("\n")

        if sol.get("short_solutions"):
            lines_s.append("3. SECTION B MODEL ANSWERS & RUBRICS:\n")
            for s in sol["short_solutions"]:
                lines_s.append(f"[Q{s.get('q_number')} Solution]")
                lines_s.append(f"Model Answer:\n{s.get('model_answer')}")
                lines_s.append(f"Rubric: {s.get('rubric')}\n" + "-"*65)

        if sol.get("long_solutions"):
            lines_s.append("\n4. SECTION C COMPREHENSIVE SOLUTIONS & STEP-WISE RUBRICS:\n")
            for s in sol["long_solutions"]:
                lines_s.append(f"[Q{s.get('q_number')} Comprehensive Solution]")
                lines_s.append(f"Model Answer:\n{s.get('model_answer')}")
                lines_s.append(f"Step-wise Rubric:\n{s.get('rubric')}\n" + "="*65)

        self.txt_display_sol.delete("1.0", "end")
        self.txt_display_sol.insert("1.0", "\n".join(lines_s))

        # 3. Dynamic Matrix Table Formatter with Real Audited Alignment
        audit = ExamPatternValidator.validate_clo_alignment(paper, subject_info)
        blooms_hdr = "Bloom's Level"
        lines_m = [
            f"=======================================================================================",
            f"               CLO / PLO ATTAINMENT & BLOOM'S TAXONOMY ALIGNMENT MATRIX",
            f"=======================================================================================",
            f"HEC OBE Alignment Audit: {'✅ All Questions Verified Bounded to Curriculum' if audit['all_verified'] else '⚠️ Custom / Unmapped CLOs Detected'}",
            f"{'Section':<15} | {'Q#':<5} | {'Marks':<6} | {'Target CLO':<12} | {blooms_hdr:<20} | {'Mapped PLOs'}",
            f"-"*85
        ]
        for item in audit.get("verification_results", []):
            sec_short = item["section"].replace("Section ", "")
            plos_str = ", ".join(item["mapped_plos"])
            lines_m.append(f"{sec_short:<15} | {'Q'+str(item['q_number']):<5} | {item['marks']:<6g} | {item['clo']:<12} | {item['blooms']:<20} | {plos_str}")

        self.txt_display_matrix.delete("1.0", "end")
        self.txt_display_matrix.insert("1.0", "\n".join(lines_m))

        # 4. Pattern Analysis Formatter
        lines_pat = [
            f"=======================================================================================",
            f"             PROFESSOR ASSESSMENT STYLE & PATTERN ANALYSIS REPORT",
            f"=======================================================================================\n",
            f"Subject: {meta.get('subject')} ({meta.get('course_code')})",
            f"Exam Type: {meta.get('exam_type')} Examination | Total Marks: {meta.get('total_marks')} Marks\n",
            f"Detected Assessment Pattern Insight:\n{paper.get('pattern_analysis_summary', 'Standard HEC academic distribution.')}\n",
            f"---------------------------------------------------------------------------------------",
            f"OBE Calibration Standards Audited:\n",
            f"• HEC Outcome Alignment: Verified {audit.get('total_questions_audited', 0)} questions against prescribed course learning outcomes.",
            f"• Cognitive Distribution: Spans C2 (Understand) to C6 (Design & Create).",
            f"• Novelty Synthesis: Custom scenario variations synthesized without verbatim prompt repetition.",
            f"• Point Balancing: Exact mathematical mark balancing enforced at {meta.get('total_marks')} Marks."
        ]
        self.txt_display_pat.delete("1.0", "end")
        self.txt_display_pat.insert("1.0", "\n".join(lines_pat))

        # Auto-switch to Exam Paper Tab
        self.results_tabs.set("📄 Practice Paper")

    def _display_extracted_material(self):
        if not self.extracted_materials_cache:
            self.txt_display_extracted.delete("1.0", "end")
            self.txt_display_extracted.insert("1.0", "No documents uploaded for this generation session.")
            return

        lines = [
            "=======================================================================================",
            "                      EXTRACTED COURSE MATERIAL & DOCUMENT CHUNKS",
            "=======================================================================================\n"
        ]
        for cat, docs in self.extracted_materials_cache.items():
            lines.append(f"📁 CATEGORY: {cat.upper()} ({len(docs)} Files Ingested)\n" + "-"*60)
            for d in docs:
                lines.append(f"📄 File: {d.get('filename')} (Chars: {d.get('char_count')})")
                lines.append(f"Extracted Content Preview:\n{d.get('text', '')[:1200]}...\n")

        self.txt_display_extracted.delete("1.0", "end")
        self.txt_display_extracted.insert("1.0", "\n".join(lines))

    def _build_mock_exam_ui(self, paper: Dict[str, Any]):
        for widget in self.mock_questions_container.winfo_children():
            widget.destroy()

        self.mock_inputs = {}

        ctk.CTkLabel(
            self.mock_questions_container,
            text="✍️ Interactive Student Test Environment",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color="#60A5FA"
        ).pack(anchor="w", pady=(0, 6))

        # 1. Section A: MCQs
        mcqs = paper.get("section_a_mcqs", [])
        if mcqs:
            sec_a = ctk.CTkFrame(self.mock_questions_container, fg_color="#1E293B", corner_radius=8)
            sec_a.pack(fill="x", pady=6, padx=2)
            ctk.CTkLabel(sec_a, text="Section A: Multiple Choice Questions", font=ctk.CTkFont(size=12, weight="bold"), text_color="#93C5FD").pack(anchor="w", padx=10, pady=(6, 4))

            for q in mcqs:
                q_num = q.get("q_number")
                q_box = ctk.CTkFrame(sec_a, fg_color="#0B0F19", corner_radius=6)
                q_box.pack(fill="x", padx=10, pady=4)

                ctk.CTkLabel(q_box, text=f"Q{q_num}. {q.get('question')} ({q.get('marks')} Mark)", font=ctk.CTkFont(size=11, weight="bold"), wraplength=580, justify="left").pack(anchor="w", padx=8, pady=(4, 2))
                
                var = ctk.StringVar(value="")
                self.mock_inputs[f"mcq_{q_num}"] = var
                
                for opt in q.get("options", []):
                    ctk.CTkRadioButton(q_box, text=opt, variable=var, value=opt[0] if opt else "", font=ctk.CTkFont(size=10)).pack(anchor="w", padx=14, pady=2)

        # 2. Section A (Part II): True / False
        tf_list = paper.get("section_a_tf", [])
        if tf_list:
            sec_tf = ctk.CTkFrame(self.mock_questions_container, fg_color="#1E293B", corner_radius=8)
            sec_tf.pack(fill="x", pady=6, padx=2)
            ctk.CTkLabel(sec_tf, text="Section A (Part II): True / False Questions", font=ctk.CTkFont(size=12, weight="bold"), text_color="#93C5FD").pack(anchor="w", padx=10, pady=(6, 4))

            for q in tf_list:
                q_num = q.get("q_number")
                q_box = ctk.CTkFrame(sec_tf, fg_color="#0B0F19", corner_radius=6)
                q_box.pack(fill="x", padx=10, pady=4)

                ctk.CTkLabel(q_box, text=f"{q_num}. {q.get('statement')} ({q.get('marks')} Mark)", font=ctk.CTkFont(size=11, weight="bold"), wraplength=580, justify="left").pack(anchor="w", padx=8, pady=(4, 2))

                tf_var = ctk.StringVar(value="")
                self.mock_inputs[f"tf_{q_num}"] = tf_var

                tf_r_frame = ctk.CTkFrame(q_box, fg_color="transparent")
                tf_r_frame.pack(anchor="w", padx=14, pady=2)
                ctk.CTkRadioButton(tf_r_frame, text="True", variable=tf_var, value="True", font=ctk.CTkFont(size=10)).pack(side="left", padx=(0, 14))
                ctk.CTkRadioButton(tf_r_frame, text="False", variable=tf_var, value="False", font=ctk.CTkFont(size=10)).pack(side="left")

        # 3. Section B: Short Questions
        short_qs = paper.get("section_b_short", [])
        if short_qs:
            sec_b = ctk.CTkFrame(self.mock_questions_container, fg_color="#1E293B", corner_radius=8)
            sec_b.pack(fill="x", pady=6, padx=2)
            ctk.CTkLabel(sec_b, text="Section B: Short Answer Questions", font=ctk.CTkFont(size=12, weight="bold"), text_color="#93C5FD").pack(anchor="w", padx=10, pady=(6, 4))

            for q in short_qs:
                q_num = q.get("q_number")
                q_box = ctk.CTkFrame(sec_b, fg_color="#0B0F19", corner_radius=6)
                q_box.pack(fill="x", padx=10, pady=4)

                ctk.CTkLabel(q_box, text=f"Q{q_num}. {q.get('question')} [{q.get('marks')} Marks]", font=ctk.CTkFont(size=11, weight="bold"), wraplength=580, justify="left").pack(anchor="w", padx=8, pady=(4, 2))
                
                txt = ctk.CTkTextbox(q_box, height=80, font=ctk.CTkFont(size=11), fg_color="#1E293B")
                txt.pack(fill="x", padx=8, pady=(2, 6))
                self.mock_inputs[f"short_{q_num}"] = txt

        # 4. Section C: Long Questions
        long_qs = paper.get("section_c_long", [])
        if long_qs:
            sec_c = ctk.CTkFrame(self.mock_questions_container, fg_color="#1E293B", corner_radius=8)
            sec_c.pack(fill="x", pady=6, padx=2)
            ctk.CTkLabel(sec_c, text="Section C: Long / Design Questions", font=ctk.CTkFont(size=12, weight="bold"), text_color="#93C5FD").pack(anchor="w", padx=10, pady=(6, 4))

            for q in long_qs:
                q_num = q.get("q_number")
                q_box = ctk.CTkFrame(sec_c, fg_color="#0B0F19", corner_radius=6)
                q_box.pack(fill="x", padx=10, pady=4)

                ctk.CTkLabel(q_box, text=f"Q{q_num}. {q.get('question')} [{q.get('marks')} Marks]", font=ctk.CTkFont(size=11, weight="bold"), wraplength=580, justify="left").pack(anchor="w", padx=8, pady=(4, 2))
                
                txt = ctk.CTkTextbox(q_box, height=130, font=ctk.CTkFont(size=11), fg_color="#1E293B")
                txt.pack(fill="x", padx=8, pady=(2, 6))
                self.mock_inputs[f"long_{q_num}"] = txt

    def _toggle_mock_timer(self):
        """Single-instance Tkinter timer loop (prevents multi-thread leaks)."""
        if self.mock_timer_running:
            self.mock_timer_running = False
            if self._timer_job:
                self.after_cancel(self._timer_job)
                self._timer_job = None
            self.btn_timer_toggle.configure(text="▶ Resume Timer", fg_color="#334155")
        else:
            self.mock_timer_running = True
            self.btn_timer_toggle.configure(text="⏸ Pause Timer", fg_color="#B45309")
            self._timer_tick()

    def _timer_tick(self):
        if not self.mock_timer_running:
            return
        self.mock_timer_seconds += 1
        h = self.mock_timer_seconds // 3600
        m = (self.mock_timer_seconds % 3600) // 60
        s = self.mock_timer_seconds % 60
        self.lbl_mock_timer.configure(text=f"⏱️ Exam Timer: {h:02d}:{m:02d}:{s:02d}")
        self._timer_job = self.after(1000, self._timer_tick)

    def _grade_mock_exam(self):
        if not self.current_paper_data:
            messagebox.showwarning("No Exam", "Generate an exam paper first.")
            return

        if self.is_grading:
            return

        self.is_grading = True
        self.btn_submit_mock.configure(state="disabled", text="⏳ Evaluating Answers...")

        # Gather Answers
        collected_answers = {}
        for key, widget in self.mock_inputs.items():
            if isinstance(widget, ctk.StringVar):
                collected_answers[key] = widget.get()
            elif isinstance(widget, ctk.CTkTextbox):
                collected_answers[key] = widget.get("1.0", "end-1c").strip()

        import threading
        thread = threading.Thread(target=self._grading_worker, args=(collected_answers,), daemon=True)
        thread.start()

    def _grading_worker(self, student_answers: Dict[str, Any]):
        try:
            grader = ExamGrader(gemini_api_key=os.environ.get("GEMINI_API_KEY"))
            grade_report = grader.grade_student_exam(self.current_paper_data, student_answers, use_llm=bool(os.environ.get("GEMINI_API_KEY")))
            self.after(0, lambda: self._display_grading_report(grade_report))
            self.after(0, lambda: self.results_tabs.set("🎯 AI Grade Report"))
            self.after(0, lambda: messagebox.showinfo("Grading Complete", f"Your Exam Score: {grade_report['summary']['total_obtained']:g} / {grade_report['summary']['total_possible']:g} ({grade_report['summary']['percentage']}% - {grade_report['summary']['grade']})"))
        except Exception as e:
            self.after(0, lambda err=str(e): messagebox.showerror("Grading Error", f"Grading failed: {err}"))
        finally:
            self.is_grading = False
            self.after(0, lambda: self.btn_submit_mock.configure(state="normal", text="🤖 AI Grade My Exam"))

    def _display_grading_report(self, report: Dict[str, Any]):
        for widget in self.grading_scroll.winfo_children():
            widget.destroy()

        summary = report.get("summary", {})

        # Scorecard Banner
        banner = ctk.CTkFrame(self.grading_scroll, fg_color="#1E3A8A", corner_radius=10)
        banner.pack(fill="x", pady=(0, 10), padx=2)

        ctk.CTkLabel(banner, text=f"🎓 {summary.get('subject')} — Exam Assessment Scorecard", font=ctk.CTkFont(size=14, weight="bold"), text_color="#93C5FD").pack(anchor="w", padx=12, pady=(10, 2))
        
        score_text = f"Marks: {summary.get('total_obtained'):g} / {summary.get('total_possible'):g}  |  Percentage: {summary.get('percentage')}%  |  Grade: {summary.get('grade')}"
        ctk.CTkLabel(banner, text=score_text, font=ctk.CTkFont(size=16, weight="bold"), text_color="#6EE7B7").pack(anchor="w", padx=12, pady=(0, 10))

        # CLO Attainment Diagnostics Card
        clo_box = ctk.CTkFrame(self.grading_scroll, fg_color="#1E293B", corner_radius=8)
        clo_box.pack(fill="x", pady=6, padx=2)
        ctk.CTkLabel(clo_box, text="🎯 HEC CLO Attainment Diagnostics", font=ctk.CTkFont(size=12, weight="bold"), text_color="#93C5FD").pack(anchor="w", padx=10, pady=(8, 4))

        for diag in report.get("clo_diagnostics", []):
            d_row = ctk.CTkFrame(clo_box, fg_color="#0B0F19", corner_radius=6)
            d_row.pack(fill="x", padx=8, pady=3)
            
            c_text = f"[{diag['clo']}] Score: {diag['obtained']:g} / {diag['total']:g} ({diag['percentage']}%)"
            ctk.CTkLabel(d_row, text=c_text, font=ctk.CTkFont(size=11, weight="bold")).pack(side="left", padx=10, pady=6)

            st_color = "#34D399" if "Mastered" in diag["status"] else ("#FBBF24" if "Satisfactory" in diag["status"] else "#F87171")
            ctk.CTkLabel(d_row, text=diag["status"], font=ctk.CTkFont(size=10, weight="bold"), text_color=st_color).pack(side="right", padx=10, pady=6)

        # Question by Question Detailed Feedback
        ctk.CTkLabel(self.grading_scroll, text="📋 Question-by-Question Evaluator Feedback:", font=ctk.CTkFont(size=13, weight="bold"), text_color="#F3F4F6").pack(anchor="w", pady=(10, 4))

        # MCQs
        for item in report.get("mcq_evaluations", []):
            card = ctk.CTkFrame(self.grading_scroll, fg_color="#1E293B", corner_radius=6)
            card.pack(fill="x", pady=3, padx=2)
            
            hdr = f"MCQ Q{item['q_number']}: {item['marks_awarded']:g} / {item['max_marks']:g} Marks [{item['clo']}]"
            color = "#6EE7B7" if item["is_correct"] else "#FCA5A5"
            ctk.CTkLabel(card, text=hdr, font=ctk.CTkFont(weight="bold"), text_color=color).pack(anchor="w", padx=8, pady=(4, 1))
            ctk.CTkLabel(card, text=f"Selected: {item['student_answer']} | {item['feedback']}", font=ctk.CTkFont(size=10), text_color="#94A3B8").pack(anchor="w", padx=8, pady=(0, 4))

        # True / False
        for item in report.get("tf_evaluations", []):
            card = ctk.CTkFrame(self.grading_scroll, fg_color="#1E293B", corner_radius=6)
            card.pack(fill="x", pady=3, padx=2)

            hdr = f"True/False Q{item['q_number']}: {item['marks_awarded']:g} / {item['max_marks']:g} Marks [{item['clo']}]"
            color = "#6EE7B7" if item["is_correct"] else "#FCA5A5"
            ctk.CTkLabel(card, text=hdr, font=ctk.CTkFont(weight="bold"), text_color=color).pack(anchor="w", padx=8, pady=(4, 1))
            ctk.CTkLabel(card, text=f"Selected: {item['student_answer']} | {item['feedback']}", font=ctk.CTkFont(size=10), text_color="#94A3B8").pack(anchor="w", padx=8, pady=(0, 4))

        # Short Questions
        for item in report.get("short_evaluations", []):
            card = ctk.CTkFrame(self.grading_scroll, fg_color="#1E293B", corner_radius=6)
            card.pack(fill="x", pady=4, padx=2)
            
            hdr = f"Section B Q{item['q_number']}: {item['marks_awarded']:g} / {item['max_marks']:g} Marks [{item['clo']}]"
            ctk.CTkLabel(card, text=hdr, font=ctk.CTkFont(weight="bold"), text_color="#93C5FD").pack(anchor="w", padx=8, pady=(6, 2))
            ctk.CTkLabel(card, text=f"Feedback: {item['feedback']}", font=ctk.CTkFont(size=11), text_color="#E2E8F0", wraplength=600, justify="left").pack(anchor="w", padx=8, pady=(0, 6))

        # Long Questions
        for item in report.get("long_evaluations", []):
            card = ctk.CTkFrame(self.grading_scroll, fg_color="#1E293B", corner_radius=6)
            card.pack(fill="x", pady=4, padx=2)
            
            hdr = f"Section C Q{item['q_number']}: {item['marks_awarded']:g} / {item['max_marks']:g} Marks [{item['clo']}]"
            ctk.CTkLabel(card, text=hdr, font=ctk.CTkFont(weight="bold"), text_color="#A78BFA").pack(anchor="w", padx=8, pady=(6, 2))
            ctk.CTkLabel(card, text=f"Step-wise Evaluation: {item['feedback']}", font=ctk.CTkFont(size=11), text_color="#E2E8F0", wraplength=600, justify="left").pack(anchor="w", padx=8, pady=(0, 6))

    def _export_docx_action(self):
        if not self.current_paper_data:
            messagebox.showwarning("No Exam", "Please generate an exam first.")
            return

        meta = self.current_paper_data.get("metadata", {})
        default_name = f"{meta.get('subject', 'Exam')}_{meta.get('exam_type', 'Terminal')}_Paper.docx".replace(" ", "_")
        dest = filedialog.asksaveasfilename(
            title="Save Microsoft Word (.docx) Exam Paper",
            initialfile=default_name,
            filetypes=[("Word Documents", "*.docx")]
        )
        if dest:
            try:
                docx_bytes = generate_exam_docx(self.current_paper_data, include_solutions=True)
                with open(dest, "wb") as f:
                    f.write(docx_bytes)
                messagebox.showinfo("Export Successful", f"Microsoft Word Exam Paper saved successfully to:\n{dest}")
            except Exception as e:
                messagebox.showerror("Export Failed", f"Could not save Word document: {e}")

    def _export_pdf_action(self):
        if not self.current_paper_data:
            messagebox.showwarning("No Exam", "Please generate or load an exam paper first.")
            return

        meta = self.current_paper_data.get("metadata", {})
        default_name = f"{meta.get('subject', 'Exam')}_{meta.get('exam_type', 'Terminal')}_Paper.pdf".replace(" ", "_")
        dest = filedialog.asksaveasfilename(
            title="Save Printable Exam PDF",
            initialfile=default_name,
            filetypes=[("PDF Files", "*.pdf")]
        )
        if dest:
            try:
                pdf_bytes = generate_exam_pdf(self.current_paper_data, include_solutions=True)
                with open(dest, "wb") as f:
                    f.write(pdf_bytes)
                messagebox.showinfo("Export Successful", f"Official Exam PDF generated and saved to:\n{dest}")
            except Exception as e:
                messagebox.showerror("Export Failed", f"Could not save PDF: {e}")

    def _copy_paper_action(self):
        if not self.current_paper_data:
            messagebox.showwarning("No Exam", "Please generate an exam first.")
            return
        text = self.txt_display_paper.get("1.0", "end-1c")
        self.clipboard_clear()
        self.clipboard_append(text)
        messagebox.showinfo("Copied", "Entire exam paper copied to clipboard!")

    def _refresh_history_cards(self):
        for widget in self.history_scroll.winfo_children():
            widget.destroy()

        saved = get_all_papers()
        if not saved:
            ctk.CTkLabel(self.history_scroll, text="No previously generated exams saved yet.", text_color="#9CA3AF").pack(pady=20)
            return

        for item in saved:
            card = ctk.CTkFrame(self.history_scroll, fg_color="#1E293B", corner_radius=8)
            card.pack(fill="x", pady=4, padx=4)

            title_str = f"📄 {item['subject_title']} ({item['exam_type']}) — {item['total_marks']} Marks\n📅 {item['created_at']}"
            ctk.CTkLabel(card, text=title_str, font=ctk.CTkFont(size=11, weight="bold"), justify="left", anchor="w").pack(side="left", padx=10, pady=8)

            btn_load = ctk.CTkButton(card, text="Load", width=70, height=26, fg_color="#2563EB", command=lambda uid=item['paper_uid']: self._load_saved(uid))
            btn_load.pack(side="right", padx=(4, 8), pady=6)

            btn_del = ctk.CTkButton(card, text="✕", width=32, height=26, fg_color="#991B1B", hover_color="#7F1D1D", command=lambda uid=item['paper_uid']: self._delete_saved(uid))
            btn_del.pack(side="right", padx=(2, 2), pady=6)

    def _load_saved(self, uid: str):
        paper_obj = get_paper_by_uid(uid)
        if paper_obj:
            self.current_paper_data = paper_obj["paper_content"]
            self.current_paper_uid = uid
            self._display_results(self.current_paper_data)
            self._build_mock_exam_ui(self.current_paper_data)
            messagebox.showinfo("Exam Loaded", f"Loaded '{paper_obj['subject_title']}' exam successfully!")

    def _delete_saved(self, uid: str):
        if messagebox.askyesno("Delete Exam", "Delete this saved exam paper from history?"):
            delete_paper(uid)
            self._refresh_history_cards()


def run_desktop_app():
    app = ModernExamMindApp()
    app.mainloop()


if __name__ == "__main__":
    run_desktop_app()
