import re
from typing import Dict, List, Any, Optional
from collections import Counter


class MaterialAnalyzer:
    @staticmethod
    def extract_topic_weightages(
        materials: Dict[str, List[Dict[str, Any]]],
        subject_info: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Analyzes lecture slides, assignments, and quizzes to detect covered topics and their weightages.
        """
        common_topics = subject_info.get("common_topics", [])
        combined_text = ""

        # Aggregate text from all uploaded material categories
        category_weights = {
            "slides": 1.0,
            "assignments": 1.5,
            "quizzes": 2.0,
            "midterms": 2.5,
            "past_papers": 1.0
        }

        topic_scores = {topic: 0.0 for topic in common_topics}
        detected_keywords = Counter()

        for category, docs in materials.items():
            cat_weight = category_weights.get(category, 1.0)
            for doc in docs:
                text = doc.get("text", "").lower()
                combined_text += "\n" + text
                
                # Check match against curated curriculum topics
                for topic in common_topics:
                    # Clean words for simple matching
                    keywords = [w.lower() for w in re.findall(r'\b[a-zA-Z]{4,}\b', topic)]
                    matched_words = sum(1 for kw in keywords if kw in text)
                    if matched_words > 0:
                        topic_scores[topic] += (matched_words * cat_weight)

        total_score = sum(topic_scores.values())
        weighted_topics = []
        if total_score > 0:
            for topic, score in topic_scores.items():
                if score > 0:
                    pct = round((score / total_score) * 100, 1)
                    weighted_topics.append({"topic": topic, "weight_pct": pct, "raw_score": score})
            weighted_topics.sort(key=lambda x: x["weight_pct"], reverse=True)
        else:
            # Equal distribution fallback
            if common_topics:
                pct = round(100.0 / len(common_topics), 1)
                for topic in common_topics:
                    weighted_topics.append({"topic": topic, "weight_pct": pct, "raw_score": 1.0})

        return {
            "weighted_topics": weighted_topics,
            "total_material_chars": len(combined_text),
            "sample_snippet": combined_text[:1500] if combined_text else ""
        }

    @staticmethod
    def analyze_past_paper_patterns(
        past_paper_docs: List[Dict[str, Any]],
        quizzes_docs: List[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Analyzes past exam papers and quizzes to determine the professor's question phrasing,
        difficulty level, and Bloom's cognitive distribution.
        """
        all_past_text = ""
        for doc in (past_paper_docs or []):
            all_past_text += "\n" + doc.get("text", "")
        for doc in (quizzes_docs or []):
            all_past_text += "\n" + doc.get("text", "")

        if not all_past_text.strip():
            return {
                "detected": False,
                "summary": "No past papers uploaded. Exam generated using official HEC standard distribution (Balanced: 25% Conceptual, 40% Application/Tracing, 35% Problem Solving & Design).",
                "coding_focus": "Moderate",
                "phrasing_style": "Standard HEC Academic Exam Format",
                "blooms_distribution": {"Remember/Understand": "30%", "Apply/Analyze": "45%", "Evaluate/Design": "25%"}
            }

        text_lower = all_past_text.lower()

        # Heuristic style detection
        code_keywords = ["write a code", "implement", "c++", "python", "function", "class", "pseudocode", "algorithm"]
        code_matches = sum(text_lower.count(k) for k in code_keywords)

        numerical_keywords = ["calculate", "solve", "evaluate", "compute", "trace", "step by step", "table"]
        numerical_matches = sum(text_lower.count(k) for k in numerical_keywords)

        theory_keywords = ["define", "explain", "differentiate", "compare", "what is", "discuss", "advantages"]
        theory_matches = sum(text_lower.count(k) for k in theory_keywords)

        total_matches = code_matches + numerical_matches + theory_matches or 1
        code_pct = round((code_matches / total_matches) * 100)
        num_pct = round((numerical_matches / total_matches) * 100)
        theo_pct = round((theory_matches / total_matches) * 100)

        # Style descriptor
        style_traits = []
        if code_pct > 35:
            style_traits.append("Heavy emphasis on practical coding & code tracing implementations")
        if num_pct > 30:
            style_traits.append("Frequent analytical, numerical, or step-by-step state table tracing questions")
        if theo_pct > 45:
            style_traits.append("Strong theoretical focus on conceptual comparisons and architectural trade-offs")
        if not style_traits:
            style_traits.append("Balanced blend of theory, tracing, and practical coding exercises")

        summary = (
            f"Detected Professor Style Profile: {', '.join(style_traits)}. "
            f"Past assessment trends indicate approx {code_pct}% coding/implementation, "
            f"{num_pct}% analytical/numerical tracing, and {theo_pct}% theoretical/conceptual questions. "
            f"ExamMind calibrated question difficulty and phrasing templates to mirror this exact style."
        )

        return {
            "detected": True,
            "summary": summary,
            "code_pct": code_pct,
            "numerical_pct": num_pct,
            "theory_pct": theo_pct,
            "style_traits": style_traits,
            "blooms_distribution": {
                "Remember/Understand (C1/C2)": f"{max(15, theo_pct - 10)}%",
                "Apply/Analyze (C3/C4)": f"{max(35, num_pct + 15)}%",
                "Evaluate/Design (C5/C6)": f"{max(20, code_pct + 10)}%"
            }
        }
