import io
from typing import Dict, Any, Optional
from pathlib import Path

try:
    import docx
    from docx.shared import Inches, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.oxml import OxmlElement, parse_xml
    from docx.oxml.ns import nsdecls, qn
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False


def generate_exam_docx(paper_data: Dict[str, Any], include_solutions: bool = True) -> bytes:
    """
    Generates a professionally formatted Microsoft Word (.docx) document for the exam paper.
    """
    if not DOCX_AVAILABLE:
        # Fallback to plain text bytes
        from engine.pdf_export import format_paper_as_text
        text = format_paper_as_text(paper_data, include_solutions)
        return text.encode("utf-8")

    doc = docx.Document()

    # Set 0.75 inch margins
    sections = doc.sections
    for s in sections:
        s.top_margin = Inches(0.75)
        s.bottom_margin = Inches(0.75)
        s.left_margin = Inches(0.75)
        s.right_margin = Inches(0.75)

    meta = paper_data.get("metadata", {})

    # 1. University Header
    p_header = doc.add_paragraph()
    p_header.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_uni = p_header.add_run(meta.get("university_header", "DEPARTMENT OF COMPUTER SCIENCE").upper())
    run_uni.bold = True
    run_uni.font.size = Pt(14)
    run_uni.font.color.rgb = RGBColor(30, 58, 138) # #1E3A8A Navy

    p_sub = doc.add_paragraph()
    p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_sub = p_sub.add_run(f"{meta.get('subject', 'Course Name')} ({meta.get('course_code', 'CS-000')}) — {meta.get('exam_type', 'Terminal')} Examination")
    run_sub.bold = True
    run_sub.font.size = Pt(11.5)
    run_sub.font.color.rgb = RGBColor(51, 65, 85)

    # 2. Exam Details Table
    table = doc.add_table(rows=1, cols=3)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False

    hdr_cells = table.rows[0].cells
    hdr_cells[0].width = Inches(2.5)
    hdr_cells[1].width = Inches(2.2)
    hdr_cells[2].width = Inches(2.3)

    p0 = hdr_cells[0].paragraphs[0]
    p0.add_run("Roll Number: _________________").bold = True
    p0.runs[0].font.size = Pt(9.5)

    p1 = hdr_cells[1].paragraphs[0]
    p1.add_run(f"Time Allowed: {meta.get('time_allowed', '2.5 Hours')}").bold = True
    p1.runs[0].font.size = Pt(9.5)

    p2 = hdr_cells[2].paragraphs[0]
    p2.add_run(f"Total Marks: {meta.get('total_marks', 50)} Marks").bold = True
    p2.runs[0].font.size = Pt(9.5)

    doc.add_paragraph() # Spacing

    # 3. Instructions Box
    instructions = meta.get("instructions", ["Attempt all questions.", "Assume any missing data reasonably."])
    p_inst = doc.add_paragraph()
    run_i_title = p_inst.add_run("General Instructions: ")
    run_i_title.bold = True
    run_i_title.font.size = Pt(9)
    run_i_body = p_inst.add_run(" | ".join(instructions))
    run_i_body.italic = True
    run_i_body.font.size = Pt(9)

    doc.add_paragraph("―" * 58)

    # 4. Section A: MCQs
    mcqs = paper_data.get("section_a_mcqs", [])
    if mcqs:
        p_sec_a = doc.add_paragraph()
        run_sa = p_sec_a.add_run(f"SECTION A: MULTIPLE CHOICE QUESTIONS [Total Marks: {sum(q.get('marks', 1) for q in mcqs):g}]")
        run_sa.bold = True
        run_sa.font.size = Pt(11)
        run_sa.font.color.rgb = RGBColor(30, 58, 138)

        for q in mcqs:
            q_num = q.get("q_number", 1)
            q_text = q.get("question", "")
            marks = q.get("marks", 1)
            clo = q.get("clo", "CLO1")
            blooms = q.get("blooms", "C2")

            pq = doc.add_paragraph()
            pq.add_run(f"Q{q_num}. {q_text} ").bold = True
            run_tag = pq.add_run(f"[{marks:g} Mark] [{clo} | {blooms}]")
            run_tag.italic = True
            run_tag.font.color.rgb = RGBColor(100, 116, 139)

            # 2-column or list options
            opts = q.get("options", [])
            for opt in opts:
                po = doc.add_paragraph()
                po.paragraph_format.left_indent = Inches(0.3)
                po.add_run(opt).font.size = Pt(9.5)

    # Section A Part II: True / False
    tf_list = paper_data.get("section_a_tf", [])
    if tf_list:
        p_sec_tf = doc.add_paragraph()
        run_stf = p_sec_tf.add_run(f"SECTION A (PART II): TRUE / FALSE QUESTIONS [Total Marks: {sum(q.get('marks', 1) for q in tf_list):g}]")
        run_stf.bold = True
        run_stf.font.size = Pt(11)
        run_stf.font.color.rgb = RGBColor(30, 58, 138)

        for q in tf_list:
            q_num = q.get("q_number", 1)
            stmt = q.get("statement", "")
            marks = q.get("marks", 1)
            clo = q.get("clo", "CLO1")

            ptf = doc.add_paragraph()
            ptf.add_run(f"{q_num}. [    ] {stmt} ").bold = True
            run_tag = ptf.add_run(f"[{marks:g} Mark] [{clo}]")
            run_tag.italic = True
            run_tag.font.color.rgb = RGBColor(100, 116, 139)

    # 5. Section B: Short Questions
    short_qs = paper_data.get("section_b_short", [])
    if short_qs:
        p_sec_b = doc.add_paragraph()
        run_sb = p_sec_b.add_run(f"\nSECTION B: SHORT ANSWER & ANALYTICAL QUESTIONS [Total Marks: {sum(q.get('marks', 5) for q in short_qs):g}]")
        run_sb.bold = True
        run_sb.font.size = Pt(11)
        run_sb.font.color.rgb = RGBColor(30, 58, 138)

        for q in short_qs:
            q_num = q.get("q_number", 1)
            q_text = q.get("question", "")
            marks = q.get("marks", 5)
            clo = q.get("clo", "CLO2")
            blooms = q.get("blooms", "C3")
            plos = ", ".join(q.get("mapped_plos", []))
            plo_str = f" | {plos}" if plos else ""

            ps = doc.add_paragraph()
            ps.add_run(f"Q{q_num}. {q_text}\n").bold = True
            run_tag = ps.add_run(f"[{marks:g} Marks] [{clo} | {blooms}{plo_str}]")
            run_tag.italic = True
            run_tag.font.color.rgb = RGBColor(100, 116, 139)

    # 6. Section C: Long Questions
    long_qs = paper_data.get("section_c_long", [])
    if long_qs:
        p_sec_c = doc.add_paragraph()
        run_sc = p_sec_c.add_run(f"\nSECTION C: LONG / COMPREHENSIVE / DESIGN QUESTIONS [Total Marks: {sum(q.get('marks', 10) for q in long_qs):g}]")
        run_sc.bold = True
        run_sc.font.size = Pt(11)
        run_sc.font.color.rgb = RGBColor(30, 58, 138)

        for q in long_qs:
            q_num = q.get("q_number", 1)
            q_text = q.get("question", "")
            marks = q.get("marks", 10)
            clo = q.get("clo", "CLO3")
            blooms = q.get("blooms", "C5")
            plos = ", ".join(q.get("mapped_plos", []))
            plo_str = f" | {plos}" if plos else ""

            pl = doc.add_paragraph()
            pl.add_run(f"Q{q_num}.\n{q_text}\n").bold = True
            run_tag = pl.add_run(f"[{marks:g} Marks] [{clo} | {blooms}{plo_str}]")
            run_tag.italic = True
            run_tag.font.color.rgb = RGBColor(100, 116, 139)

    # 7. Model Solutions & Rubrics Section
    if include_solutions and "marking_scheme_and_solutions" in paper_data:
        doc.add_page_break()

        p_sol_hdr = doc.add_paragraph()
        p_sol_hdr.alignment = WD_ALIGN_PARAGRAPH.CENTER
        rsh = p_sol_hdr.add_run("OFFICIAL MODEL SOLUTIONS & STEP-BY-STEP MARKING RUBRIC")
        rsh.bold = True
        rsh.font.size = Pt(14)
        rsh.font.color.rgb = RGBColor(16, 185, 129) # Emerald Green

        p_sol_sub = doc.add_paragraph()
        p_sol_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_sol_sub.add_run(f"Assessment Guide for {meta.get('subject')} ({meta.get('course_code')})").italic = True

        doc.add_paragraph("―" * 58)

        sol = paper_data["marking_scheme_and_solutions"]

        # MCQ Solutions
        if sol.get("mcq_solutions"):
            p_m_hdr = doc.add_paragraph()
            p_m_hdr.add_run("1. MCQ Answer Key & Explanations:").bold = True
            for s in sol["mcq_solutions"]:
                pm = doc.add_paragraph()
                pm.paragraph_format.left_indent = Inches(0.2)
                pm.add_run(f"• Q{s.get('q_number')}: Option [{s.get('correct_option')}] — ").bold = True
                pm.add_run(s.get("explanation", ""))

        # Short Solutions
        if sol.get("short_solutions"):
            p_s_hdr = doc.add_paragraph()
            p_s_hdr.add_run("\n2. Section B Model Answers & Step-by-Step Rubrics:").bold = True
            for s in sol["short_solutions"]:
                psol = doc.add_paragraph()
                psol.add_run(f"Q{s.get('q_number')} Model Answer:\n").bold = True
                psol.add_run(s.get("model_answer", "") + "\n")
                r_run = psol.add_run(f"Marking Rubric: {s.get('rubric', '')}")
                r_run.italic = True
                r_run.font.color.rgb = RGBColor(37, 99, 235)

        # Long Solutions
        if sol.get("long_solutions"):
            p_l_hdr = doc.add_paragraph()
            p_l_hdr.add_run("\n3. Section C Comprehensive Solutions & Rubrics:").bold = True
            for s in sol["long_solutions"]:
                plsol = doc.add_paragraph()
                plsol.add_run(f"Q{s.get('q_number')} Comprehensive Solution:\n").bold = True
                plsol.add_run(s.get("model_answer", "") + "\n")
                r_run = plsol.add_run(f"Step-wise Rubric: {s.get('rubric', '')}")
                r_run.italic = True
                r_run.font.color.rgb = RGBColor(37, 99, 235)

    buffer = io.BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()
