import os
import json
import re
import urllib.request
import urllib.error
from typing import Dict, List, Any, Optional
from pathlib import Path
from curriculum.loader import curriculum_repo

# Load .env file automatically if present
ENV_PATH = Path(__file__).resolve().parent.parent / ".env"
if ENV_PATH.exists():
    try:
        with open(ENV_PATH, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
    except Exception:
        pass


class ExamGenerator:
    def __init__(self, gemini_api_key: Optional[str] = None, groq_api_key: Optional[str] = None):
        self.gemini_api_key = gemini_api_key or os.environ.get("GEMINI_API_KEY", "")
        self.groq_api_key = groq_api_key or os.environ.get("GROQ_API_KEY", "")

    def _call_gemini_rest(self, prompt: str, model: str = "gemini-3.6-flash") -> str:
        """Call Gemini REST API directly with automatic model fallback."""
        if not self.gemini_api_key:
            raise ValueError("Gemini API Key is missing. Please provide a valid key.")

        models_to_try = [model, "gemini-3.6-flash", "gemini-3.7-flash", "gemini-flash-latest", "gemini-2.5-flash", "gemini-1.5-flash"]
        # Deduplicate while preserving order
        models_to_try = list(dict.fromkeys(models_to_try))

        last_error = None
        for m in models_to_try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{m}:generateContent?key={self.gemini_api_key}"
            payload = {
                "contents": [
                    {
                        "parts": [{"text": prompt}]
                    }
                ],
                "generationConfig": {
                    "temperature": 0.3,
                    "topP": 0.95,
                    "maxOutputTokens": 8192
                }
            }
            
            req = urllib.request.Request(
                url,
                data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json"}
            )
            
            try:
                with urllib.request.urlopen(req, timeout=90) as response:
                    res_data = json.loads(response.read().decode("utf-8"))
                    candidates = res_data.get("candidates", [])
                    if candidates:
                        return candidates[0]["content"]["parts"][0]["text"]
            except urllib.error.HTTPError as e:
                err_msg = e.read().decode("utf-8")
                last_error = f"HTTP Error {e.code} for {m}: {err_msg}"
                continue
            except Exception as e:
                last_error = str(e)
                continue

        raise RuntimeError(f"Gemini API request failed across models. Last error: {last_error}")

    def _call_groq_rest(self, prompt: str, model: str = "llama-3.3-70b-versatile") -> str:
        """Call Groq REST API directly."""
        if not self.groq_api_key:
            raise ValueError("Groq API Key is missing.")

        url = "https://api.groq.com/openai/v1/chat/completions"
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": "You are ExamMind AI, a university-level computer science exam generation engine aligned with HEC Pakistan OBE standards."},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.3,
            "max_tokens": 8000
        }
        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.groq_api_key}"
            }
        )
        with urllib.request.urlopen(req, timeout=90) as response:
            res_data = json.loads(response.read().decode("utf-8"))
            return res_data["choices"][0]["message"]["content"]

    def generate_exam_paper(
        self,
        subject_slug: str,
        exam_type: str,
        pattern: Dict[str, Any],
        verbal_instructions: str = "",
        uploaded_summary: str = "",
        material_analysis: Optional[Dict[str, Any]] = None,
        style_analysis: Optional[Dict[str, Any]] = None,
        document_context: Optional[Dict[str, str]] = None,
        rigor_level: str = "Standard HEC",
        university_header: str = "Department of Computer Science — Examination Paper",
        llm_provider: str = "gemini"
    ) -> Dict[str, Any]:
        """
        Generates practice exam paper, model solutions, and rubric aligned with HEC CLOs/PLOs.
        """
        subject_data = curriculum_repo.get_subject_by_slug(subject_slug)
        if not subject_data:
            raise ValueError(f"Subject '{subject_slug}' not found in HEC curriculum database.")

        clos_list = subject_data.get("clos", [])
        clos_formatted = "\n".join([
            f"- [{clo['id']}] {clo['text']} (Bloom's: {clo['blooms_level']}, Mapped PLOs: {', '.join(clo.get('mapped_plos', []))})"
            for clo in clos_list
        ])

        topics_formatted = "\n".join([f"- {t}" for t in subject_data.get("common_topics", [])])

        # Topics from uploaded materials
        weighted_topics_str = "Standard curriculum topic coverage"
        if material_analysis and material_analysis.get("weighted_topics"):
            weighted_topics_str = "\n".join([
                f"- {item['topic']} (Weightage: {item['weight_pct']}%)"
                for item in material_analysis.get("weighted_topics", [])[:8]
            ])

        style_summary = style_analysis.get("summary", "Standard HEC university format") if style_analysis else "Standard HEC university format"

        # Construct Document Context Injection
        doc_context_str = ""
        if document_context:
            if document_context.get("slides_content"):
                doc_context_str += f"\n### 📖 EXTRACTED LECTURE SLIDES & NOTES (DERIVE CORE PROBLEMS & EMPHASIS FROM HERE):\n{document_context['slides_content']}\n"
            if document_context.get("assignments_content"):
                doc_context_str += f"\n### 💻 EXTRACTED ASSIGNMENT PROBLEMS (GENERATE QUESTIONS OF SIMILAR RIGOR & PROBLEM TYPES):\n{document_context['assignments_content']}\n"
            if document_context.get("quizzes_content"):
                doc_context_str += f"\n### ✍️ EXTRACTED RECENT QUIZZES (CALIBRATE PROFESSOR QUESTION PHRASING & TOPIC FOCUS):\n{document_context['quizzes_content']}\n"
            if document_context.get("past_papers_content"):
                doc_context_str += f"\n### 📜 EXTRACTED PAST EXAM PAPERS (FOR DIFFICULTY REFERENCE — DO NOT REUSE VERBATIM):\n{document_context['past_papers_content']}\n"

        rigor_desc = {
            "Foundational": "Foundational Level: 30% direct/basic concept questions, 70% standard application & tracing.",
            "Standard HEC": "Standard HEC Pakistan University Level: High quality balance of algorithmic tracing, scenario design, and solid concepts.",
            "High Rigor (FAST-Style)": "High Rigor (FAST-NUCES / NUST Level Boss Mode): Heavy emphasis on tricky edge cases, deep code tracing, complex multi-part design scenarios, and formal complexity derivations."
        }.get(rigor_level, "Standard HEC Pakistan University Level.")

        # Build prompt
        verbal_priority_block = ""
        if verbal_instructions.strip():
            verbal_priority_block = f"""
========================================================================================
🚨 SUPREME DIRECTIVE — PROFESSOR'S VERBAL HINTS & MANDATORY TOPIC CONSTRAINTS:
"{verbal_instructions.strip()}"
========================================================================================
CRITICAL INSTRUCTION: The professor's verbal hints above are your HIGHEST PRIORITY.
1. YOU MUST BASE ALL OR THE VAST MAJORITY OF QUESTIONS (MCQs, Short Questions, Long Questions) DIRECTLY ON THE TOPICS, ALGORITHMS, AND CONSTRAINTS LISTED IN THE PROFESSOR'S VERBAL HINTS ABOVE.
2. If specific topics/algorithms are listed (e.g., A*, BFS, DFS, Minimax, Alpha-Beta Pruning, Neural Networks, KNN, K-Means, Dynamic Programming, AVL Trees, etc.), craft realistic, top-tier engineering problems centered on EACH of these specific topics.
3. If specific chapters/topics are excluded (e.g., 'No Chapter 4', 'No numericals'), strictly obey the exclusion — do NOT include any questions from those excluded domains.
"""

        prompt = f"""
You are the Chief Examination Master for BS Computer Science at a premier Pakistani Engineering & Computing University accredited by NCEAC / HEC Pakistan.
Generate a top-notch, highly realistic, and academically authentic university practice examination paper for the following subject:

### SUBJECT DETAILS:
- Subject Title: {subject_data.get('title')} ({subject_data.get('code', 'CS')})
- Course Category: {subject_data.get('category')}
- Degree: BS Computer Science (4-Year HEC Undergraduate Curriculum 2025/2026)
- Exam Type: {exam_type} Examination
- University / Institute Header: {university_header}
- Rigor Level: {rigor_desc}

{verbal_priority_block}

### OFFICIAL HEC COURSE LEARNING OUTCOMES (CLOs) & PLOs:
{clos_formatted}

### COURSE TOPICS & EXTRACTED WEIGHTAGES:
{weighted_topics_str}

### PROFESSOR ASSESSMENT PATTERN & STYLE PROFILE:
{style_summary}
{doc_context_str}
### EXAMINATION STRUCTURE & MARKS SPECIFICATION:
- Total Exam Marks: {pattern.get('total_marks')} Marks
- Section A - Multiple Choice Questions (MCQs): {pattern.get('mcq_count')} questions × {pattern.get('mcq_marks_each')} marks each = {pattern.get('mcq_count', 0) * pattern.get('mcq_marks_each', 1)} Marks
- Section A (Optional) - True/False Questions: {pattern.get('tf_count', 0)} questions × {pattern.get('tf_marks_each', 1)} marks each = {pattern.get('tf_count', 0) * pattern.get('tf_marks_each', 1)} Marks
- Section B - Short Answer / Conceptual / Tracing Questions: {pattern.get('short_count')} questions × {pattern.get('short_marks_each')} marks each = {pattern.get('short_count', 0) * pattern.get('short_marks_each', 5)} Marks
- Section C - Long / Design / Comprehensive / Scenario Questions: {pattern.get('long_count')} questions × {pattern.get('long_marks_each')} marks each = {pattern.get('long_count', 0) * pattern.get('long_marks_each', 10)} Marks

### TOP-NOTCH QUESTION DESIGN STANDARDS:
1. CLO & BLOOM'S TAGGING: Every single question MUST be explicitly tagged with its matching CLO (e.g., [CLO1], [CLO2]), its Bloom's Taxonomy Level (e.g., C2-Understand, C3-Apply, C4-Analyze, C5-Evaluate, C6-Create), and its mapped Seoul Accord PLOs.
2. ENGINEERING RIGOR: Frame questions in realistic engineering scenarios (e.g., autonomous navigation, database transaction deadlocks, distributed cache invalidation, neural net backpropagation, compiler AST generation).
3. CODE & NUMERICALS: Include clean syntax code blocks (C++, Java, Python, or SQL as appropriate), memory trace tables, state diagrams, or numerical calculations.
4. MODEL ANSWERS & STEP-BY-STEP RUBRIC: For every question, write a complete, academically flawless model answer and an itemized marking rubric detailing exact partial credit distribution.
5. NO TRIVIAL QUESTIONS: Avoid simple regurgitation. Test deep conceptual understanding, algorithm mechanics, boundary conditions, and design trade-offs.
6. OUTPUT FORMAT: Return a valid JSON object strictly enclosed between ```json and ``` code fence.

### REQUIRED JSON SCHEMA:
{{
  "metadata": {{
    "university_header": "{university_header}",
    "subject": "{subject_data.get('title')}",
    "course_code": "{subject_data.get('code')}",
    "exam_type": "{exam_type}",
    "total_marks": {pattern.get('total_marks')},
    "time_allowed": "2.5 Hours",
    "instructions": ["Attempt all questions.", "Programmable calculators are not allowed.", "Assume any missing data reasonably and state it clearly."]
  }},
  "section_a_mcqs": [
    {{
      "q_number": 1,
      "question": "Question text...",
      "options": ["A) option1", "B) option2", "C) option3", "D) option4"],
      "marks": {pattern.get('mcq_marks_each')},
      "clo": "CLO1",
      "blooms": "C2 - Understand"
    }}
  ],
  "section_a_tf": [
    {{
      "q_number": 1,
      "statement": "Statement text...",
      "marks": {pattern.get('tf_marks_each', 1)},
      "clo": "CLO1",
      "blooms": "C2 - Understand"
    }}
  ],
  "section_b_short": [
    {{
      "q_number": 1,
      "question": "Detailed short question...",
      "marks": {pattern.get('short_marks_each')},
      "clo": "CLO2",
      "blooms": "C3 - Apply",
      "mapped_plos": ["PLO3"]
    }}
  ],
  "section_c_long": [
    {{
      "q_number": 1,
      "question": "Comprehensive long/scenario/coding problem with subparts (a), (b) if needed...",
      "marks": {pattern.get('long_marks_each')},
      "clo": "CLO3",
      "blooms": "C5 - Design",
      "mapped_plos": ["PLO4"]
    }}
  ],
  "marking_scheme_and_solutions": {{
    "mcq_solutions": [
      {{"q_number": 1, "correct_option": "A", "explanation": "Brief reasoning..."}}
    ],
    "tf_solutions": [
      {{"q_number": 1, "correct_value": "True", "explanation": "Brief reasoning..."}}
    ],
    "short_solutions": [
      {{
        "q_number": 1,
        "model_answer": "Complete step-by-step model solution...",
        "rubric": "Rubric: 2 marks for key concept, 2 marks for diagram/code, 1 mark for explanation."
      }}
    ],
    "long_solutions": [
      {{
        "q_number": 1,
        "model_answer": "In-depth model answer including code, derivation, or architectural design...",
        "rubric": "Step-wise grading breakdown: (a) Algorithm formulation: 4 marks, (b) Correct complexity proof: 3 marks, (c) Edge case handling: 3 marks."
      }}
    ]
  }},
  "pattern_analysis_summary": "Comprehensive explanation of how this paper aligns with the professor's past trends, verbal constraints, and HEC curriculum distribution."
}}
"""

        raw_response = ""
        # Try LLM providers
        if self.gemini_api_key and llm_provider == "gemini":
            try:
                raw_response = self._call_gemini_rest(prompt)
            except Exception as e:
                print(f"Gemini API error: {e}. Falling back to intelligent exam synthesizer.")
                raw_response = ""
        elif self.groq_api_key and llm_provider == "groq":
            try:
                raw_response = self._call_groq_rest(prompt)
            except Exception as e:
                print(f"Groq API error: {e}. Falling back to intelligent exam synthesizer.")
                raw_response = ""

        if raw_response:
            parsed = self._extract_json_from_response(raw_response)
            if parsed:
                if "metadata" in parsed and university_header:
                    parsed["metadata"]["university_header"] = university_header
                return parsed

        # Offline / Fallback Intelligent Exam Synthesizer
        return self._generate_offline_synthesized_exam(
            subject_data=subject_data,
            exam_type=exam_type,
            pattern=pattern,
            verbal_instructions=verbal_instructions,
            style_summary=style_summary,
            university_header=university_header
        )

    def _extract_json_from_response(self, text: str) -> Optional[Dict[str, Any]]:
        """Extract and parse JSON from Markdown code blocks or plain text."""
        # Try direct match inside json code fence
        match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", text)
        if match:
            json_str = match.group(1).strip()
            try:
                return json.loads(json_str)
            except Exception:
                pass
        # Try raw json
        try:
            return json.loads(text.strip())
        except Exception:
            pass
        return None

    def _generate_offline_synthesized_exam(
        self,
        subject_data: Dict[str, Any],
        exam_type: str,
        pattern: Dict[str, Any],
        verbal_instructions: str,
        style_summary: str,
        university_header: str = "Department of Computer Science — Examination Paper"
    ) -> Dict[str, Any]:
        """
        High-fidelity curriculum-aligned offline exam generator when API key is not yet configured.
        """
        title = subject_data.get("title", "Computer Science")
        code = subject_data.get("code", "CS-101")
        clos = subject_data.get("clos", [])
        topics = subject_data.get("common_topics", ["Core Concepts", "Algorithms", "System Design"])

        mcq_count = int(pattern.get("mcq_count", 10))
        mcq_marks = float(pattern.get("mcq_marks_each", 1.0))
        tf_count = int(pattern.get("tf_count", 0))
        tf_marks = float(pattern.get("tf_marks_each", 1.0))
        short_count = int(pattern.get("short_count", 4))
        short_marks = float(pattern.get("short_marks_each", 5.0))
        long_count = int(pattern.get("long_count", 2))
        long_marks = float(pattern.get("long_marks_each", 10.0))

        # Sample dynamic questions based on subject topics
        sample_mcqs = []
        sample_mcq_solutions = []
        for i in range(mcq_count):
            clo_item = clos[i % len(clos)]
            topic = topics[i % len(topics)]
            q_num = i + 1
            sample_mcqs.append({
                "q_number": q_num,
                "question": f"In {title}, which of the following best characterizes the primary operational mechanism or property of '{topic}'?",
                "options": [
                    f"A) Provides deterministic time-bound complexity guarantees under optimal conditions",
                    f"B) Eliminates state-space redundancy by dynamic partitioning",
                    f"C) Restricts invariant violation through strict encapsulation and normalization",
                    f"D) Enforces asynchronous fault tolerance across distributed memory"
                ],
                "marks": mcq_marks,
                "clo": clo_item.get("id", "CLO1"),
                "blooms": clo_item.get("blooms_level", "C2 - Understand")
            })
            sample_mcq_solutions.append({
                "q_number": q_num,
                "correct_option": "A",
                "explanation": f"Option A accurately reflects the standard architectural definition of {topic} as formulated in the HEC curriculum guidelines."
            })

        sample_tf = []
        sample_tf_solutions = []
        for i in range(tf_count):
            clo_item = clos[i % len(clos)]
            topic = topics[(i + 2) % len(topics)]
            q_num = i + 1
            sample_tf.append({
                "q_number": q_num,
                "statement": f"In {title}, the asymptotic upper bound of '{topic}' is strictly invariant regardless of the underlying memory representation.",
                "marks": tf_marks,
                "clo": clo_item.get("id", "CLO1"),
                "blooms": "C2 - Understand"
            })
            sample_tf_solutions.append({
                "q_number": q_num,
                "correct_value": "False",
                "explanation": f"Different memory structures (e.g. contiguous arrays vs pointer-linked chains) alter traversal, cache locality, and runtime bounds for {topic}."
            })

        sample_short = []
        sample_short_solutions = []
        short_scenarios = [
            ("Differentiate and Analyze", "Differentiate between the structural trade-offs of contiguous allocation versus linked node representation in the context of {topic}. Provide a concise diagram or pseudocode snippet illustrating pointer manipulation.", "C4 - Analyze"),
            ("Algorithmic Tracing", "Trace the state transitions or memory execution steps for {topic} given an edge-case scenario with n=5 elements. Construct the intermediate execution table.", "C3 - Apply"),
            ("Complexity & Invariant Verification", "State the core invariant of {topic}. Formulate a formal argument proving how this invariant prevents race conditions or state corruption.", "C3 - Apply"),
            ("Scenario-based Optimization", "A real-time banking system experiences high latency during peak transaction intervals. Explain how re-engineering the {topic} schema resolves the bottleneck.", "C4 - Analyze"),
            ("Failure & Error Handling", "Analyze two common exception failure modes associated with {topic} and propose robust error mitigation strategies.", "C3 - Apply")
        ]

        for i in range(short_count):
            clo_item = clos[(i + 1) % len(clos)]
            topic = topics[(i + 1) % len(topics)]
            q_num = i + 1
            s_type, s_template, blooms = short_scenarios[i % len(short_scenarios)]
            q_text = s_template.format(topic=topic)
            sample_short.append({
                "q_number": q_num,
                "question": f"[{s_type}] {q_text}",
                "marks": short_marks,
                "clo": clo_item.get("id", "CLO2"),
                "blooms": blooms,
                "mapped_plos": clo_item.get("mapped_plos", ["PLO2", "PLO3"])
            })
            sample_short_solutions.append({
                "q_number": q_num,
                "model_answer": f"1. Conceptual Definition: Detailed breakdown of {topic}.\n2. Mathematical / Code Representation: Clear implementation demonstrating step-by-step transitions.\n3. Comparison & Trade-off: Analysis of time complexity vs memory overhead.",
                "rubric": f"Marking Rubric ({short_marks:g} Marks Total):\n- Concept Definition & Precision: {short_marks * 0.4:g} Marks\n- Diagram / Tracing / Code snippet: {short_marks * 0.4:g} Marks\n- Technical explanation & edge cases: {short_marks * 0.2:g} Marks"
            })

        sample_long = []
        sample_long_solutions = []
        long_scenarios = [
            ("System Architecture & Implementation", "Design a complete, modular solution for a high-concurrency university management system utilizing {topic1} and {topic2}.\n\n(a) Formulate the architectural diagram or Class/ER schema detailing all entities, relationships, and invariants. [50% Marks]\n(b) Write an efficient, well-documented implementation (C++/Java/Python) demonstrating core methods, exception safety, and optimal complexity. [50% Marks]", "C5 - Design"),
            ("Algorithmic Synthesis & Proof", "Consider a large-scale computational pipeline centered on {topic1}.\n\n(a) Develop a comprehensive divide-and-conquer or dynamic programming algorithm to solve this optimization problem. [50% Marks]\n(b) Prove algorithm correctness using Loop Invariants or Mathematical Induction, and derive its tight asymptotic bound O(n). [50% Marks]", "C6 - Create"),
            ("Case Study: System Re-engineering & Optimization", "An enterprise web portal crashes under high I/O workloads due to unoptimized {topic1} structures.\n\n(a) Identify and analyze three architectural failure points. [40% Marks]\n(b) Redesign the subsystem utilizing modern paradigms, providing normalized schemas or concurrency control mechanisms. [60% Marks]", "C5 - Design")
        ]

        for i in range(long_count):
            clo_item = clos[(i + 2) % len(clos)]
            topic1 = topics[(i * 2) % len(topics)]
            topic2 = topics[(i * 2 + 1) % len(topics)]
            q_num = i + 1
            l_title, l_template, blooms = long_scenarios[i % len(long_scenarios)]
            q_text = l_template.format(topic1=topic1, topic2=topic2)
            sample_long.append({
                "q_number": q_num,
                "question": f"Question {q_num} ({long_marks:g} Marks) — [{l_title}]\n{q_text}",
                "marks": long_marks,
                "clo": clo_item.get("id", "CLO3"),
                "blooms": blooms,
                "mapped_plos": clo_item.get("mapped_plos", ["PLO3", "PLO4"])
            })
            sample_long_solutions.append({
                "q_number": q_num,
                "model_answer": f"Part (a) Comprehensive architectural schema and entity design with full structural normalization.\nPart (b) Production-ready code implementation including proper parameter types, boundary validation, and asymptotic Big-O runtime analysis.",
                "rubric": f"Marking Breakdown ({long_marks:g} Marks Total):\n- Architectural/Schematic Design & Soundness: {long_marks * 0.4:g} Marks\n- Algorithmic/Code Implementation & Logic: {long_marks * 0.4:g} Marks\n- Formal Proof, Complexity Analysis, & Boundary Testing: {long_marks * 0.2:g} Marks"
            })

        pattern_summary = (
            f"Exam paper synthesized adhering strictly to HEC Pakistan 2025/2026 BS Computer Science Curriculum for {title}. "
            f"All questions are mapped directly to official Course Learning Outcomes ({', '.join([c['id'] for c in clos])}) "
            f"and Seoul Accord Graduate Attributes (PLOs). "
            f"Mark balance verified: Total Marks = {pattern.get('total_marks')}."
        )

        return {
            "metadata": {
                "university_header": university_header,
                "subject": title,
                "course_code": code,
                "exam_type": exam_type,
                "total_marks": int(pattern.get("total_marks", 50)),
                "time_allowed": "2.5 Hours",
                "instructions": [
                    "Attempt all questions.",
                    "Programmable calculators and unauthorized electronic devices are strictly prohibited.",
                    "State any necessary assumptions clearly and justify algorithm complexity steps."
                ]
            },
            "section_a_mcqs": sample_mcqs,
            "section_a_tf": sample_tf,
            "section_b_short": sample_short,
            "section_c_long": sample_long,
            "marking_scheme_and_solutions": {
                "mcq_solutions": sample_mcq_solutions,
                "tf_solutions": sample_tf_solutions,
                "short_solutions": sample_short_solutions,
                "long_solutions": sample_long_solutions
            },
            "pattern_analysis_summary": pattern_summary
        }
