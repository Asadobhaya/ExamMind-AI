import os
import json
import re
import urllib.request
from typing import Dict, List, Any, Optional


class ExamGrader:
    def __init__(self, gemini_api_key: Optional[str] = None):
        self.gemini_api_key = gemini_api_key or os.environ.get("GEMINI_API_KEY", "")

    def grade_student_exam(
        self,
        paper_data: Dict[str, Any],
        student_answers: Dict[str, Any],
        use_llm: bool = True
    ) -> Dict[str, Any]:
        """
        Grades student's answers against model answers and rubrics.
        """
        meta = paper_data.get("metadata", {})
        total_exam_marks = meta.get("total_marks", 50)
        sol = paper_data.get("marking_scheme_and_solutions", {})

        # Step 1: Automatic Exact Match for MCQs and True/False
        mcq_evaluations = []
        mcq_score = 0.0
        mcq_max = 0.0
        for q in paper_data.get("section_a_mcqs", []):
            q_num = q.get("q_number")
            q_marks = q.get("marks", 1.0)
            mcq_max += q_marks
            
            # Find correct option
            correct_opt = ""
            expl = ""
            for s in sol.get("mcq_solutions", []):
                if s.get("q_number") == q_num:
                    correct_opt = str(s.get("correct_option", "")).strip().upper()
                    expl = s.get("explanation", "")
                    break

            student_choice = str(student_answers.get(f"mcq_{q_num}", "")).strip().upper()
            
            # Normalize choice (e.g. "A) ..." -> "A")
            norm_student = student_choice[0] if student_choice else ""
            norm_correct = correct_opt[0] if correct_opt else ""

            is_correct = (norm_student == norm_correct) and bool(norm_student)
            awarded = q_marks if is_correct else 0.0
            mcq_score += awarded

            mcq_evaluations.append({
                "q_number": q_num,
                "question": q.get("question", ""),
                "student_answer": student_choice or "[Not Attempted]",
                "correct_answer": correct_opt,
                "marks_awarded": awarded,
                "max_marks": q_marks,
                "is_correct": is_correct,
                "clo": q.get("clo", "CLO1"),
                "feedback": "Correct selection!" if is_correct else f"Incorrect. Correct option is [{correct_opt}]. {expl}"
            })

        # True / False
        tf_evaluations = []
        tf_score = 0.0
        tf_max = 0.0
        for q in paper_data.get("section_a_tf", []):
            q_num = q.get("q_number")
            q_marks = q.get("marks", 1.0)
            tf_max += q_marks

            correct_val = ""
            expl = ""
            for s in sol.get("tf_solutions", []):
                if s.get("q_number") == q_num:
                    correct_val = str(s.get("correct_value", "")).strip().capitalize()
                    expl = s.get("explanation", "")
                    break

            student_val = str(student_answers.get(f"tf_{q_num}", "")).strip().capitalize()
            is_correct = (student_val == correct_val) and bool(student_val)
            awarded = q_marks if is_correct else 0.0
            tf_score += awarded

            tf_evaluations.append({
                "q_number": q_num,
                "statement": q.get("statement", ""),
                "student_answer": student_val or "[Not Attempted]",
                "correct_answer": correct_val,
                "marks_awarded": awarded,
                "max_marks": q_marks,
                "is_correct": is_correct,
                "clo": q.get("clo", "CLO1"),
                "feedback": "Correct!" if is_correct else f"Incorrect. Statement is {correct_val}. {expl}"
            })

        # Step 2: Subjective Questions Grading (Short & Long) via LLM / Rubric Evaluator
        short_evaluations = []
        long_evaluations = []
        
        if use_llm and self.gemini_api_key:
            try:
                llm_eval = self._grade_subjective_with_llm(paper_data, student_answers)
                short_evaluations = llm_eval.get("short_evaluations", [])
                long_evaluations = llm_eval.get("long_evaluations", [])
            except Exception as e:
                print(f"LLM grading failed ({e}), falling back to heuristic rubric grading.")
                short_evaluations, long_evaluations = self._grade_subjective_heuristic(paper_data, student_answers)
        else:
            short_evaluations, long_evaluations = self._grade_subjective_heuristic(paper_data, student_answers)

        short_score = sum(item.get("marks_awarded", 0.0) for item in short_evaluations)
        short_max = sum(item.get("max_marks", 5.0) for item in short_evaluations)

        long_score = sum(item.get("marks_awarded", 0.0) for item in long_evaluations)
        long_max = sum(item.get("max_marks", 10.0) for item in long_evaluations)

        total_obtained = mcq_score + tf_score + short_score + long_score
        total_possible = mcq_max + tf_max + short_max + long_max or total_exam_marks

        percentage = round((total_obtained / total_possible) * 100, 1) if total_possible > 0 else 0.0
        letter_grade = self._get_pakistan_gpa_grade(percentage)

        # Step 3: CLO Attainment Diagnostics
        clo_stats = {}
        all_evals = mcq_evaluations + tf_evaluations + short_evaluations + long_evaluations
        for item in all_evals:
            clo_id = item.get("clo", "CLO1")
            if clo_id not in clo_stats:
                clo_stats[clo_id] = {"obtained": 0.0, "total": 0.0}
            clo_stats[clo_id]["obtained"] += item.get("marks_awarded", 0.0)
            clo_stats[clo_id]["total"] += item.get("max_marks", 1.0)

        clo_diagnostics = []
        for clo_id, stats in clo_stats.items():
            pct = round((stats["obtained"] / stats["total"]) * 100, 1) if stats["total"] > 0 else 0
            status = "Mastered (>=80%)" if pct >= 80 else ("Satisfactory (>=60%)" if pct >= 60 else "Needs Revision (<60%)")
            clo_diagnostics.append({
                "clo": clo_id,
                "obtained": stats["obtained"],
                "total": stats["total"],
                "percentage": pct,
                "status": status
            })

        return {
            "summary": {
                "total_obtained": total_obtained,
                "total_possible": total_possible,
                "percentage": percentage,
                "grade": letter_grade,
                "subject": meta.get("subject", "Course"),
                "exam_type": meta.get("exam_type", "Exam")
            },
            "mcq_evaluations": mcq_evaluations,
            "tf_evaluations": tf_evaluations,
            "short_evaluations": short_evaluations,
            "long_evaluations": long_evaluations,
            "clo_diagnostics": clo_diagnostics
        }

    def _grade_subjective_with_llm(self, paper_data: Dict[str, Any], student_answers: Dict[str, Any]) -> Dict[str, Any]:
        """Calls Gemini to grade subjective written and coding answers strictly against the rubric."""
        short_qs = paper_data.get("section_b_short", [])
        long_qs = paper_data.get("section_c_long", [])
        solutions = paper_data.get("marking_scheme_and_solutions", {})

        short_sub_list = []
        for q in short_qs:
            q_num = q.get("q_number")
            ans = student_answers.get(f"short_{q_num}", "").strip()
            sol_match = next((s for s in solutions.get("short_solutions", []) if s.get("q_number") == q_num), {})
            short_sub_list.append({
                "q_number": q_num,
                "question": q.get("question"),
                "max_marks": q.get("marks", 5.0),
                "clo": q.get("clo", "CLO2"),
                "model_answer": sol_match.get("model_answer", ""),
                "rubric": sol_match.get("rubric", ""),
                "student_answer": ans or "[Unattempted]"
            })

        long_sub_list = []
        for q in long_qs:
            q_num = q.get("q_number")
            ans = student_answers.get(f"long_{q_num}", "").strip()
            sol_match = next((s for s in solutions.get("long_solutions", []) if s.get("q_number") == q_num), {})
            long_sub_list.append({
                "q_number": q_num,
                "question": q.get("question"),
                "max_marks": q.get("marks", 10.0),
                "clo": q.get("clo", "CLO3"),
                "model_answer": sol_match.get("model_answer", ""),
                "rubric": sol_match.get("rubric", ""),
                "student_answer": ans or "[Unattempted]"
            })

        prompt = f"""
You are an expert Computer Science Professor in Pakistan evaluating university exam submissions under HEC Outcome-Based Education (OBE) rules.
Grade the student's written/coding answers below strictly against the provided model answer and marking rubric.
Award fair partial marks based on conceptual understanding, correct logic, and addressing key requirements.

### SUBMISSIONS TO EVALUATE:
SHORT QUESTIONS:
{json.dumps(short_sub_list, indent=2)}

LONG QUESTIONS:
{json.dumps(long_sub_list, indent=2)}

### OUTPUT FORMAT:
Return a valid JSON object strictly enclosed between ```json and ``` code fence matching this schema:
{{
  "short_evaluations": [
    {{
      "q_number": 1,
      "question": "question text",
      "student_answer": "student answer",
      "marks_awarded": 4.0,
      "max_marks": 5.0,
      "clo": "CLO2",
      "feedback": "Concise constructive feedback explaining why marks were awarded or deducted..."
    }}
  ],
  "long_evaluations": [
    {{
      "q_number": 1,
      "question": "question text",
      "student_answer": "student answer",
      "marks_awarded": 8.5,
      "max_marks": 10.0,
      "clo": "CLO3",
      "feedback": "Step-by-step breakdown of marks: Part (a) 4/4, Part (b) 4.5/6 due to missing edge case check."
    }}
  ]
}}
"""
        from engine.generator import ExamGenerator
        gen = ExamGenerator(gemini_api_key=self.gemini_api_key)
        raw = gen._call_gemini_rest(prompt)
        match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", raw)
        json_str = match.group(1).strip() if match else raw.strip()
        return json.loads(json_str)

    def _grade_subjective_heuristic(self, paper_data: Dict[str, Any], student_answers: Dict[str, Any]):
        """Intelligent heuristic rubric grading when LLM is offline."""
        short_evals = []
        for q in paper_data.get("section_b_short", []):
            q_num = q.get("q_number")
            max_m = float(q.get("marks", 5.0))
            ans = str(student_answers.get(f"short_{q_num}", "")).strip()
            
            if not ans or ans == "[Not Attempted]":
                awarded = 0.0
                feedback = "Question was not attempted."
            else:
                word_count = len(ans.split())
                if word_count > 35:
                    awarded = round(max_m * 0.85, 1)
                    feedback = "Solid explanation covering core theoretical points. Check model answer for complete proof structure."
                elif word_count > 15:
                    awarded = round(max_m * 0.60, 1)
                    feedback = "Partial answer provided. Missing in-depth technical justification or diagrams."
                else:
                    awarded = round(max_m * 0.30, 1)
                    feedback = "Answer is too brief. Elaborate further with code/equations to gain full marks."

            short_evals.append({
                "q_number": q_num,
                "question": q.get("question", ""),
                "student_answer": ans or "[Unattempted]",
                "marks_awarded": awarded,
                "max_marks": max_m,
                "clo": q.get("clo", "CLO2"),
                "feedback": feedback
            })

        long_evals = []
        for q in paper_data.get("section_c_long", []):
            q_num = q.get("q_number")
            max_m = float(q.get("marks", 10.0))
            ans = str(student_answers.get(f"long_{q_num}", "")).strip()

            if not ans or ans == "[Not Attempted]":
                awarded = 0.0
                feedback = "Question was not attempted."
            else:
                word_count = len(ans.split())
                if word_count > 70:
                    awarded = round(max_m * 0.85, 1)
                    feedback = "Detailed comprehensive response. Well structured solution with good algorithmic logic."
                elif word_count > 30:
                    awarded = round(max_m * 0.55, 1)
                    feedback = "Partial response. Missed secondary sub-parts or complexity bounds."
                else:
                    awarded = round(max_m * 0.25, 1)
                    feedback = "Incomplete solution. Provide full implementation and entity modeling."

            long_evals.append({
                "q_number": q_num,
                "question": q.get("question", ""),
                "student_answer": ans or "[Unattempted]",
                "marks_awarded": awarded,
                "max_marks": max_m,
                "clo": q.get("clo", "CLO3"),
                "feedback": feedback
            })

        return short_evals, long_evals

    @staticmethod
    def _get_pakistan_gpa_grade(pct: float) -> str:
        """Returns standard Pakistani university grading letter."""
        if pct >= 85: return "A+ (4.00 GPA)"
        if pct >= 80: return "A  (3.67 GPA)"
        if pct >= 75: return "B+ (3.33 GPA)"
        if pct >= 70: return "B  (3.00 GPA)"
        if pct >= 65: return "C+ (2.50 GPA)"
        if pct >= 60: return "C  (2.00 GPA)"
        if pct >= 50: return "D  (1.00 GPA)"
        return "F  (Fail)"
