import os
import io
import re
from typing import Dict, List, Any, Optional
from pathlib import Path

# Try imports with graceful fallbacks
try:
    import pypdf
except ImportError:
    pypdf = None

try:
    from pptx import Presentation
except ImportError:
    Presentation = None

try:
    import docx
except ImportError:
    docx = None

try:
    from PIL import Image
    import pytesseract
except ImportError:
    Image = None
    pytesseract = None


class DocumentParser:
    @staticmethod
    def parse_pdf(file_bytes: bytes, filename: str = "") -> Dict[str, Any]:
        """Extract text and metadata from PDF bytes."""
        text_pages = []
        if pypdf:
            try:
                reader = pypdf.PdfReader(io.BytesIO(file_bytes))
                for i, page in enumerate(reader.pages):
                    page_text = page.extract_text() or ""
                    if page_text.strip():
                        text_pages.append(f"--- Page {i+1} ---\n{page_text.strip()}")
            except Exception as e:
                text_pages.append(f"[Error reading PDF pages with pypdf: {e}]")
        
        full_text = "\n\n".join(text_pages)
        if not full_text.strip():
            full_text = f"[PDF file: {filename} (Binary size: {len(file_bytes)} bytes - text could not be extracted directly)]"

        return {
            "filename": filename,
            "file_type": "pdf",
            "page_count": len(text_pages),
            "text": full_text,
            "char_count": len(full_text)
        }

    @staticmethod
    def parse_pptx(file_bytes: bytes, filename: str = "") -> Dict[str, Any]:
        """Extract text and slide structure from PPTX bytes."""
        slide_texts = []
        if Presentation:
            try:
                prs = Presentation(io.BytesIO(file_bytes))
                for i, slide in enumerate(prs.slides):
                    lines = []
                    for shape in slide.shapes:
                        if shape.has_text_frame:
                            for paragraph in shape.text_frame.paragraphs:
                                t = paragraph.text.strip()
                                if t:
                                    lines.append(t)
                    if lines:
                        slide_texts.append(f"--- Slide {i+1} ---\n" + "\n".join(lines))
            except Exception as e:
                slide_texts.append(f"[Error reading PPTX with python-pptx: {e}]")

        full_text = "\n\n".join(slide_texts)
        if not full_text.strip():
            full_text = f"[PPTX file: {filename} (Slide count: {len(slide_texts)})]"

        return {
            "filename": filename,
            "file_type": "pptx",
            "slide_count": len(slide_texts),
            "text": full_text,
            "char_count": len(full_text)
        }

    @staticmethod
    def parse_docx(file_bytes: bytes, filename: str = "") -> Dict[str, Any]:
        """Extract paragraphs and tables from DOCX bytes."""
        paragraphs = []
        if docx:
            try:
                doc = docx.Document(io.BytesIO(file_bytes))
                for p in doc.paragraphs:
                    t = p.text.strip()
                    if t:
                        paragraphs.append(t)
                for table in doc.tables:
                    for row in table.rows:
                        row_text = " | ".join(cell.text.strip() for cell in row.cells if cell.text.strip())
                        if row_text:
                            paragraphs.append(f"[Table Row] {row_text}")
            except Exception as e:
                paragraphs.append(f"[Error reading DOCX: {e}]")

        full_text = "\n\n".join(paragraphs)
        return {
            "filename": filename,
            "file_type": "docx",
            "paragraph_count": len(paragraphs),
            "text": full_text,
            "char_count": len(full_text)
        }

    @staticmethod
    def parse_image(file_bytes: bytes, filename: str = "") -> Dict[str, Any]:
        """
        Extracts questions, diagram components, formulas, and text from photos, figures, and diagrams
        using Gemini Multimodal Vision and OCR.
        """
        api_key = os.environ.get("GEMINI_API_KEY", "")
        if not api_key:
            env_file = Path(__file__).resolve().parent.parent / ".env"
            if env_file.exists():
                try:
                    with open(env_file, "r", encoding="utf-8") as ef:
                        for line in ef:
                            if line.startswith("GEMINI_API_KEY="):
                                api_key = line.strip().split("=", 1)[1].strip().strip('"').strip("'")
                                break
                except Exception:
                    pass

        # 1. High-Accuracy Multimodal Vision Extraction
        if api_key and len(file_bytes) > 0:
            import base64
            import json
            import urllib.request
            b64_img = base64.b64encode(file_bytes).decode("utf-8")
            
            ext = Path(filename).suffix.lower()
            mime = "image/png"
            if ext in [".jpg", ".jpeg"]:
                mime = "image/jpeg"
            elif ext == ".webp":
                mime = "image/webp"

            prompt_vision = (
                "You are an expert Academic Document & Examination Vision AI. "
                "Carefully inspect this image of an exam, quiz, assignment, whiteboard, textbook figure, or diagram. "
                "Extract in full detail:\n"
                "1. All question statements, numbers, marks, and subparts.\n"
                "2. All diagram structures, graph nodes/edges with weights, state machine transition tables, circuit components, tree structures, or ERD entities.\n"
                "3. Any mathematical formulas, matrices, truth tables, or code snippets.\n"
                "Provide a clean, structured transcription and technical diagram summary so an examination master can generate analogous university-standard questions."
            )

            models = ["gemini-3.6-flash", "gemini-3.7-flash", "gemini-flash-latest"]
            for model_name in models:
                try:
                    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_name}:generateContent?key={api_key}"
                    payload = {
                        "contents": [{
                            "parts": [
                                {"text": prompt_vision},
                                {"inline_data": {"mime_type": mime, "data": b64_img}}
                            ]
                        }]
                    }
                    req = urllib.request.Request(
                        url,
                        data=json.dumps(payload).encode("utf-8"),
                        headers={"Content-Type": "application/json"}
                    )
                    resp = urllib.request.urlopen(req, timeout=30)
                    data = json.loads(resp.read().decode("utf-8"))
                    text_extracted = data["candidates"][0]["content"]["parts"][0]["text"]
                    if text_extracted and len(text_extracted.strip()) > 10:
                        return {
                            "filename": filename,
                            "file_type": "image (Vision Extracted)",
                            "text": text_extracted.strip(),
                            "char_count": len(text_extracted)
                        }
                except Exception as e:
                    print(f"Gemini Vision call on {model_name} failed: {e}")
                    continue

        # 2. Fallback to local OCR if pytesseract is available
        ocr_text = ""
        if Image and pytesseract:
            try:
                img = Image.open(io.BytesIO(file_bytes))
                ocr_text = pytesseract.image_to_string(img)
            except Exception as e:
                ocr_text = f"[OCR error: {e}]"
        else:
            ocr_text = f"[Image file: {filename} ({len(file_bytes)} bytes) - Visual diagram content indexed]"

        return {
            "filename": filename,
            "file_type": "image",
            "text": ocr_text.strip(),
            "char_count": len(ocr_text)
        }

    @classmethod
    def parse_uploaded_file(cls, uploaded_file) -> Dict[str, Any]:
        """Generic dispatcher for Streamlit UploadedFile or file-like object."""
        filename = getattr(uploaded_file, "name", "uploaded_doc")
        file_bytes = uploaded_file.read() if hasattr(uploaded_file, "read") else bytes(uploaded_file)
        ext = Path(filename).suffix.lower()

        if ext == ".pdf":
            return cls.parse_pdf(file_bytes, filename)
        elif ext in [".pptx", ".ppt"]:
            return cls.parse_pptx(file_bytes, filename)
        elif ext in [".docx", ".doc"]:
            return cls.parse_docx(file_bytes, filename)
        elif ext in [".png", ".jpg", ".jpeg", ".webp"]:
            return cls.parse_image(file_bytes, filename)
        elif ext in [".txt", ".md"]:
            try:
                text = file_bytes.decode("utf-8")
            except Exception:
                text = file_bytes.decode("latin-1", errors="ignore")
            return {
                "filename": filename,
                "file_type": "txt",
                "text": text,
                "char_count": len(text)
            }
        else:
            # Fallback text decoder
            try:
                text = file_bytes.decode("utf-8")
            except Exception:
                text = f"[File {filename} ({len(file_bytes)} bytes)]"
            return {
                "filename": filename,
                "file_type": ext.lstrip("."),
                "text": text,
                "char_count": len(text)
            }

    @staticmethod
    def build_prompt_material_context(parsed_materials: Dict[str, List[Dict[str, Any]]], max_chars_per_category: int = 4000) -> Dict[str, str]:
        """
        Structures extracted document content into rich, clean context streams for prompt injection.
        """
        context_blocks = {
            "slides_content": "",
            "assignments_content": "",
            "quizzes_content": "",
            "past_papers_content": ""
        }

        # Slides
        slides_docs = parsed_materials.get("slides", [])
        if slides_docs:
            all_text = "\n\n".join([f"[{d.get('filename', 'Slide')}]:\n{d.get('text', '')}" for d in slides_docs])
            context_blocks["slides_content"] = all_text[:max_chars_per_category].strip()

        # Assignments
        assign_docs = parsed_materials.get("assignments", [])
        if assign_docs:
            all_text = "\n\n".join([f"[{d.get('filename', 'Assignment')}]:\n{d.get('text', '')}" for d in assign_docs])
            context_blocks["assignments_content"] = all_text[:max_chars_per_category].strip()

        # Quizzes
        quiz_docs = parsed_materials.get("quizzes", [])
        if quiz_docs:
            all_text = "\n\n".join([f"[{d.get('filename', 'Quiz')}]:\n{d.get('text', '')}" for d in quiz_docs])
            context_blocks["quizzes_content"] = all_text[:max_chars_per_category].strip()

        # Past Papers / Midterms
        past_docs = parsed_materials.get("past_papers", []) + parsed_materials.get("midterms", [])
        if past_docs:
            all_text = "\n\n".join([f"[{d.get('filename', 'Past Paper')}]:\n{d.get('text', '')}" for d in past_docs])
            context_blocks["past_papers_content"] = all_text[:max_chars_per_category].strip()

        return context_blocks
