import io
from typing import Dict, Any, Optional

try:
    from reportlab.lib.pagesizes import letter
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether, HRFlowable
    from reportlab.lib.units import inch
    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False


def generate_exam_pdf(paper_data: Dict[str, Any], include_solutions: bool = False) -> bytes:
    """
    Generates a professional examination PDF matching Pakistani university standards.
    """
    if not REPORTLAB_AVAILABLE:
        # Fallback to plain text bytes
        buffer = io.BytesIO()
        text_content = format_paper_as_text(paper_data, include_solutions)
        buffer.write(text_content.encode("utf-8"))
        buffer.seek(0)
        return buffer.getvalue()

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=40,
        leftMargin=40,
        topMargin=40,
        bottomMargin=40
    )

    styles = getSampleStyleSheet()
    
    # Custom styles
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=14,
        leading=17,
        alignment=1, # Center
        textColor=colors.HexColor("#1A365D")
    )
    
    subtitle_style = ParagraphStyle(
        'DocSubTitle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=11,
        leading=14,
        alignment=1, # Center
        textColor=colors.HexColor("#2B6CB0")
    )
    
    section_head_style = ParagraphStyle(
        'SectionHead',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=11,
        leading=14,
        textColor=colors.HexColor("#2C5282"),
        spaceBefore=10,
        spaceAfter=5
    )

    body_style = ParagraphStyle(
        'Body',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9.5,
        leading=13,
        textColor=colors.HexColor("#1A202C")
    )

    tag_style = ParagraphStyle(
        'Tags',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=8,
        leading=10,
        textColor=colors.HexColor("#4A5568")
    )

    story = []
    meta = paper_data.get("metadata", {})

    # University & Exam Header
    story.append(Paragraph(meta.get("university_header", "DEPARTMENT OF COMPUTER SCIENCE").upper(), title_style))
    story.append(Spacer(1, 3))
    story.append(Paragraph(f"{meta.get('subject', 'Course Name')} ({meta.get('course_code', 'CS-000')}) — {meta.get('exam_type', 'Terminal')} Examination", subtitle_style))
    story.append(Spacer(1, 8))

    # Exam Info Table
    info_data = [
        [
            Paragraph("<b>Roll No:</b> ____________________", body_style),
            Paragraph(f"<b>Time Allowed:</b> {meta.get('time_allowed', '2.5 Hours')}", body_style),
            Paragraph(f"<b>Total Marks:</b> {meta.get('total_marks', 50)}", body_style)
        ]
    ]
    t = Table(info_data, colWidths=[200, 160, 160])
    t.setStyle(TableStyle([
        ('BOX', (0, 0), (-1, -1), 1, colors.HexColor("#CBD5E0")),
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor("#F7FAFC")),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(t)
    story.append(Spacer(1, 8))

    # Instructions Box
    instructions = meta.get("instructions", ["Attempt all questions.", "Programmable calculators are not allowed."])
    inst_text = "<b>Instructions:</b> " + " | ".join(instructions)
    story.append(Paragraph(inst_text, ParagraphStyle('Inst', parent=body_style, fontSize=8.5, fontName='Helvetica-Oblique', textColor=colors.HexColor("#4A5568"))))
    story.append(Spacer(1, 6))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#CBD5E0"), spaceBefore=3, spaceAfter=8))

    # Section A - MCQs
    mcqs = paper_data.get("section_a_mcqs", [])
    if mcqs:
        story.append(Paragraph(f"SECTION A: MULTIPLE CHOICE QUESTIONS [Marks: {sum(q.get('marks', 1) for q in mcqs):g}]", section_head_style))
        for q in mcqs:
            q_num = q.get("q_number", 1)
            q_text = q.get("question", "")
            marks = q.get("marks", 1)
            clo = q.get("clo", "CLO1")
            blooms = q.get("blooms", "C2")
            
            q_header = f"<b>Q{q_num}.</b> {q_text} <i>[{marks:g} Mark] [{clo} | {blooms}]</i>"
            story.append(Paragraph(q_header, body_style))
            story.append(Spacer(1, 2))
            
            # Options in 2x2 table
            opts = q.get("options", [])
            if len(opts) == 4:
                opt_table = Table([[Paragraph(opts[0], body_style), Paragraph(opts[1], body_style)],
                                   [Paragraph(opts[2], body_style), Paragraph(opts[3], body_style)]],
                                  colWidths=[260, 260])
                opt_table.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'TOP'), ('BOTTOMPADDING', (0, 0), (-1, -1), 2)]))
                story.append(opt_table)
            else:
                for opt in opts:
                    story.append(Paragraph(f"&nbsp;&nbsp;&nbsp;&nbsp;{opt}", body_style))
            story.append(Spacer(1, 5))

    # Section A - True / False
    tf_list = paper_data.get("section_a_tf", [])
    if tf_list:
        story.append(Spacer(1, 4))
        story.append(Paragraph(f"SECTION A (PART II): TRUE / FALSE [Marks: {sum(q.get('marks', 1) for q in tf_list):g}]", section_head_style))
        for q in tf_list:
            q_num = q.get("q_number", 1)
            stmt = q.get("statement", "")
            marks = q.get("marks", 1)
            clo = q.get("clo", "CLO1")
            story.append(Paragraph(f"<b>{q_num}.</b> [ &nbsp; ] {stmt} <i>[{marks:g} Mark] [{clo}]</i>", body_style))
            story.append(Spacer(1, 3))

    # Section B - Short Questions
    short_qs = paper_data.get("section_b_short", [])
    if short_qs:
        story.append(Spacer(1, 6))
        story.append(Paragraph(f"SECTION B: SHORT ANSWER / ANALYTICAL QUESTIONS [Marks: {sum(q.get('marks', 5) for q in short_qs):g}]", section_head_style))
        for q in short_qs:
            q_num = q.get("q_number", 1)
            q_text = q.get("question", "").replace("\n", "<br/>")
            marks = q.get("marks", 5)
            clo = q.get("clo", "CLO2")
            blooms = q.get("blooms", "C3")
            plos = ", ".join(q.get("mapped_plos", []))
            plo_str = f" | {plos}" if plos else ""
            
            story.append(Paragraph(f"<b>Q{q_num}.</b> {q_text} <b>[{marks:g} Marks]</b> <i>[{clo} | {blooms}{plo_str}]</i>", body_style))
            story.append(Spacer(1, 6))

    # Section C - Long Questions
    long_qs = paper_data.get("section_c_long", [])
    if long_qs:
        story.append(Spacer(1, 6))
        story.append(Paragraph(f"SECTION C: LONG / COMPREHENSIVE / DESIGN QUESTIONS [Marks: {sum(q.get('marks', 10) for q in long_qs):g}]", section_head_style))
        for q in long_qs:
            q_num = q.get("q_number", 1)
            q_text = q.get("question", "").replace("\n", "<br/>")
            marks = q.get("marks", 10)
            clo = q.get("clo", "CLO3")
            blooms = q.get("blooms", "C5")
            plos = ", ".join(q.get("mapped_plos", []))
            plo_str = f" | {plos}" if plos else ""
            
            story.append(Paragraph(f"<b>Q{q_num}.</b> {q_text} <b>[{marks:g} Marks]</b> <i>[{clo} | {blooms}{plo_str}]</i>", body_style))
            story.append(Spacer(1, 8))

    # Optional: Append Solution Key & Rubric
    if include_solutions and "marking_scheme_and_solutions" in paper_data:
        story.append(PageBreak())
        story.append(Paragraph("OFFICIAL MODEL SOLUTIONS & STEP-BY-STEP MARKING RUBRIC", title_style))
        story.append(Spacer(1, 4))
        story.append(Paragraph(f"Confidential Assessment Guide — {meta.get('subject')}", subtitle_style))
        story.append(Spacer(1, 8))
        story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#CBD5E0"), spaceBefore=3, spaceAfter=8))

        sol = paper_data["marking_scheme_and_solutions"]

        # MCQ Solutions
        if sol.get("mcq_solutions"):
            story.append(Paragraph("1. MCQ Answer Key", section_head_style))
            sol_rows = [["Q#", "Key", "Technical Explanation"]]
            for s in sol["mcq_solutions"]:
                sol_rows.append([str(s.get("q_number")), s.get("correct_option", ""), Paragraph(s.get("explanation", ""), body_style)])
            st = Table(sol_rows, colWidths=[40, 50, 430])
            st.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#EDF2F7")),
                ('BOX', (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E0")),
                ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#E2E8F0")),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
                ('TOPPADDING', (0, 0), (-1, -1), 4),
            ]))
            story.append(st)
            story.append(Spacer(1, 10))

        # Short Solutions
        if sol.get("short_solutions"):
            story.append(Paragraph("2. Section B Model Answers & Rubrics", section_head_style))
            for s in sol["short_solutions"]:
                story.append(Paragraph(f"<b>Q{s.get('q_number')} Model Solution:</b>", body_style))
                story.append(Paragraph(s.get("model_answer", "").replace("\n", "<br/>"), body_style))
                story.append(Paragraph(f"<b>Rubric:</b> <i>{s.get('rubric', '')}</i>", ParagraphStyle('Rubric', parent=body_style, textColor=colors.HexColor("#2B6CB0"))))
                story.append(Spacer(1, 6))

        # Long Solutions
        if sol.get("long_solutions"):
            story.append(Paragraph("3. Section C Model Answers & Rubrics", section_head_style))
            for s in sol["long_solutions"]:
                story.append(Paragraph(f"<b>Q{s.get('q_number')} Comprehensive Solution:</b>", body_style))
                story.append(Paragraph(s.get("model_answer", "").replace("\n", "<br/>"), body_style))
                story.append(Paragraph(f"<b>Step-wise Rubric:</b> <i>{s.get('rubric', '')}</i>", ParagraphStyle('Rubric2', parent=body_style, textColor=colors.HexColor("#2B6CB0"))))
                story.append(Spacer(1, 8))

    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()


def format_paper_as_text(paper_data: Dict[str, Any], include_solutions: bool = False) -> str:
    """Formats the exam paper as clean Markdown / Plain Text."""
    meta = paper_data.get("metadata", {})
    lines = [
        f"# {meta.get('university_header', 'DEPARTMENT OF COMPUTER SCIENCE')}",
        f"## {meta.get('subject', 'Course')} ({meta.get('course_code', 'CS')}) — {meta.get('exam_type', 'Terminal')} Exam",
        f"**Time Allowed:** {meta.get('time_allowed', '2.5 Hours')} | **Total Marks:** {meta.get('total_marks', 50)}",
        "---",
        "**Instructions:** " + " | ".join(meta.get("instructions", [])),
        "\n"
    ]

    mcqs = paper_data.get("section_a_mcqs", [])
    if mcqs:
        lines.append("### SECTION A: MCQs")
        for q in mcqs:
            lines.append(f"**Q{q.get('q_number')}.** {q.get('question')} *[{q.get('marks')} Mark | {q.get('clo')} | {q.get('blooms')}]*")
            for opt in q.get("options", []):
                lines.append(f"  - {opt}")
            lines.append("")

    tf_list = paper_data.get("section_a_tf", [])
    if tf_list:
        lines.append("### SECTION A (Part II): True / False")
        for q in tf_list:
            lines.append(f"**{q.get('q_number')}.** [ ] {q.get('statement')} *[{q.get('marks')} Mark | {q.get('clo')}]*")
        lines.append("")

    short_qs = paper_data.get("section_b_short", [])
    if short_qs:
        lines.append("### SECTION B: Short Questions")
        for q in short_qs:
            plos = f" | {', '.join(q.get('mapped_plos', []))}" if q.get('mapped_plos') else ""
            lines.append(f"**Q{q.get('q_number')}.** {q.get('question')} **[{q.get('marks')} Marks]** *[{q.get('clo')} | {q.get('blooms')}{plos}]*\n")

    long_qs = paper_data.get("section_c_long", [])
    if long_qs:
        lines.append("### SECTION C: Long / Design Questions")
        for q in long_qs:
            plos = f" | {', '.join(q.get('mapped_plos', []))}" if q.get('mapped_plos') else ""
            lines.append(f"**Q{q.get('q_number')}.**\n{q.get('question')}\n**[{q.get('marks')} Marks]** *[{q.get('clo')} | {q.get('blooms')}{plos}]*\n")

    if include_solutions and "marking_scheme_and_solutions" in paper_data:
        lines.append("\n\n---\n# OFFICIAL MODEL SOLUTIONS & MARKING RUBRIC\n")
        sol = paper_data["marking_scheme_and_solutions"]
        if sol.get("mcq_solutions"):
            lines.append("### MCQ Key:")
            for s in sol["mcq_solutions"]:
                lines.append(f"- **Q{s.get('q_number')}:** {s.get('correct_option')} ({s.get('explanation')})")
            lines.append("")
        if sol.get("short_solutions"):
            lines.append("### Section B Model Solutions:")
            for s in sol["short_solutions"]:
                lines.append(f"**Q{s.get('q_number')}:**\n{s.get('model_answer')}\n*Rubric:* {s.get('rubric')}\n")
        if sol.get("long_solutions"):
            lines.append("### Section C Model Solutions:")
            for s in sol["long_solutions"]:
                lines.append(f"**Q{s.get('q_number')}:**\n{s.get('model_answer')}\n*Rubric:* {s.get('rubric')}\n")

    return "\n".join(lines)
