from typing import Dict, Any, Tuple, List, Optional


class ExamPatternValidator:
    @staticmethod
    def validate_marks(
        total_marks: float,
        mcq_count: int,
        mcq_marks_each: float,
        short_count: int,
        short_marks_each: float,
        long_count: int,
        long_marks_each: float,
        tf_count: int = 0,
        tf_marks_each: float = 0.0
    ) -> Tuple[bool, float, str]:
        """
        Validates that the sum of all question type marks exactly matches the total marks.
        Formula: (MCQs * marks) + (short * marks) + (long * marks) + (T/F * marks) == total marks
        """
        if total_marks <= 0:
            return False, 0.0, "Total exam marks must be greater than 0."

        # Bounds validation
        if mcq_count < 0 or short_count < 0 or long_count < 0 or tf_count < 0:
            return False, 0.0, "Question counts cannot be negative."
        if mcq_count > 60 or short_count > 30 or long_count > 15 or tf_count > 40:
            return False, 0.0, "Question count exceeds maximum realistic exam capacity."

        mcq_total = mcq_count * mcq_marks_each
        short_total = short_count * short_marks_each
        long_total = long_count * long_marks_each
        tf_total = tf_count * tf_marks_each

        calculated_total = mcq_total + short_total + long_total + tf_total

        # Format calculation summary
        parts = []
        if mcq_count > 0:
            parts.append(f"{mcq_count} MCQs × {mcq_marks_each:g} = {mcq_total:g}")
        if short_count > 0:
            parts.append(f"{short_count} Short Qs × {short_marks_each:g} = {short_total:g}")
        if long_count > 0:
            parts.append(f"{long_count} Long Qs × {long_marks_each:g} = {long_total:g}")
        if tf_count > 0:
            parts.append(f"{tf_count} T/F Qs × {tf_marks_each:g} = {tf_total:g}")

        breakdown_str = " + ".join(parts) if parts else "No questions configured"

        diff = total_marks - calculated_total
        if abs(diff) < 0.001:
            return True, calculated_total, f"Marks calculation valid! ({breakdown_str} = {calculated_total:g} Marks)"
        elif diff > 0:
            return False, calculated_total, f"Marks Mismatch! Allocated sum is {calculated_total:g} / {total_marks:g} Marks ({breakdown_str}). You need to allocate {diff:g} more mark(s)."
        else:
            return False, calculated_total, f"Marks Mismatch! Allocated sum is {calculated_total:g} / {total_marks:g} Marks ({breakdown_str}). You have over-allocated by {abs(diff):g} mark(s)."

    @staticmethod
    def validate_clo_alignment(paper_data: Dict[str, Any], subject_info: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Performs rigorous HEC OBE CLO/PLO verification on every generated question.
        Ensures questions map to official curriculum CLOs and resolves PLO mappings accurately.
        """
        valid_clos = {}
        if subject_info and "clos" in subject_info:
            for c in subject_info["clos"]:
                valid_clos[c["id"]] = c

        all_questions = []
        for q in paper_data.get("section_a_mcqs", []):
            all_questions.append(("Section A (MCQ)", q))
        for q in paper_data.get("section_a_tf", []):
            all_questions.append(("Section A (T/F)", q))
        for q in paper_data.get("section_b_short", []):
            all_questions.append(("Section B (Short)", q))
        for q in paper_data.get("section_c_long", []):
            all_questions.append(("Section C (Long)", q))

        verification_results = []
        all_valid = True

        for sec_name, q in all_questions:
            q_num = q.get("q_number", 1)
            target_clo = str(q.get("clo", "")).strip().upper()
            blooms = q.get("blooms", "C2")
            
            # Resolve Mapped PLOs dynamically if not set
            mapped_plos = q.get("mapped_plos", [])
            if not mapped_plos and target_clo in valid_clos:
                mapped_plos = valid_clos[target_clo].get("mapped_plos", [])
                q["mapped_plos"] = mapped_plos # synchronize question object

            is_clo_valid = target_clo in valid_clos if valid_clos else bool(target_clo)
            if not is_clo_valid:
                all_valid = False

            verification_results.append({
                "section": sec_name,
                "q_number": q_num,
                "marks": q.get("marks", 1),
                "clo": target_clo or "UNMAPPED",
                "blooms": blooms,
                "mapped_plos": mapped_plos or ["UNMAPPED"],
                "is_verified": is_clo_valid,
                "official_clo_text": valid_clos[target_clo]["text"] if target_clo in valid_clos else "Custom / Unverified CLO"
            })

        return {
            "all_verified": all_valid,
            "total_questions_audited": len(all_questions),
            "verification_results": verification_results
        }


def validate_pattern(pattern: Dict[str, Any]) -> Tuple[bool, float, str]:
    return ExamPatternValidator.validate_marks(
        total_marks=float(pattern.get("total_marks", 50)),
        mcq_count=int(pattern.get("mcq_count", 10)),
        mcq_marks_each=float(pattern.get("mcq_marks_each", 1.0)),
        short_count=int(pattern.get("short_count", 4)),
        short_marks_each=float(pattern.get("short_marks_each", 5.0)),
        long_count=int(pattern.get("long_count", 2)),
        long_marks_each=float(pattern.get("long_marks_each", 10.0)),
        tf_count=int(pattern.get("tf_count", 0)),
        tf_marks_each=float(pattern.get("tf_marks_each", 1.0)),
    )
