"""
ExamMind AI — Main Desktop Application Entry Point
"""
import sys
import os

# Ensure the root directory is on Python path
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)

from desktop_app import run_desktop_app

if __name__ == "__main__":
    run_desktop_app()
