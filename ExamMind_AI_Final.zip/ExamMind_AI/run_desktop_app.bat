@echo off
title ExamMind AI - Desktop Application
cd /d "%~dp0"
echo Starting ExamMind AI Desktop Application...
python main.py
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo An error occurred while launching ExamMind AI.
    pause
)
