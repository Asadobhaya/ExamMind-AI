import time
import os
import sys
from pathlib import Path

# Ensure root path
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from curriculum.loader import curriculum_repo
from engine.validator import ExamPatternValidator
from engine.parser import DocumentParser
from engine.analyzer import MaterialAnalyzer
from engine.generator import ExamGenerator
from engine.pdf_export import generate_exam_pdf
from database.db import save_paper, get_paper_by_uid, delete_paper

TEST_CONFIGS = [
    {
        "name": "Test Run 1/10: Data Structures (Midterm 50M)",
        "subject": "data_structures",
        "exam_type": "Midterm",
        "pattern": {"total_marks": 50, "mcq_count": 10, "mcq_marks_each": 1, "short_count": 4, "short_marks_each": 5, "long_count": 2, "long_marks_each": 10, "tf_count": 0, "tf_marks_each": 1},
        "verbal": "Focus on AVL Tree rotations and Graph BFS/DFS.",
        "attach_docs": True
    },
    {
        "name": "Test Run 2/10: Database Systems (Final 80M)",
        "subject": "database_systems",
        "exam_type": "Final",
        "pattern": {"total_marks": 80, "mcq_count": 20, "mcq_marks_each": 1, "short_count": 6, "short_marks_each": 5, "long_count": 3, "long_marks_each": 10, "tf_count": 0, "tf_marks_each": 1},
        "verbal": "Focus on 3NF/BCNF normalization and transaction serializability.",
        "attach_docs": False
    },
    {
        "name": "Test Run 3/10: Object Oriented Programming (Midterm 30M)",
        "subject": "object_oriented_programming",
        "exam_type": "Midterm",
        "pattern": {"total_marks": 30, "mcq_count": 5, "mcq_marks_each": 1, "short_count": 3, "short_marks_each": 5, "long_count": 1, "long_marks_each": 10, "tf_count": 0, "tf_marks_each": 1},
        "verbal": "Write code in C++ with virtual destructors and inheritance.",
        "attach_docs": False
    },
    {
        "name": "Test Run 4/10: Operating Systems (Final 100M)",
        "subject": "operating_systems",
        "exam_type": "Final",
        "pattern": {"total_marks": 100, "mcq_count": 20, "mcq_marks_each": 1, "short_count": 8, "short_marks_each": 5, "long_count": 4, "long_marks_each": 10, "tf_count": 0, "tf_marks_each": 1},
        "verbal": "Include Banker's algorithm and Page replacement simulation.",
        "attach_docs": False
    },
    {
        "name": "Test Run 5/10: Design and Analysis of Algorithms (Midterm 50M)",
        "subject": "design_and_analysis_of_algorithms",
        "exam_type": "Midterm",
        "pattern": {"total_marks": 50, "mcq_count": 10, "mcq_marks_each": 1, "short_count": 4, "short_marks_each": 5, "long_count": 2, "long_marks_each": 10, "tf_count": 0, "tf_marks_each": 1},
        "verbal": "Dynamic programming for 0/1 Knapsack and Master Theorem.",
        "attach_docs": True
    },
    {
        "name": "Test Run 6/10: Computer Networks (Final 80M)",
        "subject": "computer_networks",
        "exam_type": "Final",
        "pattern": {"total_marks": 80, "mcq_count": 20, "mcq_marks_each": 1, "short_count": 6, "short_marks_each": 5, "long_count": 3, "long_marks_each": 10, "tf_count": 0, "tf_marks_each": 1},
        "verbal": "VLSM Subnetting calculation and TCP 3-way handshake.",
        "attach_docs": False
    },
    {
        "name": "Test Run 7/10: Theory of Automata (Midterm 40M)",
        "subject": "theory_of_automata",
        "exam_type": "Midterm",
        "pattern": {"total_marks": 40, "mcq_count": 10, "mcq_marks_each": 1, "short_count": 4, "short_marks_each": 5, "long_count": 1, "long_marks_each": 10, "tf_count": 0, "tf_marks_each": 1},
        "verbal": "NFA to DFA subset construction and regular expressions.",
        "attach_docs": False
    },
    {
        "name": "Test Run 8/10: Artificial Intelligence (Final 60M)",
        "subject": "artificial_intelligence",
        "exam_type": "Final",
        "pattern": {"total_marks": 60, "mcq_count": 10, "mcq_marks_each": 1, "short_count": 6, "short_marks_each": 5, "long_count": 2, "long_marks_each": 10, "tf_count": 0, "tf_marks_each": 1},
        "verbal": "Minimax with Alpha-Beta pruning and A* heuristic consistency.",
        "attach_docs": False
    },
    {
        "name": "Test Run 9/10: Information Security (Midterm 50M)",
        "subject": "information_security",
        "exam_type": "Midterm",
        "pattern": {"total_marks": 50, "mcq_count": 10, "mcq_marks_each": 1, "short_count": 4, "short_marks_each": 5, "long_count": 2, "long_marks_each": 10, "tf_count": 0, "tf_marks_each": 1},
        "verbal": "RSA key generation steps and Diffie-Hellman problem.",
        "attach_docs": False
    },
    {
        "name": "Test Run 10/10: Machine Learning (Final 80M)",
        "subject": "machine_learning",
        "exam_type": "Final",
        "pattern": {"total_marks": 80, "mcq_count": 20, "mcq_marks_each": 1, "short_count": 6, "short_marks_each": 5, "long_count": 3, "long_marks_each": 10, "tf_count": 0, "tf_marks_each": 1},
        "verbal": "Gradient descent derivation, confusion matrix, and SVM margins.",
        "attach_docs": False
    }
]


def run_10x_stress_test():
    print("=" * 80)
    print("      EXAMMIND AI — 10x FULL PIPELINE VERIFICATION & STRESS TEST")
    print("=" * 80)

    generator = ExamGenerator()
    created_uids = []
    passed_count = 0
    start_total_time = time.time()

    # Load sample document
    sample_slide_path = ROOT_DIR / "tests" / "sample_docs" / "dsa_lecture_slides.txt"
    sample_quiz_path = ROOT_DIR / "tests" / "sample_docs" / "dsa_quiz_1.txt"

    for i, tc in enumerate(TEST_CONFIGS, 1):
        print(f"\n[{i}/10] Executing: {tc['name']}...")
        t_start = time.time()

        # 1. Validate Math Pattern
        p = tc["pattern"]
        is_valid, calc_total, val_msg = ExamPatternValidator.validate_marks(
            total_marks=p["total_marks"],
            mcq_count=p["mcq_count"],
            mcq_marks_each=p["mcq_marks_each"],
            short_count=p["short_count"],
            short_marks_each=p["short_marks_each"],
            long_count=p["long_count"],
            long_marks_each=p["long_marks_each"],
            tf_count=p.get("tf_count", 0),
            tf_marks_each=p.get("tf_marks_each", 1.0)
        )
        assert is_valid, f"Pattern marks mismatch in test {i}: {val_msg}"

        # 2. Material Parsing & Topic Weightage
        parsed_materials = {}
        if tc.get("attach_docs") and sample_slide_path.exists():
            with open(sample_slide_path, "rb") as f:
                doc1 = DocumentParser.parse_uploaded_file(f)
                doc1["filename"] = "dsa_lecture_slides.txt"
                parsed_materials["slides"] = [doc1]
            if sample_quiz_path.exists():
                with open(sample_quiz_path, "rb") as f:
                    doc2 = DocumentParser.parse_uploaded_file(f)
                    doc2["filename"] = "dsa_quiz_1.txt"
                    parsed_materials["quizzes"] = [doc2]

        subj_info = curriculum_repo.get_subject_by_slug(tc["subject"])
        assert subj_info is not None, f"Subject {tc['subject']} not found in curriculum!"

        mat_analysis = MaterialAnalyzer.extract_topic_weightages(parsed_materials, subj_info)
        style_analysis = MaterialAnalyzer.analyze_past_paper_patterns(
            parsed_materials.get("past_papers", []),
            parsed_materials.get("quizzes", [])
        )

        # 3. Generate Exam Paper
        paper = generator.generate_exam_paper(
            subject_slug=tc["subject"],
            exam_type=tc["exam_type"],
            pattern=p,
            verbal_instructions=tc["verbal"],
            uploaded_summary=f"Attached {len(parsed_materials)} test documents",
            material_analysis=mat_analysis,
            style_analysis=style_analysis
        )

        # 4. Verify Generated Paper Structure
        assert "metadata" in paper, "Missing metadata in paper"
        assert len(paper.get("section_a_mcqs", [])) == p["mcq_count"], f"MCQ count mismatch in test {i}"
        assert len(paper.get("section_b_short", [])) == p["short_count"], f"Short Q count mismatch in test {i}"
        assert len(paper.get("section_c_long", [])) == p["long_count"], f"Long Q count mismatch in test {i}"
        assert "marking_scheme_and_solutions" in paper, "Missing marking solutions"

        # Verify CLO tagging
        for q in paper.get("section_a_mcqs", []):
            assert "clo" in q and q["clo"].startswith("CLO"), f"Missing valid CLO in MCQ: {q}"
        for q in paper.get("section_b_short", []):
            assert "clo" in q and q["clo"].startswith("CLO"), f"Missing valid CLO in Short Q: {q}"
        for q in paper.get("section_c_long", []):
            assert "clo" in q and q["clo"].startswith("CLO"), f"Missing valid CLO in Long Q: {q}"

        # 5. Verify PDF Generation
        pdf_bytes = generate_exam_pdf(paper, include_solutions=True)
        assert len(pdf_bytes) > 500, "PDF export output is too small or invalid"

        # 6. Verify SQLite Database Persistence
        uid = save_paper(
            subject_slug=tc["subject"],
            subject_title=subj_info.get("title", tc["subject"]),
            exam_type=tc["exam_type"],
            total_marks=p["total_marks"],
            pattern=p,
            verbal_instructions=tc["verbal"],
            uploaded_files_summary="Stress test run",
            paper_content=paper,
            solution_content=paper["marking_scheme_and_solutions"],
            analysis_summary=paper.get("pattern_analysis_summary", "")
        )
        assert uid is not None, "Failed to save paper in SQLite"
        created_uids.append(uid)

        retrieved = get_paper_by_uid(uid)
        assert retrieved is not None, "Failed to retrieve paper from SQLite"
        assert retrieved["total_marks"] == p["total_marks"], "Retrieved marks mismatch"

        elapsed = time.time() - t_start
        print(f"   -> Result: PASSED in {elapsed:.2f}s | Questions: {p['mcq_count']} MCQs, {p['short_count']} Short, {p['long_count']} Long | PDF: {len(pdf_bytes):,} bytes")
        passed_count += 1

    # Cleanup test entries from DB
    for uid in created_uids:
        delete_paper(uid)

    total_time = time.time() - start_total_time
    print("\n" + "=" * 80)
    print(f"STRESS TEST SUMMARY: {passed_count}/10 TEST RUNS PASSED (100% SUCCESS)")
    print(f"Total Test Time: {total_time:.2f} seconds | Average per exam: {total_time/10:.2f}s")
    print("=" * 80)


if __name__ == "__main__":
    run_10x_stress_test()
