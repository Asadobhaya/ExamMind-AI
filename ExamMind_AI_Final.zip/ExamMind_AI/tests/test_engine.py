import unittest
import json
from curriculum.loader import curriculum_repo
from engine.validator import ExamPatternValidator, validate_pattern
from engine.parser import DocumentParser
from engine.analyzer import MaterialAnalyzer
from engine.generator import ExamGenerator
from engine.pdf_export import generate_exam_pdf, format_paper_as_text
from database.db import save_paper, get_all_papers, get_paper_by_uid, delete_paper


class TestExamMindAI(unittest.TestCase):

    def test_curriculum_plos_loaded(self):
        plos = curriculum_repo.get_plos()
        self.assertGreaterEqual(len(plos), 10, "Should have all 10 HEC PLOs")
        plo_ids = [p["id"] for p in plos]
        self.assertIn("PLO1", plo_ids)
        self.assertIn("PLO2", plo_ids)
        self.assertIn("PLO10", plo_ids)

    def test_curriculum_subjects_loaded(self):
        subjects = curriculum_repo.get_subjects_list()
        self.assertGreaterEqual(len(subjects), 10, "Should load core BSCS subjects")
        
        # Check specific key courses
        dsa = curriculum_repo.get_subject_by_slug("data_structures")
        self.assertIsNotNone(dsa)
        self.assertEqual(dsa["title"], "Data Structures")
        self.assertGreaterEqual(len(dsa["clos"]), 5)
        
        db = curriculum_repo.get_subject_by_slug("database_systems")
        self.assertIsNotNone(db)
        self.assertEqual(db["title"], "Database Systems")

    def test_mark_validator_success(self):
        # 10 MCQs * 1 + 4 Short * 5 + 2 Long * 10 = 10 + 20 + 20 = 50
        is_valid, total, msg = ExamPatternValidator.validate_marks(
            total_marks=50,
            mcq_count=10,
            mcq_marks_each=1.0,
            short_count=4,
            short_marks_each=5.0,
            long_count=2,
            long_marks_each=10.0,
            tf_count=0,
            tf_marks_each=1.0
        )
        self.assertTrue(is_valid)
        self.assertEqual(total, 50.0)

    def test_mark_validator_mismatch_deficit(self):
        # 10 MCQs * 1 + 2 Short * 5 + 1 Long * 10 = 10 + 10 + 10 = 30 vs 50
        is_valid, total, msg = ExamPatternValidator.validate_marks(
            total_marks=50,
            mcq_count=10,
            mcq_marks_each=1.0,
            short_count=2,
            short_marks_each=5.0,
            long_count=1,
            long_marks_each=10.0
        )
        self.assertFalse(is_valid)
        self.assertEqual(total, 30.0)
        self.assertIn("Mismatch", msg)
        self.assertIn("20", msg)

    def test_mark_validator_mismatch_surplus(self):
        # 10 MCQs * 1 + 6 Short * 5 + 2 Long * 10 = 10 + 30 + 20 = 60 vs 50
        is_valid, total, msg = ExamPatternValidator.validate_marks(
            total_marks=50,
            mcq_count=10,
            mcq_marks_each=1.0,
            short_count=6,
            short_marks_each=5.0,
            long_count=2,
            long_marks_each=10.0
        )
        self.assertFalse(is_valid)
        self.assertEqual(total, 60.0)
        self.assertIn("over-allocated", msg)

    def test_material_analyzer(self):
        subject = curriculum_repo.get_subject_by_slug("data_structures")
        sample_materials = {
            "slides": [{"text": "AVL trees are self-balancing binary search trees. Rotations include LL, RR, LR, RL."}],
            "assignments": [{"text": "Implement an AVL Tree and graph traversal using BFS and DFS in C++."}]
        }
        res = MaterialAnalyzer.extract_topic_weightages(sample_materials, subject)
        self.assertIn("weighted_topics", res)
        self.assertGreater(len(res["weighted_topics"]), 0)

    def test_past_paper_pattern_analyzer(self):
        past_docs = [
            {"text": "Q1. Write a code in C++ to implement Dijkstra algorithm. Q2. Calculate the step by step shortest path table."}
        ]
        style = MaterialAnalyzer.analyze_past_paper_patterns(past_docs)
        self.assertTrue(style["detected"])
        self.assertIn("code_pct", style)

    def test_exam_generation_and_storage(self):
        gen = ExamGenerator()
        pattern = {
            "total_marks": 40,
            "mcq_count": 5,
            "mcq_marks_each": 1.0,
            "short_count": 3,
            "short_marks_each": 5.0,
            "long_count": 2,
            "long_marks_each": 10.0,
            "tf_count": 0,
            "tf_marks_each": 1.0
        }
        paper = gen.generate_exam_paper(
            subject_slug="database_systems",
            exam_type="Midterm",
            pattern=pattern,
            verbal_instructions="Focus on Normalization 3NF/BCNF and ER Modeling."
        )

        self.assertIn("metadata", paper)
        self.assertIn("section_a_mcqs", paper)
        self.assertEqual(len(paper["section_a_mcqs"]), 5)
        self.assertIn("section_b_short", paper)
        self.assertEqual(len(paper["section_b_short"]), 3)
        self.assertIn("section_c_long", paper)
        self.assertEqual(len(paper["section_c_long"]), 2)
        self.assertIn("marking_scheme_and_solutions", paper)

        # Test DB save and retrieve
        uid = save_paper(
            subject_slug="database_systems",
            subject_title="Database Systems",
            exam_type="Midterm",
            total_marks=40,
            pattern=pattern,
            verbal_instructions="Focus on 3NF",
            uploaded_files_summary="2 files",
            paper_content=paper,
            solution_content=paper["marking_scheme_and_solutions"],
            analysis_summary="Midterm generated"
        )
        self.assertIsNotNone(uid)
        retrieved = get_paper_by_uid(uid)
        self.assertEqual(retrieved["subject_slug"], "database_systems")

        # Test PDF generation
        pdf_bytes = generate_exam_pdf(paper, include_solutions=True)
        self.assertGreater(len(pdf_bytes), 100)

        # Cleanup
        delete_paper(uid)


if __name__ == "__main__":
    unittest.main()
