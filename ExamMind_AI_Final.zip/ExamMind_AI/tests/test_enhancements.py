import unittest
from engine.parser import DocumentParser
from engine.generator import ExamGenerator
from engine.grader import ExamGrader
from engine.docx_export import generate_exam_docx


class TestExamMindEnhancements(unittest.TestCase):

    def test_document_context_builder(self):
        sample_materials = {
            "slides": [{"filename": "lec1.txt", "text": "AVL trees have balance factors in {-1, 0, 1}.", "char_count": 50}],
            "assignments": [{"filename": "assign1.txt", "text": "Implement graph shortest path using Dijkstra.", "char_count": 60}],
            "quizzes": [{"filename": "quiz1.txt", "text": "Q1: What is the time complexity of BFS?", "char_count": 40}]
        }
        ctx = DocumentParser.build_prompt_material_context(sample_materials)
        self.assertIn("AVL trees", ctx["slides_content"])
        self.assertIn("Dijkstra", ctx["assignments_content"])
        self.assertIn("BFS", ctx["quizzes_content"])

    def test_docx_export(self):
        gen = ExamGenerator()
        pattern = {"total_marks": 20, "mcq_count": 5, "mcq_marks_each": 1, "short_count": 3, "short_marks_each": 5, "long_count": 0, "long_marks_each": 0, "tf_count": 0, "tf_marks_each": 0}
        paper = gen.generate_exam_paper("data_structures", "Midterm", pattern, llm_provider="offline")
        docx_bytes = generate_exam_docx(paper, include_solutions=True)
        self.assertGreater(len(docx_bytes), 500, "DOCX file bytes should be generated")

    def test_ai_auto_grader_offline(self):
        grader = ExamGrader()
        mock_paper = {
            "metadata": {"subject": "Data Structures", "course_code": "CS-202", "total_marks": 20, "exam_type": "Midterm"},
            "section_a_mcqs": [
                {"q_number": 1, "question": "What is the time complexity of binary search?", "marks": 1, "clo": "CLO1"},
                {"q_number": 2, "question": "Which data structure follows LIFO?", "marks": 1, "clo": "CLO1"}
            ],
            "section_a_tf": [],
            "section_b_short": [
                {"q_number": 1, "question": "Explain the AVL tree balance factor invariant.", "marks": 5, "clo": "CLO2"}
            ],
            "section_c_long": [],
            "marking_scheme_and_solutions": {
                "mcq_solutions": [
                    {"q_number": 1, "correct_option": "A", "explanation": "O(log n)"},
                    {"q_number": 2, "correct_option": "B", "explanation": "Stack is LIFO"}
                ],
                "short_solutions": [
                    {"q_number": 1, "model_answer": "AVL tree invariant requires balance factor to be in {-1, 0, +1}.", "rubric": "5 marks"}
                ]
            }
        }
        student_answers = {
            "mcq_1": "A",
            "mcq_2": "B",
            "short_1": "The AVL tree balance factor is calculated as height of left subtree minus height of right subtree and must strictly remain in {-1, 0, 1} for all nodes in the tree."
        }
        report = grader.grade_student_exam(mock_paper, student_answers, use_llm=False)
        self.assertIn("summary", report)
        self.assertGreater(report["summary"]["total_obtained"], 0)
        self.assertEqual(len(report["mcq_evaluations"]), 2)
        self.assertTrue(report["mcq_evaluations"][0]["is_correct"])
        self.assertIn("clo_diagnostics", report)


if __name__ == "__main__":
    unittest.main()
